import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { CompanyProfile } from './pages/CompanyProfile';
import { Clients } from './pages/Clients';
import { Home } from './pages/Home';
import { Products } from './pages/Products';
import { Invoices } from './pages/Invoices';
import { CreateInvoice } from './pages/CreateInvoice';
import { InvoiceDetail } from './pages/InvoiceDetail';
import { Quotes } from './pages/Quotes';
import { CreateQuote } from './pages/CreateQuote';
import { QuoteDetail } from './pages/QuoteDetail';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { AdminDashboard } from './pages/admin/Dashboard';
import { AdminLayout } from './components/AdminLayout';
import { AdminLogin } from './pages/admin/Login';
import { AdminClients } from './pages/admin/Clients';
import { AdminSubscriptions } from './pages/admin/Subscriptions';
import { AdminPayments } from './pages/admin/Payments';
import { AdminSettings } from './pages/admin/Settings';
import { AuthProvider, useAuth } from './contexts/AuthContext';

// This component must be used inside a Router
const ProtectedRouteContent = ({ children }: { children: React.ReactNode }) => {
  const { session, isPublicRoute } = useAuth();
  const location = useLocation();
  
  if (!session && !isPublicRoute(location.pathname)) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// Admin route protection
const AdminRouteContent = ({ children }: { children: React.ReactNode }) => {
  const { session, isAdminUser, isLoading } = useAuth();
  const location = useLocation();
  
  // When still checking admin status, show a loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }
  
  // If not logged in, redirect to admin login
  if (!session) {
    return <Navigate to="/admin/login" replace />;
  }
  
  // If logged in but not admin, show unauthorized
  if (!isAdminUser) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Acceso no autorizado</h1>
          <p className="text-gray-600 mb-6">
            No tienes permisos de administrador para acceder a esta sección.
          </p>
          <div className="flex justify-between">
            <button
              onClick={() => window.location.href = '/app'}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition-colors"
            >
              Volver a la aplicación
            </button>
            <button
              onClick={() => window.location.href = '/admin/login'}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors"
            >
              Iniciar sesión como admin
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return <>{children}</>;
};

const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ProtectedRouteContent>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            {/* App Routes */}
            <Route path="/app" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="company" element={<CompanyProfile />} />
              <Route path="clients" element={<Clients />} />
              <Route path="products" element={<Products />} />
              
              {/* Invoice Routes */}
              <Route path="invoices" element={<Invoices />} />
              <Route path="invoices/new" element={<CreateInvoice />} />
              <Route path="invoices/:id" element={<InvoiceDetail />} />
              <Route path="invoices/:id/edit" element={<CreateInvoice />} />
              
              {/* Quote Routes */}
              <Route path="quotes" element={<Quotes />} />
              <Route path="quotes/new" element={<CreateQuote />} />
              <Route path="quotes/:id" element={<QuoteDetail />} />
              <Route path="quotes/:id/edit" element={<CreateQuote />} />
              <Route path="quotes/:id/convert" element={<CreateInvoice />} />
            </Route>
            
            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={
              <AdminRouteContent>
                <AdminLayout />
              </AdminRouteContent>
            }>
              <Route index element={<AdminDashboard />} />
              <Route path="clients" element={<AdminClients />} />
              <Route path="subscriptions" element={<AdminSubscriptions />} />
              <Route path="payments" element={<AdminPayments />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
          </Routes>
        </ProtectedRouteContent>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
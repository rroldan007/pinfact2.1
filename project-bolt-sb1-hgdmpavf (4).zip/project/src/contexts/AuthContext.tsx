import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  session: Session | null;
  loading: boolean;
  isLoading: boolean;
  isPublicRoute: (path: string) => boolean;
  isAdminUser: boolean;
  checkAdminStatus: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  loading: true,
  isLoading: true,
  isPublicRoute: () => false,
  isAdminUser: false,
  checkAdminStatus: async () => false,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdminUser, setIsAdminUser] = useState(false);
  const [isCheckingAdmin, setIsCheckingAdmin] = useState(true);

  const isPublicRoute = (path: string) => {
    return ['/', '/login', '/register', '/admin/login'].includes(path);
  };

  // Function to check if current user is an admin
  const checkAdminStatus = async (): Promise<boolean> => {
    if (!session?.user?.id) {
      setIsAdminUser(false);
      return false;
    }
    
    try {
      setIsCheckingAdmin(true);
      
      // Use RPC function to check admin status
      const { data, error } = await supabase
        .rpc('check_admin_status', {
          checking_user_id: session.user.id
        });
        
      if (error) throw error;
      
      // Update admin status based on RPC result
      setIsAdminUser(!!data);
      return !!data;
      
    } catch (error) {
      console.error('Error checking admin status:', error);
      setIsAdminUser(false);
      return false;
    } finally {
      setIsCheckingAdmin(false);
    }
  };

  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (mounted) {
          setSession(session);
          
          if (session) {
            await checkAdminStatus();
          } else {
            setIsAdminUser(false);
          }
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        if (mounted) {
          setIsAdminUser(false);
        }
      } finally {
        if (mounted) {
          setLoading(false);
          setIsCheckingAdmin(false);
        }
      }
    };

    initAuth();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (mounted) {
        setSession(session);
        
        if (session) {
          await checkAdminStatus();
        } else {
          setIsAdminUser(false);
          setIsCheckingAdmin(false);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ 
      session, 
      loading, 
      isPublicRoute, 
      isAdminUser,
      isLoading: loading || isCheckingAdmin,
      checkAdminStatus
    }}>
      {children}
    </AuthContext.Provider>
  );
};
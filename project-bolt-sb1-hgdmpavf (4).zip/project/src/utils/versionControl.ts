/**
 * Version Control Utility
 * 
 * This file provides functionality to manage version snapshots of critical components
 * within the application. It allows storing and restoring specific versions of components.
 */

import { QrBillData, generateQrCodeContent, getQrCodeStyles, generateQrBillTemplate } from './swissQrBill';

export type ComponentVersion = {
  version: string;
  timestamp: string;
  component: string;
  snapshot: any;
};

// In-memory storage for snapshots (in a real app, this could be persisted to localStorage or IndexedDB)
const versionSnapshots: Record<string, ComponentVersion> = {};

/**
 * Creates a snapshot of the specified component with version information
 * 
 * @param component Name of the component being versioned
 * @param version Version identifier
 * @param snapshot Data snapshot of the component
 * @returns The saved ComponentVersion object
 */
export const createVersionSnapshot = (
  component: string,
  version: string,
  snapshot: any
): ComponentVersion => {
  const versionData: ComponentVersion = {
    version,
    timestamp: new Date().toISOString(),
    component,
    snapshot
  };
  
  // Create the key using component and version
  const key = `${component}@${version}`;
  
  // Store the snapshot
  versionSnapshots[key] = versionData;
  
  // Log the backup creation
  console.info(`📦 Version snapshot created: ${key} at ${versionData.timestamp}`);
  
  return versionData;
};

/**
 * Retrieves a specific version of a component
 * 
 * @param component Name of the component
 * @param version Version identifier to retrieve
 * @returns The ComponentVersion if found, null otherwise
 */
export const getVersionSnapshot = (
  component: string,
  version: string
): ComponentVersion | null => {
  const key = `${component}@${version}`;
  return versionSnapshots[key] || null;
};

/**
 * Lists all available versions for a specific component
 * 
 * @param component Name of the component
 * @returns Array of available versions
 */
export const listAvailableVersions = (
  component: string
): string[] => {
  return Object.keys(versionSnapshots)
    .filter(key => key.startsWith(`${component}@`))
    .map(key => key.split('@')[1]);
};

// Create a snapshot of the current SwissQRBill implementation (v2.0)
export const createSwissQRBillV2_0 = (): ComponentVersion => {
  // Capture the current implementation
  const snapshot = {
    generateQrCodeContent: generateQrCodeContent.toString(),
    getQrCodeStyles: getQrCodeStyles.toString(),
    generateQrBillTemplate: generateQrBillTemplate.toString()
  };
  
  return createVersionSnapshot('SwissQRBill', '2.0', snapshot);
};

// Create a snapshot of the current SwissQRBill implementation (v1.6 beta)
export const createSwissQRBillV1_6Beta = (): ComponentVersion => {
  // Capture the current implementation
  const snapshot = {
    generateQrCodeContent: generateQrCodeContent.toString(),
    getQrCodeStyles: getQrCodeStyles.toString(),
    generateQrBillTemplate: generateQrBillTemplate.toString()
  };
  
  return createVersionSnapshot('SwissQRBill', '1.6-betaQR', snapshot);
};

// Export a function to restore QR functionality to v2.0 if needed in the future
export const restoreSwissQRBillV2_0 = (): boolean => {
  const snapshot = getVersionSnapshot('SwissQRBill', '2.0');
  if (!snapshot) {
    console.error('❌ SwissQRBill v2.0 snapshot not found');
    return false;
  }
  
  console.info(`🔄 Restoring SwissQRBill to version 2.0 (from ${snapshot.timestamp})`);
  // In a real implementation, this would actually replace the current functions
  // But since we can't do that directly in JavaScript, this would need to be handled
  // by a more sophisticated mechanism like module replacement or dependency injection
  
  return true;
};

// Export a function to restore QR functionality to v1.6 beta if needed in the future
export const restoreSwissQRBillV1_6Beta = (): boolean => {
  const snapshot = getVersionSnapshot('SwissQRBill', '1.6-betaQR');
  if (!snapshot) {
    console.error('❌ SwissQRBill v1.6-betaQR snapshot not found');
    return false;
  }
  
  console.info(`🔄 Restoring SwissQRBill to version 1.6-betaQR (from ${snapshot.timestamp})`);
  // In a real implementation, this would actually replace the current functions
  // But since we can't do that directly in JavaScript, this would need to be handled
  // by a more sophisticated mechanism like module replacement or dependency injection
  
  return true;
};
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { QrBillData } from './swissQrBill';

/**
 * Generates a PDF file with multiple pages from an array of HTML elements
 * 
 * @param elements Array of HTML elements to convert to PDF pages
 * @param filename Output filename for the PDF
 * @returns Promise that resolves when the PDF is saved
 */
export const generateMultiPagePDF = async (
  elements: HTMLElement[],
  filename: string = 'document.pdf'
): Promise<void> => {
  try {
    // Create A4 PDF
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });
    
    // Process each element as a separate page
    for (let i = 0; i < elements.length; i++) {
      // Add a new page for each element after the first one
      if (i > 0) {
        pdf.addPage();
      }
      
      const element = elements[i];
      
      // Generate canvas for this element
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#FFFFFF'
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      
      const imgWidth = 210; // A4 width in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, Math.min(imgHeight, 297));
      
      // If content is taller than A4 height, create additional pages
      if (imgHeight > 297) {
        let heightLeft = imgHeight - 297;
        let position = -297;
        
        while (heightLeft > 0) {
          pdf.addPage();
          pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
          heightLeft -= 297;
          position -= 297;
        }
      }
    }
    
    // Save the PDF
    pdf.save(filename);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Failed to generate PDF');
  }
};

/**
 * Directly generates a Swiss QR Bill as a PDF using jsPDF
 * This approach ensures exact dimensions and proper formatting required by banks
 * 
 * @param qrBillData Data for the QR bill
 * @param qrCodeDataUrl The QR code as a data URL
 * @param filename Output filename for the PDF
 */
export const generateQrBillPDF = (
  qrBillData: QrBillData,
  qrCodeDataUrl: string,
  filename: string = 'QRBill.pdf'
): void => {
  try {
    // Create A4 PDF
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Set position at the bottom third of the page
    const startY = 180; // Start at 180mm from top
    
    // Define section widths per specifications
    const receiptWidth = 62; // mm
    const paymentWidth = 148; // mm
    const margin = 10; // mm
    const startX = margin;
    
    // Draw outer border of the entire slip
    doc.setDrawColor(0);
    doc.setLineWidth(0.5);
    doc.rect(startX, startY, receiptWidth + paymentWidth, 105);
    
    // Draw separator between receipt and payment parts
    doc.setLineDashPattern([3, 2], 0);
    doc.line(startX + receiptWidth, startY, startX + receiptWidth, startY + 105);
    doc.setLineDashPattern([], 0);
    
    // ---- Receipt Section (62mm wide) ----
    const rx = startX + 5; // Receipt content starts 5mm from left border
    let ry = startY + 10;  // Start receipt content 10mm from top of receipt
    
    // Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Receipt', rx, ry);
    ry += 8;
    
    // Account information
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    doc.text('Account / Payable to', rx, ry);
    ry += 3;
    
    doc.setFontSize(8);
    doc.text(qrBillData.creditorIban, rx, ry);
    ry += 4;
    doc.text(qrBillData.creditorName, rx, ry);
    ry += 4;
    
    if (qrBillData.creditorAddress) {
      doc.text(qrBillData.creditorAddress, rx, ry);
      ry += 4;
    }
    
    if (qrBillData.creditorPostalCode || qrBillData.creditorCity) {
      doc.text(`${qrBillData.creditorPostalCode} ${qrBillData.creditorCity}`, rx, ry);
      ry += 4;
    }
    
    doc.text(qrBillData.creditorCountry, rx, ry);
    ry += 8;
    
    // Empty Reference field
    doc.setFontSize(6);
    doc.text('Reference', rx, ry);
    ry += 8;
    
    // Payable by section if debtor info is available
    if (qrBillData.debtorName) {
      doc.setFontSize(6);
      doc.text('Payable by', rx, ry);
      ry += 3;
      
      doc.setFontSize(8);
      doc.text(qrBillData.debtorName, rx, ry);
      ry += 4;
      
      if (qrBillData.debtorAddress) {
        doc.text(qrBillData.debtorAddress, rx, ry);
        ry += 4;
      }
      
      if (qrBillData.debtorPostalCode || qrBillData.debtorCity) {
        doc.text(`${qrBillData.debtorPostalCode} ${qrBillData.debtorCity}`, rx, ry);
        ry += 4;
      }
      
      if (qrBillData.debtorCountry) {
        doc.text(qrBillData.debtorCountry, rx, ry);
      }
    }
    
    // Amount section - positioned at the bottom of the receipt
    const amountY = startY + 75;
    
    // Currency
    doc.setFontSize(6);
    doc.text('Currency', rx, amountY);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text(qrBillData.currency, rx, amountY + 4);
    
    // Amount
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('Amount', rx + 30, amountY);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text(qrBillData.amount.toFixed(2), rx + 30, amountY + 4);
    
    // Acceptance point
    doc.setLineWidth(0.2);
    doc.line(rx, startY + 85, rx + 52, startY + 85);
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('Acceptance point', rx, startY + 90);
    
    // ---- Payment Section (148mm wide) ----
    const px = startX + receiptWidth + 5; // Payment section starts 5mm after receipt section
    let py = startY + 10; // Start payment content 10mm from top
    
    // Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Payment part', px, py);
    py += 10;
    
    // QR Code - exactly 46x46mm
    if (qrCodeDataUrl) {
      doc.addImage(qrCodeDataUrl, 'PNG', px, py, 46, 46);
      
      // Add Swiss cross in the center
      const crossSize = 7; // mm
      const crossX = px + (46 - crossSize) / 2;
      const crossY = py + (46 - crossSize) / 2;
      
      // White background for cross
      doc.setFillColor(255, 255, 255);
      doc.rect(crossX, crossY, crossSize, crossSize, 'F');
      
      // Black square for cross
      doc.setFillColor(0, 0, 0);
      doc.rect(crossX + 1, crossY + 1, crossSize - 2, crossSize - 2, 'F');
      
      // White cross
      doc.setFillColor(255, 255, 255);
      doc.rect(crossX + 1 + (crossSize - 2) / 3, crossY + 1, (crossSize - 2) / 3, crossSize - 2, 'F');
      doc.rect(crossX + 1, crossY + 1 + (crossSize - 2) / 3, crossSize - 2, (crossSize - 2) / 3, 'F');
    }
    
    // Currency and amount below QR code
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('Currency', px + 18, py + 50);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text(qrBillData.currency, px + 23, py + 54);
    
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('Amount', px + 18, py + 58);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text(qrBillData.amount.toFixed(2), px + 23, py + 62);
    
    // Payment information - right side of QR code
    const infoX = px + 54; // 54mm right of payment section start (after QR code + margin)
    let infoY = py;
    
    // Account information
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('Account / Payable to', infoX, infoY);
    infoY += 3;
    
    doc.setFontSize(8);
    doc.text(qrBillData.creditorIban, infoX, infoY);
    infoY += 4;
    doc.text(qrBillData.creditorName, infoX, infoY);
    infoY += 4;
    
    if (qrBillData.creditorAddress) {
      doc.text(qrBillData.creditorAddress, infoX, infoY);
      infoY += 4;
    }
    
    if (qrBillData.creditorPostalCode || qrBillData.creditorCity) {
      doc.text(`${qrBillData.creditorPostalCode} ${qrBillData.creditorCity}`, infoX, infoY);
      infoY += 4;
    }
    
    doc.text(qrBillData.creditorCountry, infoX, infoY);
    infoY += 8;
    
    // Empty Reference field
    doc.setFontSize(6);
    doc.text('Reference', infoX, infoY);
    infoY += 8;
    
    // Empty Additional Information field
    doc.setFontSize(6);
    doc.text('Additional information', infoX, infoY);
    infoY += 8;
    
    // Payable by section if debtor info is available
    if (qrBillData.debtorName) {
      doc.setFontSize(6);
      doc.text('Payable by', infoX, infoY);
      infoY += 3;
      
      doc.setFontSize(8);
      doc.text(qrBillData.debtorName, infoX, infoY);
      infoY += 4;
      
      if (qrBillData.debtorAddress) {
        doc.text(qrBillData.debtorAddress, infoX, infoY);
        infoY += 4;
      }
      
      if (qrBillData.debtorPostalCode || qrBillData.debtorCity) {
        doc.text(`${qrBillData.debtorPostalCode} ${qrBillData.debtorCity}`, infoX, infoY);
        infoY += 4;
      }
      
      if (qrBillData.debtorCountry) {
        doc.text(qrBillData.debtorCountry, infoX, infoY);
      }
    }
    
    // Scissors line
    const scissorsY = startY + 85;
    doc.setLineDashPattern([3, 2], 0);
    doc.line(startX + receiptWidth, scissorsY, startX + receiptWidth + paymentWidth, scissorsY);
    
    // Scissors symbol text
    doc.setFontSize(6);
    doc.setFont('helvetica', 'normal');
    doc.text('✂ Separate before paying in ✂', px + 40, scissorsY - 1);
    
    // Save the PDF
    doc.save(filename);
  } catch (error) {
    console.error('Error generating QR bill PDF:', error);
    throw new Error('Failed to generate QR bill PDF');
  }
};

/**
 * Email an invoice to a client
 * @param invoiceId ID of the invoice to email
 * @param emailAddress Email address to send to
 * @param customMessage Optional custom message to include
 */
export const emailInvoice = async (
  invoiceId: string,
  emailAddress: string,
  customMessage?: string
): Promise<void> => {
  try {
    // Implementation would depend on your backend setup
    // This is a placeholder for actual email sending logic
    console.log(`Sending invoice ${invoiceId} to ${emailAddress} with message: ${customMessage}`);
    
    // In a real implementation, you would make an API call to your backend
    // to send the email with the invoice attached
    
    return Promise.resolve();
  } catch (error) {
    console.error('Error sending invoice email:', error);
    throw new Error('Failed to send invoice email');
  }
};
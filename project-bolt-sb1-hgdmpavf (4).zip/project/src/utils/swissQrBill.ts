import { QRCodeSVG } from 'qrcode.react';

// Type for our invoice data needed to generate a QR bill
export interface QrBillData {
  invoiceNumber: string;
  amount: number;
  currency: string;
  creditorName: string;
  creditorAddress: string;
  creditorPostalCode: string;
  creditorCity: string;
  creditorCountry: string;
  creditorIban: string;
  debtorName?: string;
  debtorAddress?: string;
  debtorPostalCode?: string;
  debtorCity?: string;
  debtorCountry?: string;
  message?: string;
}

/**
 * Format amounts for Swiss QR bill per specification
 * Must be formatted as #.## with two decimal places and no thousands separators
 */
const formatAmount = (amount: number): string => {
  // Format with exactly 2 decimal places, no thousands separators
  return amount.toFixed(2);
};

/**
 * Format IBAN for Swiss QR bill (remove spaces)
 */
const formatIban = (iban: string): string => {
  // Remove all whitespace and convert to uppercase
  return iban.replace(/\s/g, '').toUpperCase();
};

/**
 * Generate the Swiss QR Code content string according to Swiss Payments standards (SPC)
 * Implemented according to the official Swiss QR Code specification v2.0:
 * https://www.paymentstandards.ch/dam/downloads/ig-qr-bill-en.pdf
 */
export const generateQrCodeContent = (data: QrBillData): string => {
  try {
    // Format IBAN (remove spaces)
    const iban = formatIban(data.creditorIban);
    
    // Format amount
    const amount = formatAmount(data.amount);

    // Format addresses according to Swiss Payment Standards
    const formatAddress = (address: string | undefined) => {
      return address ? address.replace(/\n/g, ' ').substring(0, 70) : '';
    };

    // Format postal codes and cities
    const formatPostalCodeCity = (postalCode: string | undefined, city: string | undefined) => {
      return (postalCode && city) ? `${postalCode} ${city}` : '';
    };

    // Use CRLF for line breaks as specified in the standard
    const CRLF = '\r\n';

    // Build QR code data according to Swiss Payments Standard (SPS) v2.0
    const qrCodeData = [
      'SPC',                                             // QR Type - fixed value
      '0200',                                            // Version - fixed value for version 2.0
      '1',                                               // Coding Type (1=UTF-8) - fixed value
      iban,                                              // IBAN - no spaces
      'S',                                               // Creditor address type (S=structured)
      data.creditorName.substring(0, 70),                // Creditor name (max 70 chars)
      formatAddress(data.creditorAddress),               // Creditor address
      formatPostalCodeCity(data.creditorPostalCode, data.creditorCity), // Creditor postal code and city
      'CH',                                              // Always use CH for creditor country
      '',                                                // Empty field for future use
      
      // Alternative procedures - all empty as per spec for standard payment
      '', '', '', '', '', '', '',
      
      // Payment information
      amount,                                            // Amount - always with 2 decimal places
      data.currency,                                     // Currency - CHF or EUR
      
      // Debtor information - optional
      data.debtorName ? 'S' : '',                        // Debtor address type (S if present)
      data.debtorName || '',                             // Debtor name
      formatAddress(data.debtorAddress),                 // Debtor address
      formatPostalCodeCity(data.debtorPostalCode, data.debtorCity), // Debtor postal code and city
      'CH',                                              // Always use CH for debtor country
      
      // Reference information
      'NON',                                             // Reference type (NON = no reference)
      '',                                                // Reference value (empty for NON)
      
      // Additional information
      data.message || `Invoice ${data.invoiceNumber}`,   // Unstructured message
      'EPD'                                              // EPD - fixed value for end of payment data
    ];

    // Join all elements with line breaks (CRLF according to spec)
    return qrCodeData.join(CRLF);
  } catch (error) {
    console.error('Error generating Swiss QR bill content:', error);
    throw new Error('Failed to generate Swiss QR bill content');
  }
};

/**
 * Get QR code styles for Swiss QR Bill according to specification
 * Based on official Swiss QR Bill specifications:
 * - QR code must be exactly 46x46mm
 * - Swiss cross must be 7x7mm in the center
 * - Must have 4 module quiet zone
 * - Must use error correction level M (15%)
 */
export const getQrCodeStyles = () => {
  return {
    width: 174,       // 46mm at 96dpi
    height: 174,      // 46mm at 96dpi
    level: 'M' as 'L' | 'M' | 'Q' | 'H',  // Medium error correction (15%) as per spec
    bgColor: "#FFFFFF",
    fgColor: "#000000",
    includeMargin: true, // Include 4 module quiet zone
    marginSize: 4,    // 4 modules quiet zone as per spec
  };
};

/**
 * Generate a Swiss QR Bill paper format template
 */
export const generateQrBillTemplate = (data: QrBillData): any => {
  const formatCurrency = (amount: number): string => {
    return amount.toFixed(2);
  };

  // Generate QR code content string according to Swiss payment standards
  const qrCodeValue = generateQrCodeContent(data);

  // Format IBAN for display (CH12 3456 7890 1234 5678 9)
  const formatIbanForDisplay = (iban: string): string => {
    const cleanIban = iban.replace(/\s/g, '');
    return cleanIban.match(/.{1,4}/g)?.join(' ') || cleanIban;
  };

  // Generate QR reference if it's a QR IBAN
  const iban = formatIban(data.creditorIban);
  const isQrIban = iban.startsWith('CH') && 
                   parseInt(iban.substring(4, 9), 10) >= 30000 && 
                   parseInt(iban.substring(4, 9), 10) <= 31999;

  return {
    qrCodeValue,
    amount: formatCurrency(data.amount),
    currency: data.currency || 'CHF',
    creditorName: data.creditorName,
    creditorAddress: data.creditorAddress,
    creditorPostalCode: data.creditorPostalCode,
    creditorCity: data.creditorCity,
    creditorCountry: data.creditorCountry,
    creditorIban: formatIbanForDisplay(data.creditorIban),
    debtorName: data.debtorName,
    debtorAddress: data.debtorAddress,
    debtorPostalCode: data.debtorPostalCode,
    debtorCity: data.debtorCity,
    debtorCountry: data.debtorCountry,
    reference: '',
    message: `Invoice ${data.invoiceNumber}`,
    isQrIban: isQrIban
  };
};

/**
 * Validate Swiss QR bill data according to specifications
 */
export const validateQrBillData = (data: QrBillData): { valid: boolean; errors: string[] } => {
  const errors: string[] = [];

  // Validate IBAN
  const iban = formatIban(data.creditorIban);
  if (!iban.match(/^CH|LI[0-9]{19}$/)) {
    errors.push('Invalid IBAN format. Must be a valid Swiss or Liechtenstein IBAN.');
  }

  // Validate amount
  if (data.amount <= 0 || data.amount > 999999999.99) {
    errors.push('Amount must be between 0.01 and 999,999,999.99');
  }

  // Validate currency
  if (!['CHF', 'EUR'].includes(data.currency)) {
    errors.push('Currency must be either CHF or EUR');
  }

  // Validate creditor information
  if (!data.creditorName || data.creditorName.length > 70) {
    errors.push('Creditor name is required and must not exceed 70 characters');
  }

  // Validate debtor information if provided
  if (data.debtorName) {
    if (data.debtorName.length > 70) {
      errors.push('Debtor name must not exceed 70 characters');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
};
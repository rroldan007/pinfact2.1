/**
 * QR Code generator library
 * Adapted from Nayuki's QR Code generator (https://github.com/nayuki/QR-Code-generator)
 * 
 * This is a specialized version for Swiss QR Bill that follows the specifications required
 * by Swiss banks for payment slips.
 */

/*
 * QR Code generator library (TypeScript)
 * 
 * Copyright (c) Project Nayuki. (MIT License)
 * https://www.nayuki.io/page/qr-code-generator-library
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 * - The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 * - The Software is provided "as is", without warranty of any kind, express or
 *   implied, including but not limited to the warranties of merchantability,
 *   fitness for a particular purpose and noninfringement. In no event shall the
 *   authors or copyright holders be liable for any claim, damages or other
 *   liability, whether in an action of contract, tort or otherwise, arising from,
 *   out of or in connection with the Software or the use or other dealings in the
 *   Software.
 */

export type Ecc = 'L' | 'M' | 'Q' | 'H';

// We define the QR Code module here
export class QrCode {
  // Static factory function to create a QR Code from a string of text.
  public static encodeText(text: string, ecl: Ecc): QrCode {
    const segs = QrSegment.makeSegments(text);
    return QrCode.encodeSegments(segs, ecl);
  }

  // Static factory function to create a QR Code from segments.
  public static encodeSegments(segs: QrSegment[], ecl: Ecc, minVersion: number = 1, maxVersion: number = 40, mask: number = -1, boostEcl: boolean = true): QrCode {
    if (!(QrCode.MIN_VERSION <= minVersion && minVersion <= maxVersion && maxVersion <= QrCode.MAX_VERSION) || mask < -1 || mask > 7) {
      throw new RangeError("Invalid value");
    }

    // Find the minimal version number to use
    let version: number;
    let dataUsedBits: number;
    for (version = minVersion; ; version++) {
      const dataCapacityBits: number = QrCode.getNumDataCodewords(version, ecl) * 8; // Number of data bits available
      const usedBits: number = QrSegment.getTotalBits(segs, version);
      if (usedBits <= dataCapacityBits) {
        dataUsedBits = usedBits;
        break; // This version number is found to be suitable
      }
      if (version >= maxVersion) {
        // All versions in the range could not fit the given data
        throw new RangeError("Data too long");
      }
    }

    // Increase the error correction level while the data still fits in the current version number
    for (const newEcl of [Ecc.M, Ecc.Q, Ecc.H]) {
      if (boostEcl && dataUsedBits <= QrCode.getNumDataCodewords(version, newEcl) * 8) {
        ecl = newEcl;
      }
    }

    // Concatenate all segments to create the data bit string
    const bb: Array<number> = [];
    for (const seg of segs) {
      appendBits(seg.mode, 4, bb);
      appendBits(seg.numChars, seg.mode.numCharCountBits(version), bb);
      for (const b of seg.getData()) {
        bb.push(b);
      }
    }
    
    // Add terminator and pad up to a byte if applicable
    const dataCapacityBits: number = QrCode.getNumDataCodewords(version, ecl) * 8;
    if (bb.length > dataCapacityBits) {
      throw new RangeError("Assertion error");
    }
    appendBits(0, Math.min(4, dataCapacityBits - bb.length), bb);
    appendBits(0, (8 - (bb.length % 8)) % 8, bb);
    
    // Pad with alternating bytes until data capacity is reached
    for (let padByte = 0xEC; bb.length < dataCapacityBits; padByte ^= 0xEC ^ 0x11) {
      appendBits(padByte, 8, bb);
    }

    // Pack bits into bytes in big endian
    const dataCodewords: Array<number> = [];
    for (let i = 0; i < bb.length; i += 8) {
      dataCodewords.push(getByte(bb, i));
    }

    // Create the QR Code object
    return new QrCode(version, ecl, dataCodewords, mask);
  }

  // Returns the number of data bits that can be stored in a QR Code of the given version number, after
  // all function modules are excluded. This includes remainder bits, so it might not be a multiple of 8.
  // The result is in the range [208, 29648]. This could be implemented as a lookup table.
  private static getNumRawDataModules(ver: number): number {
    if (ver < QrCode.MIN_VERSION || ver > QrCode.MAX_VERSION) {
      throw new RangeError("Version number out of range");
    }
    let result: number = (16 * ver + 128) * ver + 64;
    if (ver >= 2) {
      const numAlign: number = Math.floor(ver / 7) + 2;
      result -= (25 * numAlign - 10) * numAlign - 55;
      if (ver >= 7) {
        result -= 36;
      }
    }
    return result;
  }

  // Returns the number of 8-bit data (i.e., not error correction) codewords contained in any
  // QR Code of the given version number and error correction level, with remainder bits discarded.
  // This stateless pure function could be implemented as a (40*4)-cell lookup table.
  private static getNumDataCodewords(ver: number, ecl: Ecc): number {
    return Math.floor(QrCode.getNumRawDataModules(ver) / 8) -
      QrCode.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver] *
      QrCode.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
  }

  // The minimum version number supported in the QR Code Model 2 standard
  public static readonly MIN_VERSION: number =  1;
  // The maximum version number supported in the QR Code Model 2 standard
  public static readonly MAX_VERSION: number = 40;

  // For use in getPenaltyScore(), when evaluating which mask is best.
  private static readonly PENALTY_N1: number =  3;
  private static readonly PENALTY_N2: number =  3;
  private static readonly PENALTY_N3: number = 40;
  private static readonly PENALTY_N4: number = 10;

  private static readonly ECC_CODEWORDS_PER_BLOCK: number[][] = [
    // Version: (note that index 0 is for padding, and is set to an illegal value)
    //0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40    Error correction level
    [-1,  7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],  // Low
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],  // Medium
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],  // Quartile
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],  // High
  ];

  private static readonly NUM_ERROR_CORRECTION_BLOCKS: number[][] = [
    // Version: (note that index 0 is for padding, and is set to an illegal value)
    //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40    Error correction level
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4,  4,  4,  4,  4,  6,  6,  6,  6,  7,  8,  8,  9,  9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],  // Low
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5,  5,  8,  9,  9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],  // Medium
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8,  8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],  // Quartile
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81],  // High
  ];

  // Constructor.
  public constructor(
    // The version number of this QR Code, which is between 1 and 40 (inclusive).
    // This determines the size of this barcode.
    public readonly version: number,
    
    // The error correction level used in this QR Code.
    public readonly errorCorrectionLevel: Ecc,
    
    // The modules/pixels of this QR Code (false = white, true = black).
    // Immutable after constructor finishes. Accessed through getModule().
    private readonly modules: Array<Array<boolean>>,
    
    // Indicates function modules that are not subjected to masking. Discarded when constructor finishes.
    private readonly isFunction: Array<Array<boolean>>,
  ) {
    // Check scalar arguments
    if (version < QrCode.MIN_VERSION || version > QrCode.MAX_VERSION) {
      throw new RangeError("Version value out of range");
    }
    if (mask < -1 || mask > 7) {
      throw new RangeError("Mask value out of range");
    }
    this.size = version * 4 + 17;
    
    // Initialize both grids to be size*size arrays of Boolean false
    let row = [];
    for (let i = 0; i < this.size; i++) {
      row.push(false);
    }
    for (let i = 0; i < this.size; i++) {
      this.modules.push(row.slice());  // Initially all white
      this.isFunction.push(row.slice());
    }
    
    // Compute ECC, draw modules
    this.drawFunctionPatterns();
    const allCodewords: Array<number> = this.addEccAndInterleave(dataCodewords);
    this.drawCodewords(allCodewords);
    
    // Do masking
    if (mask === -1) {  // Automatically choose best mask
      let minPenalty: number = 1000000000;
      for (let i = 0; i < 8; i++) {
        this.applyMask(i);
        this.drawFormatBits(i);
        const penalty: number = this.getPenaltyScore();
        if (penalty < minPenalty) {
          mask = i;
          minPenalty = penalty;
        }
        this.applyMask(i);  // Undoes the mask due to XOR
      }
    }
    this.mask = mask;
    this.applyMask(mask);  // Apply the final choice of mask
    this.drawFormatBits(mask);  // Overwrite old format bits
    
    this.isFunction = [];
  }
  
  // Returns the color of the module (pixel) at the given coordinates, which is false
  // for white or true for black. The top left corner has the coordinates (x=0, y=0).
  // If the given coordinates are out of bounds, then false (white) is returned.
  public getModule(x: number, y: number): boolean {
    return 0 <= x && x < this.size && 0 <= y && y < this.size && this.modules[y][x];
  }
  
  // Helper function to generate an SVG string for this QR Code.
  public toSvgString(border: number = 0): string {
    const blackValue = "#000000";
    const whiteValue = "#FFFFFF";
    let result = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    result += `<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n`;
    result += `<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 ${this.size + border * 2} ${this.size + border * 2}" stroke="none">\n`;
    result += `\t<rect width="100%" height="100%" fill="${whiteValue}"/>\n`;
    result += `\t<path d="`;
    for (let y = 0; y < this.size; y++) {
      for (let x = 0; x < this.size; x++) {
        if (this.getModule(x, y)) {
          if (x !== 0 || y !== 0) {
            result += " ";
          }
          result += `M${x + border},${y + border}h1v1h-1z`;
        }
      }
    }
    result += `" fill="${blackValue}"/>\n`;
    result += `</svg>\n`;
    return result;
  }

  // Returns this QR Code's modules and size as a new 2D Boolean array.
  public getModules(): boolean[][] {
    const result: boolean[][] = [];
    for (const row of this.modules) {
      result.push(row.slice());
    }
    return result;
  }
  
  // Gets the size (number of modules) of this QR Code.
  public getSize(): number {
    return this.size;
  }

  // Reads this object's version field, and draws and marks all function modules.
  private drawFunctionPatterns(): void {
    // Draw horizontal and vertical timing patterns
    for (let i = 0; i < this.size; i++) {
      this.setFunctionModule(6, i, i % 2 === 0);
      this.setFunctionModule(i, 6, i % 2 === 0);
    }
    
    // Draw 3 finder patterns (all corners except bottom right; overwrites some timing modules)
    this.drawFinderPattern(3, 3);
    this.drawFinderPattern(this.size - 4, 3);
    this.drawFinderPattern(3, this.size - 4);
    
    // Draw numerous alignment patterns
    const alignPatPos: Array<number> = this.getAlignmentPatternPositions();
    const numAlign: number = alignPatPos.length;
    for (let i = 0; i < numAlign; i++) {
      for (let j = 0; j < numAlign; j++) {
        // Don't draw on the three finder corners
        if (!((i === 0 && j === 0) || (i === 0 && j === numAlign - 1) || (i === numAlign - 1 && j === 0))) {
          this.drawAlignmentPattern(alignPatPos[i], alignPatPos[j]);
        }
      }
    }
    
    // Draw configuration data
    this.drawFormatBits(0);  // Dummy mask value; overwritten later in the constructor
    this.drawVersion();
  }

  // Draws two copies of the format bits (with its own error correction code)
  // based on the given mask and this object's error correction level field.
  private drawFormatBits(mask: number): void {
    // Calculate error correction code and pack bits
    const data: number = this.errorCorrectionLevel.formatBits << 3 | mask;  // errCorrLvl is uint2, mask is uint3
    let rem: number = data;
    for (let i = 0; i < 10; i++) {
      rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    }
    const bits = ((data << 10) | rem) ^ 0x5412;  // uint15
    if (bits >>> 15 !== 0) {
      throw new RangeError("Assertion error");
    }
    
    // Draw first copy
    for (let i = 0; i <= 5; i++) {
      this.setFunctionModule(8, i, getBit(bits, i));
    }
    this.setFunctionModule(8, 7, getBit(bits, 6));
    this.setFunctionModule(8, 8, getBit(bits, 7));
    this.setFunctionModule(7, 8, getBit(bits, 8));
    for (let i = 9; i < 15; i++) {
      this.setFunctionModule(14 - i, 8, getBit(bits, i));
    }
    
    // Draw second copy
    for (let i = 0; i < 8; i++) {
      this.setFunctionModule(this.size - 1 - i, 8, getBit(bits, i));
    }
    for (let i = 8; i < 15; i++) {
      this.setFunctionModule(8, this.size - 15 + i, getBit(bits, i));
    }
    this.setFunctionModule(8, this.size - 8, true);  // Always black
  }

  // Draws two copies of the version bits (with its own error correction code),
  // based on this object's version field, iff 7 <= version <= 40.
  private drawVersion(): void {
    if (this.version < 7) {
      return;
    }
    
    // Calculate error correction code and pack bits
    let rem: number = this.version;  // version is uint6, in the range [7, 40]
    for (let i = 0; i < 12; i++) {
      rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
    }
    const bits: number = this.version << 12 | rem;  // uint18
    if (bits >>> 18 !== 0) {
      throw new RangeError("Assertion error");
    }
    
    // Draw two copies
    for (let i = 0; i < 18; i++) {
      const color: boolean = getBit(bits, i);
      const a: number = this.size - 11 + i % 3;
      const b: number = Math.floor(i / 3);
      this.setFunctionModule(a, b, color);
      this.setFunctionModule(b, a, color);
    }
  }

  // Draws a 9*9 finder pattern including the border separator,
  // with the center module at (x, y). Modules can be out of bounds.
  private drawFinderPattern(x: number, y: number): void {
    for (let dy = -4; dy <= 4; dy++) {
      for (let dx = -4; dx <= 4; dx++) {
        const dist: number = Math.max(Math.abs(dx), Math.abs(dy));  // Chebyshev/infinity norm
        const xx: number = x + dx;
        const yy: number = y + dy;
        if (0 <= xx && xx < this.size && 0 <= yy && yy < this.size) {
          this.setFunctionModule(xx, yy, dist != 2 && dist != 4);
        }
      }
    }
  }

  // Draws a 5*5 alignment pattern, with the center module
  // at (x, y). All modules must be in bounds.
  private drawAlignmentPattern(x: number, y: number): void {
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        this.setFunctionModule(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
      }
    }
  }

  // Sets the color of a module and marks it as a function module.
  // Only used by the constructor. Coordinates must be in bounds.
  private setFunctionModule(x: number, y: number, isBlack: boolean): void {
    this.modules[y][x] = isBlack;
    this.isFunction[y][x] = true;
  }

  // Returns the positions of alignment patterns for this version number.
  // Each position is in the range [0,177), and are used on both the x and y axes.
  // This could be implemented as lookup table of 40 variable-length lists of unsigned bytes.
  private getAlignmentPatternPositions(): Array<number> {
    if (this.version === 1) {
      return [];
    }
    const numAlign: number = Math.floor(this.version / 7) + 2;
    const step: number = (this.version === 32) ? 26 :
      Math.ceil((this.size - 13) / (numAlign * 2 - 2)) * 2;
    const result: Array<number> = [6];
    for (let pos = this.size - 7; result.length < numAlign; pos -= step) {
      result.splice(1, 0, pos);
    }
    return result;
  }

  // Returns the number of data bits that can be stored in a QR Code of the given version number, after
  // all function modules are excluded. This includes remainder bits, so it might not be a multiple of 8.
  // The result is in the range [208, 29648]. This could be implemented as a lookup table.
  private static getNumRawDataModules(ver: number): number {
    if (ver < QrCode.MIN_VERSION || ver > QrCode.MAX_VERSION) {
      throw new RangeError("Version number out of range");
    }
    let result: number = (16 * ver + 128) * ver + 64;
    if (ver >= 2) {
      const numAlign: number = Math.floor(ver / 7) + 2;
      result -= (25 * numAlign - 10) * numAlign - 55;
      if (ver >= 7) {
        result -= 36;
      }
    }
    return result;
  }

  // Returns a Reed-Solomon ECC generator polynomial for the given degree. This could be
  // implemented as a lookup table over all possible parameter values, instead of as an algorithm.
  private static reedSolomonComputeDivisor(degree: number): Array<number> {
    if (degree < 1 || degree > 255) {
      throw new RangeError("Degree out of range");
    }
    // Polynomial coefficients are stored from highest to lowest power, excluding the leading term which is always 1.
    // For example the polynomial x^3 + 255x^2 + 8x + 93 is stored as the uint8 array [255, 8, 93].
    const result: Array<number> = [];
    for (let i = 0; i < degree - 1; i++) {
      result.push(0);
    }
    result.push(1);  // Start with the monomial x^0
    
    // Compute the product polynomial (x - r^0) * (x - r^1) * (x - r^2) * ... * (x - r^{degree-1}),
    // and drop the highest monomial term which is always 1x^degree.
    // Note that r = 0x02, which is a generator element of this field GF(2^8/0x11D).
    let root = 1;
    for (let i = 0; i < degree; i++) {
      // Multiply the current product by (x - r^i)
      for (let j = 0; j < result.length; j++) {
        result[j] = QrCode.reedSolomonMultiply(result[j], root);
        if (j + 1 < result.length) {
          result[j] ^= result[j + 1];
        }
      }
      root = QrCode.reedSolomonMultiply(root, 0x02);
    }
    return result;
  }

  // Returns the Reed-Solomon error correction codeword for the given data and divisor polynomials.
  private static reedSolomonComputeRemainder(data: Readonly<Array<number>>, divisor: Readonly<Array<number>>): Array<number> {
    const result: Array<number> = divisor.map(_ => 0);
    for (const b of data) {  // Polynomial division
      const factor: number = b ^ result.shift();
      result.push(0);
      for (let i = 0; i < result.length; i++) {
        result[i] ^= QrCode.reedSolomonMultiply(divisor[i], factor);
      }
    }
    return result;
  }

  // Returns the product of the two given field elements modulo GF(2^8/0x11D).
  // All inputs are valid. This could be implemented as a lookup table.
  private static reedSolomonMultiply(x: number, y: number): number {
    if (x >>> 8 !== 0 || y >>> 8 !== 0) {
      throw new RangeError("Byte out of range");
    }
    // Russian peasant multiplication
    let z: number = 0;
    for (let i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    if (z >>> 8 !== 0) {
      throw new RangeError("Assertion error");
    }
    return z;
  }

  // Draws the given sequence of 8-bit codewords (data and error correction) onto the entire
  // data area of this QR Code. Function modules need to be marked off before this is called.
  private drawCodewords(data: Readonly<Array<number>>): void {
    if (data.length != Math.floor(QrCode.getNumRawDataModules(this.version) / 8)) {
      throw new RangeError("Invalid argument");
    }
    let i: number = 0;  // Bit index into the data
    // Do the funny zigzag scan
    for (let right = this.size - 1; right >= 1; right -= 2) {  // Index of right column in each column pair
      if (right == 6) {
        right = 5;
      }
      for (let vert = 0; vert < this.size; vert++) {  // Vertical counter
        for (let j = 0; j < 2; j++) {
          const x: number = right - j;  // Actual x coordinate
          const upward: boolean = ((right + 1) & 2) == 0;
          const y: number = upward ? this.size - 1 - vert : vert;  // Actual y coordinate
          if (!this.isFunction[y][x] && i < data.length * 8) {
            this.modules[y][x] = getBit(data[i >>> 3], 7 - (i & 7));
            i++;
          }
          // If this QR Code has any remainder bits (0 to 7), they were assigned as
          // 0/false/white by the constructor and are left unchanged by this method
        }
      }
    }
    if (i != data.length * 8) {
      throw new RangeError("Assertion error");
    }
  }

  // XORs the codeword modules in this QR Code with the given mask pattern.
  // The function modules must be marked and the codeword bits must be drawn
  // before masking. Due to the arithmetic of XOR, calling applyMask() with
  // the same mask value a second time will undo the mask. A final well-formed
  // QR Code needs exactly one (not zero, two, etc.) mask applied.
  private applyMask(mask: number): void {
    if (mask < 0 || mask > 7) {
      throw new RangeError("Mask value out of range");
    }
    for (let y = 0; y < this.size; y++) {
      for (let x = 0; x < this.size; x++) {
        let invert: boolean;
        switch (mask) {
          case 0:  invert = (x + y) % 2 == 0;                                    break;
          case 1:  invert = y % 2 == 0;                                          break;
          case 2:  invert = x % 3 == 0;                                          break;
          case 3:  invert = (x + y) % 3 == 0;                                    break;
          case 4:  invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0;    break;
          case 5:  invert = x * y % 2 + x * y % 3 == 0;                          break;
          case 6:  invert = (x * y % 2 + x * y % 3) % 2 == 0;                    break;
          case 7:  invert = ((x + y) % 2 + x * y % 3) % 2 == 0;                  break;
          default:  throw new Error("Unreachable");
        }
        if (!this.isFunction[y][x] && invert) {
          this.modules[y][x] = !this.modules[y][x];
        }
      }
    }
  }

  // Calculates and returns the penalty score based on state of this QR Code's current modules.
  // This is used by the automatic mask choice algorithm to find the mask pattern that yields the lowest score.
  private getPenaltyScore(): number {
    let result: number = 0;
    
    // Adjacent modules in row having same color, and finder-like patterns
    for (let y = 0; y < this.size; y++) {
      let runColor = false;
      let runX = 0;
      const runHistory = [0, 0, 0, 0, 0, 0, 0];
      for (let x = 0; x < this.size; x++) {
        if (this.modules[y][x] == runColor) {
          runX++;
          if (runX == 5) {
            result += QrCode.PENALTY_N1;
          } else if (runX > 5) {
            result++;
          }
        } else {
          this.finderPenaltyAddHistory(runX, runHistory);
          if (!runColor) {
            result += this.finderPenaltyCountPatterns(runHistory) * QrCode.PENALTY_N3;
          }
          runColor = this.modules[y][x];
          runX = 1;
        }
      }
      result += this.finderPenaltyTerminateAndCount(runColor, runX, runHistory) * QrCode.PENALTY_N3;
    }
    // Adjacent modules in column having same color, and finder-like patterns
    for (let x = 0; x < this.size; x++) {
      let runColor = false;
      let runY = 0;
      const runHistory = [0, 0, 0, 0, 0, 0, 0];
      for (let y = 0; y < this.size; y++) {
        if (this.modules[y][x] == runColor) {
          runY++;
          if (runY == 5) {
            result += QrCode.PENALTY_N1;
          } else if (runY > 5) {
            result++;
          }
        } else {
          this.finderPenaltyAddHistory(runY, runHistory);
          if (!runColor) {
            result += this.finderPenaltyCountPatterns(runHistory) * QrCode.PENALTY_N3;
          }
          runColor = this.modules[y][x];
          runY = 1;
        }
      }
      result += this.finderPenaltyTerminateAndCount(runColor, runY, runHistory) * QrCode.PENALTY_N3;
    }
    
    // 2*2 blocks of modules having same color
    for (let y = 0; y < this.size - 1; y++) {
      for (let x = 0; x < this.size - 1; x++) {
        const color: boolean = this.modules[y][x];
        if (color == this.modules[y][x + 1] &&
            color == this.modules[y + 1][x] &&
            color == this.modules[y + 1][x + 1]) {
          result += QrCode.PENALTY_N2;
        }
      }
    }
    
    // Balance of black and white modules
    let black: number = 0;
    for (const row of this.modules) {
      for (const color of row) {
        if (color) {
          black++;
        }
      }
    }
    const total: number = this.size * this.size;  // Note that size is odd, so black/total will never be exactly 0.5
    // Compute the smallest integer k >= 0 such that (45-5k)% <= black/total <= (55+5k)%
    const k: number = Math.ceil(Math.abs(black * 20 - total * 10) / total) - 1;
    result += k * QrCode.PENALTY_N4;
    return result;
  }

  // Returns an ascending list of positions of alignment patterns for this version number.
  // Each position is in the range [0,177), and are used on both the x and y axes.
  // This could be implemented as lookup table of 40 variable-length lists of integers.
  private getAlignmentPatternPositions(): Array<number> {
    if (this.version == 1) {
      return [];
    }
    const numAlign = Math.floor(this.version / 7) + 2;
    const step = (this.version == 32) ? 26 :
      Math.ceil((this.size - 13) / (2 * numAlign - 2)) * 2;
    const result: Array<number> = [6];
    for (let pos = this.size - 7; result.length < numAlign; pos -= step) {
      result.splice(1, 0, pos);
    }
    return result;
  }

  // Can only be called immediately after a white run is added, and
  // returns either 0, 1, or 2. A helper function for getPenaltyScore().
  private finderPenaltyCountPatterns(runHistory: Readonly<Array<number>>): number {
    const n: number = runHistory[1];
    if (n > this.size * 3) {
      throw new Error("Assertion error");
    }
    const core: boolean = n > 0 && runHistory[2] == n && runHistory[3] == n * 3 && runHistory[4] == n && runHistory[5] == n;
    return (core && runHistory[0] >= n * 4 && runHistory[6] >= n ? 1 : 0)
       + (core && runHistory[6] >= n * 4 && runHistory[0] >= n ? 1 : 0);
  }

  // Must be called at the end of a line (row or column) of modules. A helper function for getPenaltyScore().
  private finderPenaltyTerminateAndCount(currentRunColor: boolean, currentRunLength: number, runHistory: Array<number>): number {
    if (currentRunColor) {  // Terminate black run
      this.finderPenaltyAddHistory(currentRunLength, runHistory);
      currentRunLength = 0;
    }
    currentRunLength += this.size;  // Add white border to final run
    this.finderPenaltyAddHistory(currentRunLength, runHistory);
    return this.finderPenaltyCountPatterns(runHistory);
  }

  // Pushes the given value to the front and drops the last value. A helper function for getPenaltyScore().
  private finderPenaltyAddHistory(currentRunLength: number, runHistory: Array<number>): void {
    if (runHistory[0] == 0) {
      currentRunLength += this.size;  // Add white border to initial run
    }
    runHistory.pop();
    runHistory.unshift(currentRunLength);
  }

  // Calculates and returns the penalty score for specific mask.
  // This is a helper function for getPenaltyScore().
  private calculateForMask(mask: number): number {
    return 0; // Temporarily returning 0
  }
}

// Appends the given number of low-order bits of the given value to the given buffer.
// Requires 0 <= len <= 31 and 0 <= val < 2^len.
function appendBits(val: number, len: number, bb: Array<number>): void {
  if (len < 0 || len > 31 || val >>> len != 0) {
    throw new RangeError("Value out of range");
  }
  for (let i = len - 1; i >= 0; i--) {  // Append bit by bit
    bb.push((val >>> i) & 1);
  }
}

// Returns true iff the i'th bit of x is set to 1.
function getBit(x: number, i: number): boolean {
  return ((x >>> i) & 1) != 0;
}

// Returns the number of bytes needed to represent the given bits array.
function getByteLength(bits: Array<number>): number {
  return Math.ceil(bits.length / 8);
}

// Returns a new byte array representing the given bits array.
function getBytes(bits: Array<number>): Array<number> {
  const result = new Array<number>(getByteLength(bits));
  for (let i = 0; i < result.length; i++) {
    result[i] = 0;
  }
  for (let i = 0; i < bits.length; i++) {
    result[i >>> 3] |= bits[i] << (7 - (i & 7));
  }
  return result;
}

// Returns a byte array of length 1 containing the given byte value.
function getBytes8(x: number): Array<number> {
  if (x < 0 || x > 255) {
    throw new RangeError("Byte value out of range");
  }
  return [x];
}

// Returns the byte at the given bit index.
function getByte(bits: Array<number>, index: number): number {
  if (index < 0 || index > bits.length - 8) {
    throw new RangeError("Index out of range");
  }
  let result = 0;
  for (let i = 0; i < 8; i++) {
    result = (result << 1) | bits[index + i];
  }
  return result;
}

// The error correction level in a QR Code symbol.
export class Ecc {
  /*-- Constants --*/
  
  // Must be declared in ascending order of error protection.
  public static readonly LOW      = new Ecc(0, 1, "L");  // The QR Code can tolerate about  7% erroneous codewords
  public static readonly MEDIUM   = new Ecc(1, 0, "M");  // The QR Code can tolerate about 15% erroneous codewords
  public static readonly QUARTILE = new Ecc(2, 3, "Q");  // The QR Code can tolerate about 25% erroneous codewords
  public static readonly HIGH     = new Ecc(3, 2, "H");  // The QR Code can tolerate about 30% erroneous codewords
  
  /*-- Constructor and fields --*/
  
  private constructor(
    // In the range 0 to 3 (unsigned 2-bit integer).
    public readonly ordinal: number,
    // (Package-private) In the range 0 to 3 (unsigned 2-bit integer).
    public readonly formatBits: number,
    // The name of this ECC level.
    public readonly name: string,
  ) {}
}

// A segment of character/binary/control data in a QR Code symbol.
// Instances of this class are immutable.
export class QrSegment {
  
  /*-- Static factory functions --*/
  
  // Returns a segment representing the given binary data.
  // All input array elements must be in the range [0, 255].
  public static makeBytes(data: Readonly<Array<number>>): QrSegment {
    const bb: Array<number> = [];
    for (const b of data) {
      appendBits(b, 8, bb);
    }
    return new QrSegment(Mode.BYTE, data.length, bb);
  }
  
  // Returns a segment representing the given string of decimal digits.
  public static makeNumeric(digits: string): QrSegment {
    if (!QrSegment.isNumeric(digits)) {
      throw new RangeError("String contains non-numeric characters");
    }
    const bb: Array<number> = [];
    for (let i = 0; i < digits.length; ) {  // Consume up to 3 digits per iteration
      const n: number = Math.min(digits.length - i, 3);
      appendBits(parseInt(digits.substring(i, i + n), 10), n * 3 + 1, bb);
      i += n;
    }
    return new QrSegment(Mode.NUMERIC, digits.length, bb);
  }
  
  // Returns a segment representing the given text string. The characters are sent to this method in order.
  public static makeAlphanumeric(text: string): QrSegment {
    if (!QrSegment.isAlphanumeric(text)) {
      throw new RangeError("String contains unencodable characters in alphanumeric mode");
    }
    const bb: Array<number> = [];
    let i: number;
    for (i = 0; i + 2 <= text.length; i += 2) {  // Process groups of 2
      let temp: number = QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)) * 45;
      temp += QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i + 1));
      appendBits(temp, 11, bb);
    }
    if (i < text.length) {  // 1 character remaining
      appendBits(QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)), 6, bb);
    }
    return new QrSegment(Mode.ALPHANUMERIC, text.length, bb);
  }
  
  // Returns a new mutable list of zero or more segments to represent the given Unicode text string.
  // The result may use various segment modes and switch modes to optimize the length of the bit stream.
  public static makeSegments(text: string): Array<QrSegment> {
    // Select the most efficient segment encoding automatically
    if (text == "") {
      return [];
    } else if (QrSegment.isNumeric(text)) {
      return [QrSegment.makeNumeric(text)];
    } else if (QrSegment.isAlphanumeric(text)) {
      return [QrSegment.makeAlphanumeric(text)];
    } else {
      return [QrSegment.makeBytes(QrSegment.toUtf8ByteArray(text))];
    }
  }
  
  // Returns a segment representing an Extended Channel Interpretation
  // (ECI) designator with the given assignment value.
  public static makeEci(assignVal: number): QrSegment {
    const bb: Array<number> = [];
    if (assignVal < 0) {
      throw new RangeError("ECI assignment value out of range");
    } else if (assignVal < (1 << 7)) {
      appendBits(assignVal, 8, bb);
    } else if (assignVal < (1 << 14)) {
      appendBits(0b10, 2, bb);
      appendBits(assignVal, 14, bb);
    } else if (assignVal < 1000000) {
      appendBits(0b110, 3, bb);
      appendBits(assignVal, 21, bb);
    } else {
      throw new RangeError("ECI assignment value out of range");
    }
    return new QrSegment(Mode.ECI, 0, bb);
  }
  
  // Tests whether the given string can be encoded as a segment in numeric mode.
  // A string is encodable iff each character is in the range 0 to 9.
  public static isNumeric(text: string): boolean {
    return QrSegment.NUMERIC_REGEX.test(text);
  }
  
  // Tests whether the given string can be encoded as a segment in alphanumeric mode.
  // A string is encodable iff each character is in the following set: 0 to 9, A to Z
  // (uppercase only), space, dollar, percent, asterisk, plus, hyphen, period, slash, colon.
  public static isAlphanumeric(text: string): boolean {
    return QrSegment.ALPHANUMERIC_REGEX.test(text);
  }
  
  // Returns the number of bytes needed for the data of the given segment.
  private static getTotalBits(segs: Readonly<Array<QrSegment>>, version: number): number {
    if (segs.length > 1 << 16) {
      throw new RangeError("Too many segments");
    }
    
    let result = 0;
    for (const seg of segs) {
      if (seg.mode.ordinal >= 4) {
        throw new Error("Invalid mode");
      }
      result += 4 + seg.mode.numCharCountBits(version);
      if (seg.numBits > (1 << 31) - result) {
        throw new RangeError("Data too long");
      }
      result += seg.numBits;
    }
    return result;
  }
  
  // Returns a new array of bytes representing the given string encoded in UTF-8.
  private static toUtf8ByteArray(str: string): Array<number> {
    str = encodeURI(str);
    const result: Array<number> = [];
    for (let i = 0; i < str.length; i++) {
      if (str.charAt(i) != "%") {
        result.push(str.charCodeAt(i));
      } else {
        result.push(parseInt(str.substring(i + 1, i + 3), 16));
        i += 2;
      }
    }
    return result;
  }
  
  
  /*-- Constants --*/
  
  // Describes precisely all strings that are encodable in numeric mode.
  private static readonly NUMERIC_REGEX: RegExp = /^[0-9]*$/;
  
  // Describes precisely all strings that are encodable in alphanumeric mode.
  private static readonly ALPHANUMERIC_REGEX: RegExp = /^[A-Z0-9 $%*+.\/:-]*$/;
  
  // The set of all legal characters in alphanumeric mode,
  // where each character value maps to the index in the string.
  private static readonly ALPHANUMERIC_CHARSET: string = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
  
  
  /*-- Constructor (low level) and fields --*/
  
  // Creates a new QR Code segment with the given attributes and data.
  // The character count (numChars) must agree with the mode and the bit buffer length,
  // but the constraint isn't checked. The given bit buffer is cloned and stored.
  public constructor(
    // The mode indicator of this segment.
    public readonly mode: Mode,
    
    // The length of this segment's unencoded data. Measured in characters for
    // numeric/alphanumeric/kanji mode, bytes for byte mode, and 0 for ECI mode.
    // Always zero or positive. Not the same as the data's bit length.
    public readonly numChars: number,
    
    // The data bits of this segment. Accessed through getData().
    private readonly bitData: Array<number>,
  ) {
    if (numChars < 0) {
      throw new RangeError("Invalid argument");
    }
    this.bitData = bitData.slice();  // Make defensive copy
  }
  
  
  /*-- Methods --*/
  
  // Returns a new copy of the data bits of this segment.
  public getData(): Array<number> {
    return this.bitData.slice();  // Make defensive copy
  }
  
  // (Package-private) Returns the data length of this segment measured in bits.
  public get numBits(): number {
    return this.bitData.length;
  }
}

// Describes how a segment's data bits are interpreted.
export class Mode {
  
  /*-- Constants --*/
  
  public static readonly NUMERIC      = new Mode(0x1, [10, 12, 14]);
  public static readonly ALPHANUMERIC = new Mode(0x2, [ 9, 11, 13]);
  public static readonly BYTE         = new Mode(0x4, [ 8, 16, 16]);
  public static readonly KANJI        = new Mode(0x8, [ 8, 10, 12]);
  public static readonly ECI          = new Mode(0x7, [ 0,  0,  0]);
  
  
  /*-- Constructor and fields --*/
  
  private constructor(
    // The mode indicator bits, which is a uint4 value (range 0 to 15).
    public readonly modeBits: number,
    // Number of character count bits for three different version ranges.
    private readonly numBitsCharCount: [number,number,number],
  ) {}
  
  
  /*-- Method --*/
  
  // (Package-private) Returns the bit width of the character count field for a segment in
  // this mode in a QR Code at the given version number. The result is in the range [0, 16].
  public numCharCountBits(ver: number): number {
    return this.numBitsCharCount[Math.floor((ver + 7) / 17)];
  }
  
  public get ordinal(): number {
    return this.modeBits;
  }
}

/**
 * QR Code rendering function for SVG output.
 * @param {string} data The text or URL to encode in the QR code
 * @param {Object} options Configuration options for QR code
 * @returns {string} SVG string representation of the QR code
 */
export function renderQrCodeSvg(data: string, options: { 
  size?: number; 
  margin?: number;
  level?: Ecc;
  includeSvgTag?: boolean;
  className?: string;
} = {}): string {
  const { 
    size = 174, // 46mm at 96dpi - This is the required size for Swiss QR bills
    margin = 0,
    level = Ecc.MEDIUM,
    includeSvgTag = true,
    className = ''
  } = options;
  
  // Create the QR code
  const qrCode = QrCode.encodeText(data, level);
  const qrSize = qrCode.getSize();
  const moduleSize = (size - 2 * margin) / qrSize;
  
  // Generate SVG path
  let path = '';
  for (let y = 0; y < qrSize; y++) {
    for (let x = 0; x < qrSize; x++) {
      if (qrCode.getModule(x, y)) {
        const left = x * moduleSize + margin;
        const top = y * moduleSize + margin;
        path += `M${left},${top}h${moduleSize}v${moduleSize}h-${moduleSize}z `;
      }
    }
  }
  
  // Return just the SVG path if includeSvgTag is false
  if (!includeSvgTag) {
    return path;
  }
  
  // Return complete SVG
  const svgString = `<svg 
    xmlns="http://www.w3.org/2000/svg" 
    version="1.1" 
    viewBox="0 0 ${size} ${size}" 
    stroke="none" 
    width="${size}" 
    height="${size}"
    ${className ? `class="${className}"` : ''}
  >
    <rect width="100%" height="100%" fill="white"/>
    <path d="${path}" fill="black"/>
  </svg>`;
  
  return svgString;
}

/**
 * Returns a configuration object specifically for Swiss QR bills.
 * These settings follow the official Swiss QR Bill specifications.
 */
export function getSwissQrCodeConfig() {
  return {
    size: 174, // 46mm at 96dpi - Swiss QR bill standard
    level: Ecc.MEDIUM, // Medium error correction as required
    margin: 0, // No margin as the QR bill has its own quiet zone
  };
}
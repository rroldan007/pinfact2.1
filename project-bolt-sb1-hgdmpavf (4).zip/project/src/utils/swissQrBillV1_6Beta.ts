/**
 * Swiss QR Bill Utilities - Version 1.6 Beta
 * 
 * This is a snapshot of the Swiss QR Bill implementation at version 1.6 Beta.
 * It's kept as a backup to ensure we can revert to this version if needed.
 */

import { format } from 'date-fns';

// Type for our invoice data needed to generate a QR bill
export interface QrBillData {
  invoiceNumber: string;
  amount: number;
  currency: string;
  creditorName: string;
  creditorAddress: string;
  creditorPostalCode: string;
  creditorCity: string;
  creditorCountry: string;
  creditorIban: string;
  debtorName?: string;
  debtorAddress?: string;
  debtorPostalCode?: string;
  debtorCity?: string;
  debtorCountry?: string;
  message?: string;
}

/**
 * Format amounts for Swiss QR bill per specification
 * Must be formatted as #.## with two decimal places and no thousands separators
 */
const formatAmount = (amount: number): string => {
  return amount.toFixed(2);
};

/**
 * Format IBAN for Swiss QR bill (remove spaces)
 */
const formatIban = (iban: string): string => {
  return iban.replace(/\s/g, '');
};

/**
 * Calculate the check digit for a QR reference number
 * Based on Modulo 10 recursive algorithm used in Switzerland
 */
const calculateQrReferenceCheckDigit = (reference: string): string => {
  // Table for the recursive modulo 10
  const table = [0, 9, 4, 6, 8, 2, 7, 1, 3, 5];
  let carry = 0;
  
  // Process each digit
  for (let i = 0; i < reference.length; i++) {
    const digit = parseInt(reference.charAt(i), 10);
    carry = table[(carry + digit) % 10];
  }
  
  return ((10 - carry) % 10).toString();
};

/**
 * Generate a valid QR reference number from an invoice number
 * Must be numeric only, 26 digits plus 1 check digit
 */
const generateQrReference = (invoiceNumber: string): string => {
  // Extract digits only
  const numericOnly = invoiceNumber.replace(/\D/g, '');
  
  // Pad with leading zeros to 26 digits
  const reference = numericOnly.padStart(26, '0');
  
  // Calculate and append check digit
  const checkDigit = calculateQrReferenceCheckDigit(reference);
  
  return reference + checkDigit;
};

/**
 * Generate the Swiss QR Code content string according to Swiss Payments standards (SPC)
 * Implementation based on https://github.com/manuelbl/SwissQRBill
 * @see https://www.paymentstandards.ch/dam/downloads/ig-qr-bill-en.pdf
 */
export const generateQrCodeContent = (data: QrBillData): string => {
  try {
    // Format IBAN (remove spaces)
    const iban = formatIban(data.creditorIban);
    
    // Determine if it's a QR-IBAN (range 30000-31999 in positions 5-9)
    const isQrIban = iban.startsWith('CH') && 
                      parseInt(iban.substring(4, 9), 10) >= 30000 && 
                      parseInt(iban.substring(4, 9), 10) <= 31999;
    
    // Format amount
    const amount = formatAmount(data.amount);

    // Format the creditor and debtor addresses following SIX rules
    const formatAddress = (address: string | undefined) => {
      return address ? address.replace(/\n/g, ' ').substring(0, 70) : '';
    };

    // Always use NON for reference type and an empty string for the reference
    // This is a test to see if it fixes bank scanning issues
    const referenceType = 'NON';
    const reference = '';

    // Prepare QR code data elements according to Swiss Payment Standards 2019
    const qrCodeData = [
      // Header elements - mandatory and fixed
      'SPC',                                             // QR Type - fixed value
      '0200',                                            // Version - fixed value for version 2.0
      '1',                                               // Coding Type - fixed value
      
      // Creditor information - mandatory
      iban,                                              // IBAN - no spaces
      'K',                                               // Creditor address type (K for structured)
      data.creditorName.substring(0, 70),                // Creditor name (max 70 chars)
      formatAddress(data.creditorAddress),               // Creditor address (max 70 chars)
      `${data.creditorPostalCode} ${data.creditorCity}`, // Creditor postal code and city
      '',                                                // Empty field - REQUIRED by spec
      data.creditorCountry,                              // Creditor country code (2 letters)
      
      // Additional information (2 blocks) - all empty for standard usage
      '',                                                // Alternative procedure block 1 - name
      '',                                                // Alternative procedure block 1 - value
      '',                                                // Alternative procedure block 2 - name
      '',                                                // Alternative procedure block 2 - value 1
      '',                                                // Alternative procedure block 2 - value 2
      '',                                                // Alternative procedure block 2 - value 3
      '',                                                // Alternative procedure block 2 - value 4
      
      // Payment information - mandatory if amount is known
      amount,                                            // Amount - always with 2 decimal places
      data.currency,                                     // Currency - CHF or EUR
      
      // Debtor information - optional
      data.debtorName ? 'K' : '',                        // Debtor address type (K if present)
      data.debtorName ? data.debtorName.substring(0, 70) : '', // Debtor name
      formatAddress(data.debtorAddress),                 // Debtor address
      data.debtorPostalCode && data.debtorCity ? 
        `${data.debtorPostalCode} ${data.debtorCity}` : '', // Debtor postal code and city
      '',                                                // Empty field - REQUIRED by spec
      data.debtorCountry || '',                          // Debtor country code
      
      // Reference information - mandatory depending on IBAN type
      referenceType,                                     // Reference type (QRR, SCOR or NON)
      reference,                                         // Reference value - EMPTY FOR TESTING
      
      // Additional unstructured message and trailer - optional
      '',                                                // Unstructured message - EMPTY FOR TESTING
      'EPD'                                              // Trailer for end of payment data
    ];

    // Join all elements with line breaks (CRLF according to spec)
    return qrCodeData.join('\r\n');
  } catch (error) {
    console.error('Error generating Swiss QR bill content:', error);
    throw new Error('Failed to generate Swiss QR bill content');
  }
};

/**
 * Get QR code styles for Swiss QR Bill according to specification
 * - Must be exactly 46x46mm in size
 * - Must have Swiss cross in the center
 * - Must have 5mm quiet zone around it
 */
export const getQrCodeStyles = () => {
  return {
    width: 174,       // 46mm at 96dpi
    height: 174,      // 46mm at 96dpi
    level: 'M' as 'L' | 'M' | 'Q' | 'H',  // Medium error correction
    bgColor: "#FFFFFF",
    fgColor: "#000000",
  };
};

/**
 * Generate a Swiss QR Bill paper format template
 */
export const generateQrBillTemplate = (data: QrBillData): any => {
  const formatCurrency = (amount: number): string => {
    return amount.toFixed(2);
  };

  // Generate QR code content string according to Swiss payment standards
  const qrCodeValue = generateQrCodeContent(data);

  // Format IBAN for display (CH12 3456 7890 1234 5678 9)
  const formatIbanForDisplay = (iban: string): string => {
    const cleanIban = iban.replace(/\s/g, '');
    return cleanIban.match(/.{1,4}/g)?.join(' ') || cleanIban;
  };

  // Generate QR reference if it's a QR IBAN
  const iban = formatIban(data.creditorIban);
  const isQrIban = iban.startsWith('CH') && 
                   parseInt(iban.substring(4, 9), 10) >= 30000 && 
                   parseInt(iban.substring(4, 9), 10) <= 31999;
  
  const reference = ''; // Empty reference for testing

  return {
    qrCodeValue,
    amount: formatCurrency(data.amount),
    currency: data.currency || 'CHF',
    creditorName: data.creditorName,
    creditorAddress: data.creditorAddress,
    creditorPostalCode: data.creditorPostalCode,
    creditorCity: data.creditorCity,
    creditorCountry: data.creditorCountry,
    creditorIban: formatIbanForDisplay(data.creditorIban),
    debtorName: data.debtorName,
    debtorAddress: data.debtorAddress,
    debtorPostalCode: data.debtorPostalCode,
    debtorCity: data.debtorCity,
    debtorCountry: data.debtorCountry,
    reference: reference,
    message: '', // Empty message for testing
    isQrIban: isQrIban
  };
};
/**
 * Wrapper for qrinvoice-cpp WebAssembly module
 * 
 * This file provides TypeScript functions to interact with the qrinvoice-cpp
 * WASM library for generating Swiss QR bills
 */

// Define the interface for the QRInvoice module
interface QRInvoiceModule {
  _generateSwissQRCode: (
    amount: number, 
    currency: string, 
    iban: string, 
    creditorName: string,
    creditorAddress: string,
    creditorCity: string,
    creditorPostal: string,
    creditorCountry: string,
    reference: string,
    message: string,
    debtorName: string,
    debtorAddress: string,
    debtorCity: string,
    debtorPostal: string,
    debtorCountry: string
  ) => number;
  
  _getQRCodeData: () => number;
  _getQRCodeDataSize: () => number;
  HEAPU8: Uint8Array;
  _malloc: (size: number) => number;
  _free: (ptr: number) => void;
  stringToUTF8: (str: string, outPtr: number, maxBytesToWrite: number) => void;
  UTF8ToString: (ptr: number, maxBytesToWrite?: number) => string;
}

// Global module instance
let qrinvoiceModule: QRInvoiceModule | null = null;

/**
 * Initialize the QRInvoice WASM module
 * @returns Promise that resolves when the module is ready
 */
export const initQRInvoiceModule = async (): Promise<void> => {
  if (qrinvoiceModule) {
    return; // Already initialized
  }
  
  try {
    // Check if we're in a browser environment
    if (typeof window === 'undefined') {
      throw new Error('QRInvoice module can only be initialized in a browser environment');
    }
    
    // Load the WASM module
    // @ts-ignore
    qrinvoiceModule = await import('/lib/qrinvoice.js');
    
    console.log('QRInvoice WASM module loaded successfully');
  } catch (error) {
    console.error('Failed to initialize QRInvoice WASM module:', error);
    throw new Error('Failed to initialize QRInvoice module');
  }
};

/**
 * Check if the QRInvoice module is initialized
 * @returns True if initialized, false otherwise
 */
export const isQRInvoiceModuleInitialized = (): boolean => {
  return qrinvoiceModule !== null;
};

/**
 * Generate a Swiss QR code using the qrinvoice-cpp library
 * @param params Parameters for the QR code
 * @returns QR code data as string
 */
export const generateSwissQRCode = (params: {
  amount: number;
  currency: string;
  iban: string;
  creditorName: string;
  creditorAddress: string;
  creditorCity: string;
  creditorPostal: string;
  creditorCountry: string;
  reference?: string;
  message?: string;
  debtorName?: string;
  debtorAddress?: string;
  debtorCity?: string;
  debtorPostal?: string;
  debtorCountry?: string;
}): string => {
  if (!qrinvoiceModule) {
    throw new Error('QRInvoice module not initialized. Call initQRInvoiceModule first.');
  }
  
  // Call the C++ function
  const result = qrinvoiceModule._generateSwissQRCode(
    params.amount,
    params.currency || 'CHF',
    params.iban,
    params.creditorName,
    params.creditorAddress || '',
    params.creditorCity || '',
    params.creditorPostal || '',
    params.creditorCountry || 'CH',
    params.reference || '',
    params.message || '',
    params.debtorName || '',
    params.debtorAddress || '',
    params.debtorCity || '',
    params.debtorPostal || '',
    params.debtorCountry || ''
  );
  
  if (result === 0) {
    throw new Error('Failed to generate Swiss QR code');
  }
  
  // Get the QR code data
  const dataPtr = qrinvoiceModule._getQRCodeData();
  const dataSize = qrinvoiceModule._getQRCodeDataSize();
  
  // Convert the data to a string
  const qrCodeData = qrinvoiceModule.UTF8ToString(dataPtr, dataSize);
  
  return qrCodeData;
};

/**
 * Generate a Swiss QR code SVG using the qrinvoice-cpp library
 * @param params Parameters for the QR code
 * @returns QR code as SVG string
 */
export const generateSwissQRCodeSVG = async (params: {
  amount: number;
  currency: string;
  iban: string;
  creditorName: string;
  creditorAddress: string;
  creditorCity: string;
  creditorPostal: string;
  creditorCountry: string;
  reference?: string;
  message?: string;
  debtorName?: string;
  debtorAddress?: string;
  debtorCity?: string;
  debtorPostal?: string;
  debtorCountry?: string;
}): Promise<string> => {
  try {
    // Make sure the module is initialized
    if (!isQRInvoiceModuleInitialized()) {
      await initQRInvoiceModule();
    }
    
    // Generate the QR code data
    const qrCodeData = generateSwissQRCode(params);
    
    // We would normally convert this to SVG here, but since we're using 
    // qrcode.react in the UI, we'll just return the data
    return qrCodeData;
  } catch (error) {
    console.error('Error generating Swiss QR code SVG:', error);
    throw error;
  }
};
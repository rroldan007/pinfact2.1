import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  Package,
  FileText,
  LogOut,
  Users,
  Menu,
  X,
  FileCheck
} from 'lucide-react';
import { supabase } from '../lib/supabase';

const navigation = [
  { name: 'Dashboard', href: '/app', icon: LayoutDashboard },
  { name: 'Company Profile', href: '/app/company', icon: Building2 },
  { name: 'Clients', href: '/app/clients', icon: Users },
  { name: 'Products', href: '/app/products', icon: Package },
  { name: 'Quotes', href: '/app/quotes', icon: FileCheck },
  { name: 'Invoices', href: '/app/invoices', icon: FileText },
];

export const Layout = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [pageLoadTime, setPageLoadTime] = useState<number | null>(null);

  useEffect(() => {
    // Measure page load time
    const loadTime = window.performance.timing.domContentLoadedEventEnd - 
                    window.performance.timing.navigationStart;
    setPageLoadTime(loadTime);
    
    // Add performance observer to track slow operations
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.duration > 100) {
            console.log(`Slow operation detected: ${entry.name} took ${entry.duration}ms`);
          }
        }
      });
      observer.observe({ entryTypes: ['measure', 'resource'] });
      
      return () => {
        observer.disconnect();
      };
    }
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex h-screen">
        {/* Mobile menu button */}
        <div className="md:hidden fixed top-0 left-0 w-full bg-white z-10 flex items-center p-4 border-b border-gray-200">
          <button
            type="button"
            className="text-gray-500 hover:text-gray-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
          <div className="ml-4 flex items-center">
            <FileText className="h-6 w-6 text-indigo-600" />
            <span className="ml-2 text-lg font-bold text-gray-900">
              InvoiceApp
            </span>
          </div>
        </div>
        
        {/* Mobile sidebar */}
        <div className={`fixed inset-0 z-40 md:hidden transform ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out`}>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white pt-5 pb-4">
            <div className="flex items-center flex-shrink-0 px-4">
              <FileText className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">
                InvoiceApp
              </span>
            </div>
            <div className="mt-5 flex-1 h-0 overflow-y-auto">
              <nav className="px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`${
                        location.pathname === item.href
                          ? 'bg-indigo-50 text-indigo-600'
                          : 'text-gray-600 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Icon
                        className={`${
                          location.pathname === item.href
                            ? 'text-indigo-600'
                            : 'text-gray-400 group-hover:text-gray-500'
                        } mr-4 h-6 w-6`}
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
              <button
                onClick={handleSignOut}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <LogOut className="h-6 w-6 mr-3" />
                Sign out
              </button>
            </div>
          </div>
          <div className="flex-shrink-0 w-14" onClick={() => setMobileMenuOpen(false)}></div>
        </div>

        {/* Desktop sidebar */}
        <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
          <div className="flex flex-col flex-grow pt-5 bg-white overflow-y-auto">
            <div className="flex items-center flex-shrink-0 px-4">
              <FileText className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">
                InvoiceApp
              </span>
            </div>
            <div className="mt-5 flex-grow flex flex-col">
              <nav className="flex-1 px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`${
                        location.pathname === item.href || location.pathname.startsWith(item.href + '/')
                          ? 'bg-indigo-50 text-indigo-600'
                          : 'text-gray-600 hover:bg-gray-50'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <Icon
                        className={`${
                          location.pathname === item.href || location.pathname.startsWith(item.href + '/')
                            ? 'text-indigo-600'
                            : 'text-gray-400 group-hover:text-gray-500'
                        } mr-3 h-5 w-5`}
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
              <button
                onClick={handleSignOut}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Sign out
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="md:pl-64 flex flex-col flex-1">
          <div className="md:hidden h-16"></div> {/* Spacer for mobile menu */}
          <main className="flex-1 p-6">
            <Outlet />
          </main>
          
          {/* Performance debug indicator - only visible in development */}
          {process.env.NODE_ENV === 'development' && pageLoadTime && (
            <div className="fixed bottom-0 right-0 bg-gray-800 text-white text-xs p-1 opacity-75">
              Page load: {pageLoadTime}ms
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { format } from 'date-fns';

type InvoiceTemplateProps = {
  invoice: any;
  logoUrl?: string | null;
};

export const ClassicTemplate: React.FC<InvoiceTemplateProps> = ({ invoice, logoUrl }) => {
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="bg-white p-6 max-w-4xl mx-auto text-sm" id="invoice-template">
      <div className="flex justify-between items-start mb-8">
        <div>
          {logoUrl && (
            <div className="mb-4">
              <img src={logoUrl} alt="Company Logo" className="h-12 object-contain" />
            </div>
          )}
          <h1 className="text-gray-900 text-xl font-bold">INVOICE</h1>
          <p className="text-gray-600 text-sm mt-1">{invoice.invoice_number}</p>
        </div>
        
        <div className="text-right">
          <div className="text-gray-700 text-sm">
            <p className="font-bold">{invoice.company?.company_name}</p>
            {invoice.company?.company_address && <p>{invoice.company.company_address}</p>}
            {(invoice.company?.company_postal_code || invoice.company?.company_city) && (
              <p>
                {invoice.company.company_postal_code} {invoice.company.company_city}
              </p>
            )}
            {invoice.company?.company_country && <p>{invoice.company.company_country}</p>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8 text-sm">
        <div>
          <h3 className="text-gray-600 text-xs uppercase font-bold mb-2">Bill To:</h3>
          <div className="text-gray-700">
            <p className="font-bold">{invoice.client?.name}</p>
            {invoice.client?.address && <p>{invoice.client.address}</p>}
            {(invoice.client?.postal_code || invoice.client?.city) && (
              <p>
                {invoice.client.postal_code} {invoice.client.city}
              </p>
            )}
            {invoice.client?.country && <p>{invoice.client.country}</p>}
            {invoice.client?.email && <p>{invoice.client.email}</p>}
          </div>
        </div>

        <div>
          <div className="grid grid-cols-2 gap-2 text-gray-700 text-sm">
            <div className="text-gray-600 text-xs uppercase font-bold">Invoice Date:</div>
            <div className="text-right">{formatDate(invoice.date)}</div>

            <div className="text-gray-600 text-xs uppercase font-bold">Due Date:</div>
            <div className="text-right">{formatDate(invoice.due_date)}</div>

            <div className="text-gray-600 text-xs uppercase font-bold">Status:</div>
            <div className="text-right capitalize">{invoice.status}</div>
          </div>
        </div>
      </div>

      <table className="w-full mb-8 text-sm">
        <thead>
          <tr className="text-left bg-gray-100">
            <th className="py-2 px-3 text-gray-600 text-xs uppercase font-bold">Description</th>
            <th className="py-2 px-3 text-gray-600 text-xs uppercase font-bold">Qty</th>
            <th className="py-2 px-3 text-gray-600 text-xs uppercase font-bold">Unit Price</th>
            <th className="py-2 px-3 text-gray-600 text-xs uppercase font-bold">Tax Rate</th>
            <th className="py-2 px-3 text-gray-600 text-xs uppercase font-bold text-right">Amount</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {invoice.items?.map((item: any) => (
            <tr key={item.id}>
              <td className="py-3 px-3">
                <div className="font-medium text-gray-900">{item.description}</div>
                {item.secondary_description && (
                  <div className="text-xs text-gray-500">{item.secondary_description}</div>
                )}
              </td>
              <td className="py-3 px-3 text-gray-600">{item.quantity}</td>
              <td className="py-3 px-3 text-gray-600">{item.unit_price.toFixed(2)}</td>
              <td className="py-3 px-3 text-gray-600">{item.tax_rate}%</td>
              <td className="py-3 px-3 text-gray-900 font-medium text-right">
                {item.total.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end mb-8">
        <div className="w-64">
          <div className="flex justify-between py-2 border-b border-gray-200 text-sm">
            <div className="text-gray-600">Subtotal:</div>
            <div className="text-gray-900">{invoice.subtotal.toFixed(2)}</div>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-200 text-sm">
            <div className="text-gray-600">Tax:</div>
            <div className="text-gray-900">{invoice.tax_amount.toFixed(2)}</div>
          </div>
          <div className="flex justify-between py-2 font-bold text-sm">
            <div>Total:</div>
            <div>CHF {invoice.total.toFixed(2)}</div>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-200 pt-4 text-sm">
        {invoice.notes && (
          <div className="mb-4">
            <div className="text-gray-600 text-xs uppercase font-bold mb-1">Notes:</div>
            <p className="text-xs text-gray-700">{invoice.notes}</p>
          </div>
        )}

        {invoice.terms && (
          <div className="mb-4">
            <div className="text-gray-600 text-xs uppercase font-bold mb-1">Terms & Conditions:</div>
            <p className="text-xs text-gray-700">{invoice.terms}</p>
          </div>
        )}

        {invoice.company?.company_iban && (
          <div className="mt-4">
            <div className="text-gray-600 text-xs uppercase font-bold mb-1">Payment Information:</div>
            <p className="text-xs text-gray-700">
              <span className="font-medium">IBAN:</span> {invoice.company.company_iban}
            </p>
          </div>
        )}
      </div>

      <div className="text-center text-gray-500 text-xs mt-8">
        Thank you for your business!
      </div>
    </div>
  );
};
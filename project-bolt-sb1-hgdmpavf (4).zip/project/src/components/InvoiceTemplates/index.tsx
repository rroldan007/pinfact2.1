import React from 'react';
import { ClassicTemplate } from './ClassicTemplate';
import { ModernTemplate } from './ModernTemplate';
import { MinimalTemplate } from './MinimalTemplate';
import { ProfessionalTemplate } from './ProfessionalTemplate';

type InvoiceTemplateRendererProps = {
  invoice: any;
  templateStyle: string;
  logoUrl?: string | null;
};

export const InvoiceTemplateRenderer: React.FC<InvoiceTemplateRendererProps> = ({ 
  invoice, 
  templateStyle,
  logoUrl 
}) => {
  switch(templateStyle) {
    case 'modern':
      return <ModernTemplate invoice={invoice} logoUrl={logoUrl} />;
    case 'minimal':
      return <MinimalTemplate invoice={invoice} logoUrl={logoUrl} />;
    case 'professional':
      return <ProfessionalTemplate invoice={invoice} logoUrl={logoUrl} />;
    case 'classic':
    default:
      return <ClassicTemplate invoice={invoice} logoUrl={logoUrl} />;
  }
};
import React from 'react';
import { format } from 'date-fns';

type InvoiceTemplateProps = {
  invoice: any;
  logoUrl?: string | null;
};

export const ProfessionalTemplate: React.FC<InvoiceTemplateProps> = ({ invoice, logoUrl }) => {
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      'paid': 'bg-green-100 text-green-800 border-green-200',
      'sent': 'bg-blue-100 text-blue-800 border-blue-200',
      'draft': 'bg-gray-100 text-gray-800 border-gray-200',
      'overdue': 'bg-red-100 text-red-800 border-red-200',
      'cancelled': 'bg-gray-100 text-gray-500 border-gray-200',
    };
    
    return (
      <span className={`inline-block px-2 py-1 text-xs font-medium rounded-md border ${colors[status] || colors.draft}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  return (
    <div className="bg-white p-6 max-w-4xl mx-auto border border-gray-200 text-sm" id="invoice-template">
      {/* Header */}
      <div className="flex justify-between items-start mb-8 border-b border-gray-200 pb-5">
        <div>
          {logoUrl && (
            <div className="mb-3">
              <img src={logoUrl} alt="Company Logo" className="h-14 object-contain" />
            </div>
          )}
          <h1 className="text-xl font-bold text-gray-800">{invoice.company?.company_name || 'Company Name'}</h1>
          <div className="text-gray-600 mt-1 text-xs">
            {invoice.company?.company_address && <p>{invoice.company.company_address}</p>}
            {(invoice.company?.company_postal_code || invoice.company?.company_city) && (
              <p>
                {invoice.company.company_postal_code} {invoice.company.company_city}
              </p>
            )}
            {invoice.company?.company_country && <p>{invoice.company.company_country}</p>}
            {invoice.company?.company_email && <p>Email: {invoice.company.company_email}</p>}
            {invoice.company?.company_phone && <p>Phone: {invoice.company.company_phone}</p>}
            {invoice.company?.company_vat_number && <p>VAT: {invoice.company.company_vat_number}</p>}
          </div>
        </div>
        
        <div className="text-right">
          <div className="inline-block bg-gray-900 text-white px-5 py-2 rounded">
            <h2 className="text-lg font-bold">INVOICE</h2>
            <p className="text-gray-300 text-xs mt-1">{invoice.invoice_number}</p>
          </div>
          <div className="mt-3">
            {getStatusBadge(invoice.status)}
          </div>
        </div>
      </div>

      {/* Invoice Info and Client */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-gray-800 font-bold text-xs mb-2 uppercase">Bill To</h3>
          <div className="bg-gray-50 p-3 rounded border border-gray-200 text-xs">
            <p className="font-bold text-gray-800">{invoice.client?.name}</p>
            {invoice.client?.address && <p>{invoice.client.address}</p>}
            {(invoice.client?.postal_code || invoice.client?.city) && (
              <p>
                {invoice.client.postal_code} {invoice.client.city}
              </p>
            )}
            {invoice.client?.country && <p>{invoice.client.country}</p>}
            {invoice.client?.email && <p className="mt-1">Email: {invoice.client.email}</p>}
            {invoice.client?.phone && <p>Phone: {invoice.client.phone}</p>}
          </div>
        </div>

        <div>
          <h3 className="text-gray-800 font-bold text-xs mb-2 uppercase">Invoice Details</h3>
          <div className="bg-gray-50 p-3 rounded border border-gray-200 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div className="text-gray-600">Invoice Date:</div>
              <div className="text-gray-800 font-medium">{formatDate(invoice.date)}</div>
              
              <div className="text-gray-600">Due Date:</div>
              <div className="text-gray-800 font-medium">{formatDate(invoice.due_date)}</div>
              
              <div className="text-gray-600 col-span-2 mt-2 pt-2 border-t border-gray-200">
                Payment Terms: {invoice.terms ? invoice.terms : 'Due by the due date'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-8">
        <h3 className="text-gray-800 font-bold text-xs mb-2 uppercase">Invoice Items</h3>
        <div className="border border-gray-200 rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-900 text-white">
                <th className="text-left px-3 py-2 font-semibold text-xs">Description</th>
                <th className="text-center px-3 py-2 font-semibold text-xs w-16">Qty</th>
                <th className="text-right px-3 py-2 font-semibold text-xs w-24">Unit Price</th>
                <th className="text-right px-3 py-2 font-semibold text-xs w-20">Tax Rate</th>
                <th className="text-right px-3 py-2 font-semibold text-xs w-28">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {invoice.items?.map((item: any, index: number) => (
                <tr key={item.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-3 py-2">
                    <div className="font-medium text-gray-800">{item.description}</div>
                    {item.secondary_description && (
                      <div className="text-xs text-gray-500 mt-0.5">{item.secondary_description}</div>
                    )}
                  </td>
                  <td className="px-3 py-2 text-center text-gray-700">{item.quantity}</td>
                  <td className="px-3 py-2 text-right text-gray-700">{item.unit_price.toFixed(2)}</td>
                  <td className="px-3 py-2 text-right text-gray-700">{item.tax_rate}%</td>
                  <td className="px-3 py-2 text-right font-medium text-gray-800">
                    CHF {item.total.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary */}
      <div className="flex justify-end mb-8">
        <div className="w-72">
          <div className="border border-gray-200 rounded overflow-hidden">
            <div className="bg-gray-50 px-3 py-2 border-b border-gray-200">
              <h3 className="text-gray-800 font-bold text-xs uppercase">Invoice Summary</h3>
            </div>
            <div className="p-3 text-xs">
              <div className="flex justify-between py-1">
                <div className="text-gray-600">Subtotal:</div>
                <div className="text-gray-800">CHF {invoice.subtotal.toFixed(2)}</div>
              </div>
              <div className="flex justify-between py-1">
                <div className="text-gray-600">Tax:</div>
                <div className="text-gray-800">CHF {invoice.tax_amount.toFixed(2)}</div>
              </div>
              <div className="flex justify-between py-1 font-bold border-t border-gray-200 mt-1 pt-1">
                <div className="text-gray-800">Total:</div>
                <div className="text-gray-900">CHF {invoice.total.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notes and Payment Info */}
      <div className="grid grid-cols-2 gap-5 mb-6 text-xs">
        {invoice.notes && (
          <div>
            <h3 className="text-gray-800 font-bold text-xs mb-1 uppercase">Notes</h3>
            <div className="bg-gray-50 p-3 rounded border border-gray-200 text-gray-600">
              {invoice.notes}
            </div>
          </div>
        )}
        
        {invoice.company?.company_iban && (
          <div>
            <h3 className="text-gray-800 font-bold text-xs mb-1 uppercase">Payment Information</h3>
            <div className="bg-gray-50 p-3 rounded border border-gray-200 text-gray-600">
              <p><span className="font-medium">IBAN:</span> {invoice.company.company_iban}</p>
              {invoice.company?.company_bic && (
                <p><span className="font-medium">BIC/SWIFT:</span> {invoice.company.company_bic}</p>
              )}
              {invoice.company?.company_bank && (
                <p><span className="font-medium">Bank:</span> {invoice.company.company_bank}</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 pt-4 text-center text-gray-500 text-xs">
        <p>Terms: Payment due within 30 days</p>
        <p className="mt-1">Thank you for your business!</p>
      </div>
    </div>
  );
};
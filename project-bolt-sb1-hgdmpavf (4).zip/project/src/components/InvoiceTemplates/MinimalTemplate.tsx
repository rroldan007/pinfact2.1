import React from 'react';
import { format } from 'date-fns';

type InvoiceTemplateProps = {
  invoice: any;
  logoUrl?: string | null;
};

export const MinimalTemplate: React.FC<InvoiceTemplateProps> = ({ invoice, logoUrl }) => {
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="bg-white p-6 max-w-4xl mx-auto font-sans text-sm" id="invoice-template">
      <div className="flex justify-between items-start mb-12">
        <div>
          {logoUrl && (
            <div className="mb-6">
              <img src={logoUrl} alt="Company Logo" className="h-10 object-contain" />
            </div>
          )}
        </div>
        
        <div className="text-right">
          <h1 className="text-gray-900 text-xl font-normal tracking-wide">INVOICE</h1>
          <p className="text-gray-500 text-sm mt-1">{invoice.invoice_number}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-10 mb-12">
        <div>
          <p className="text-gray-400 text-xs mb-1">FROM</p>
          <div className="text-gray-800 text-sm">
            <p className="font-medium">{invoice.company?.company_name}</p>
            {invoice.company?.company_address && <p>{invoice.company.company_address}</p>}
            {(invoice.company?.company_postal_code || invoice.company?.company_city) && (
              <p>
                {invoice.company.company_postal_code} {invoice.company.company_city}
              </p>
            )}
            {invoice.company?.company_country && <p>{invoice.company.company_country}</p>}
          </div>
        </div>

        <div>
          <p className="text-gray-400 text-xs mb-1">TO</p>
          <div className="text-gray-800 text-sm">
            <p className="font-medium">{invoice.client?.name}</p>
            {invoice.client?.address && <p>{invoice.client.address}</p>}
            {(invoice.client?.postal_code || invoice.client?.city) && (
              <p>
                {invoice.client.postal_code} {invoice.client.city}
              </p>
            )}
            {invoice.client?.country && <p>{invoice.client.country}</p>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-12">
        <div>
          <p className="text-gray-400 text-xs mb-1">ISSUE DATE</p>
          <p className="text-gray-800 text-sm">{formatDate(invoice.date)}</p>
        </div>
        <div>
          <p className="text-gray-400 text-xs mb-1">DUE DATE</p>
          <p className="text-gray-800 text-sm">{formatDate(invoice.due_date)}</p>
        </div>
        <div>
          <p className="text-gray-400 text-xs mb-1">STATUS</p>
          <p className="text-gray-800 text-sm capitalize">{invoice.status}</p>
        </div>
      </div>

      <table className="w-full mb-12">
        <thead>
          <tr className="text-left border-b border-gray-200">
            <th className="pb-2 text-gray-400 text-xs font-normal">DESCRIPTION</th>
            <th className="pb-2 text-gray-400 text-xs font-normal">QTY</th>
            <th className="pb-2 text-gray-400 text-xs font-normal">UNIT PRICE</th>
            <th className="pb-2 text-gray-400 text-xs font-normal">TAX</th>
            <th className="pb-2 text-gray-400 text-xs font-normal text-right">AMOUNT</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items?.map((item: any) => (
            <tr key={item.id} className="border-b border-gray-100">
              <td className="py-3">
                <div className="text-gray-800 text-sm">{item.description}</div>
                {item.secondary_description && (
                  <div className="text-xs text-gray-400">{item.secondary_description}</div>
                )}
              </td>
              <td className="py-3 text-gray-800 text-sm">{item.quantity}</td>
              <td className="py-3 text-gray-800 text-sm">{item.unit_price.toFixed(2)}</td>
              <td className="py-3 text-gray-800 text-sm">{item.tax_rate}%</td>
              <td className="py-3 text-gray-800 text-sm text-right">
                {item.total.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end mb-12">
        <div className="w-56">
          <div className="flex justify-between py-2 text-gray-600 text-sm">
            <div>Subtotal</div>
            <div className="text-gray-800">{invoice.subtotal.toFixed(2)}</div>
          </div>
          <div className="flex justify-between py-2 text-gray-600 text-sm">
            <div>Tax</div>
            <div className="text-gray-800">{invoice.tax_amount.toFixed(2)}</div>
          </div>
          <div className="flex justify-between py-2 border-t border-gray-200 mt-2 text-sm">
            <div className="text-gray-800 font-medium">Total</div>
            <div className="text-gray-800 font-medium">CHF {invoice.total.toFixed(2)}</div>
          </div>
        </div>
      </div>

      {(invoice.notes || invoice.terms || invoice.company?.company_iban) && (
        <div className="border-t border-gray-200 pt-6 text-gray-600 text-xs">
          {invoice.notes && (
            <div className="mb-4">
              <p className="text-gray-400 text-xs mb-1">NOTES</p>
              <p className="text-gray-600 text-xs">{invoice.notes}</p>
            </div>
          )}

          {invoice.terms && (
            <div className="mb-4">
              <p className="text-gray-400 text-xs mb-1">TERMS & CONDITIONS</p>
              <p className="text-gray-600 text-xs">{invoice.terms}</p>
            </div>
          )}

          {invoice.company?.company_iban && (
            <div className="mb-4">
              <p className="text-gray-400 text-xs mb-1">PAYMENT INFORMATION</p>
              <p className="text-gray-600 text-xs">
                <span className="font-medium">IBAN:</span> {invoice.company.company_iban}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
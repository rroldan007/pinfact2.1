import React from 'react';
import { format } from 'date-fns';

type InvoiceTemplateProps = {
  invoice: any;
  logoUrl?: string | null;
};

export const ModernTemplate: React.FC<InvoiceTemplateProps> = ({ invoice, logoUrl }) => {
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-gray-100 text-gray-500';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white max-w-4xl mx-auto text-sm" id="invoice-template">
      {/* Header with color accent */}
      <div className="bg-purple-600 px-6 py-6 text-white">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold tracking-tight">INVOICE</h1>
            <p className="text-purple-200 text-sm mt-1">#{invoice.invoice_number}</p>
          </div>
          {logoUrl && (
            <div>
              <img 
                src={logoUrl} 
                alt="Company Logo" 
                className="h-14 object-contain bg-white p-1 rounded"
              />
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="bg-purple-50 px-5 py-2 flex justify-between items-center border-b border-purple-100 text-xs">
        <div>
          <span className="text-purple-600 font-medium">Issue Date: </span>
          <span className="text-gray-800">{formatDate(invoice.date)}</span>
          <span className="mx-2 text-purple-300">•</span>
          <span className="text-purple-600 font-medium">Due Date: </span>
          <span className="text-gray-800">{formatDate(invoice.due_date)}</span>
        </div>
        <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(invoice.status)}`}>
          {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-5">
        <div className="grid grid-cols-2 gap-6 mb-8 text-sm">
          <div>
            <h3 className="text-xs font-medium text-purple-600 uppercase mb-2">From</h3>
            <div className="text-gray-700">
              <p className="font-bold text-gray-900">{invoice.company?.company_name}</p>
              {invoice.company?.company_address && <p>{invoice.company.company_address}</p>}
              {(invoice.company?.company_postal_code || invoice.company?.company_city) && (
                <p>
                  {invoice.company.company_postal_code} {invoice.company.company_city}
                </p>
              )}
              {invoice.company?.company_country && <p>{invoice.company.company_country}</p>}
              {invoice.company?.company_email && (
                <p className="mt-2 text-xs text-purple-600">{invoice.company.company_email}</p>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-medium text-purple-600 uppercase mb-2">Bill To</h3>
            <div className="text-gray-700">
              <p className="font-bold text-gray-900">{invoice.client?.name}</p>
              {invoice.client?.address && <p>{invoice.client.address}</p>}
              {(invoice.client?.postal_code || invoice.client?.city) && (
                <p>
                  {invoice.client.postal_code} {invoice.client.city}
                </p>
              )}
              {invoice.client?.country && <p>{invoice.client.country}</p>}
              {invoice.client?.email && (
                <p className="mt-2 text-xs text-purple-600">{invoice.client.email}</p>
              )}
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="overflow-hidden rounded-lg border border-gray-200 mb-6 text-sm">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-left">
                <th className="py-2 px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                <th className="py-2 px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
                <th className="py-2 px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="py-2 px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Tax</th>
                <th className="py-2 px-3 text-xs font-medium text-gray-500 uppercase tracking-wider text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items?.map((item: any, index: number) => (
                <tr key={item.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="py-3 px-3">
                    <div className="font-medium text-gray-900">{item.description}</div>
                    {item.secondary_description && (
                      <div className="text-xs text-gray-500">{item.secondary_description}</div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-gray-600">{item.quantity}</td>
                  <td className="py-3 px-3 text-gray-600">{item.unit_price.toFixed(2)}</td>
                  <td className="py-3 px-3 text-gray-600">{item.tax_rate}%</td>
                  <td className="py-3 px-3 text-gray-900 font-medium text-right">
                    {item.total.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Summary */}
        <div className="flex justify-end">
          <div className="w-64 bg-purple-50 rounded-lg p-4 text-sm">
            <div className="flex justify-between py-1 text-gray-600">
              <div>Subtotal:</div>
              <div>CHF {invoice.subtotal.toFixed(2)}</div>
            </div>
            <div className="flex justify-between py-1 text-gray-600">
              <div>Tax:</div>
              <div>CHF {invoice.tax_amount.toFixed(2)}</div>
            </div>
            <div className="flex justify-between pt-2 border-t border-purple-200 mt-2 font-bold text-gray-800">
              <div>Total:</div>
              <div>CHF {invoice.total.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Notes and Terms */}
        <div className="mt-8 text-gray-600 text-xs">
          {invoice.notes && (
            <div className="mb-3">
              <h3 className="text-xs font-medium text-purple-600 uppercase mb-1">Notes</h3>
              <p>{invoice.notes}</p>
            </div>
          )}

          {invoice.terms && (
            <div className="mb-3">
              <h3 className="text-xs font-medium text-purple-600 uppercase mb-1">Terms & Conditions</h3>
              <p>{invoice.terms}</p>
            </div>
          )}

          {invoice.company?.company_iban && (
            <div className="mt-5 p-3 bg-gray-50 rounded-lg border border-gray-200 text-xs">
              <h3 className="text-xs font-medium text-purple-600 uppercase mb-1">Payment Information</h3>
              <p>
                <span className="font-medium">IBAN:</span> {invoice.company.company_iban}
              </p>
              {invoice.company?.company_bic && (
                <p>
                  <span className="font-medium">BIC/SWIFT:</span> {invoice.company.company_bic}
                </p>
              )}
              {invoice.company?.company_bank && (
                <p>
                  <span className="font-medium">Bank:</span> {invoice.company.company_bank}
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-50 px-6 py-3 text-center text-xs text-gray-500 mt-3">
        Thank you for choosing our services
      </div>
    </div>
  );
};
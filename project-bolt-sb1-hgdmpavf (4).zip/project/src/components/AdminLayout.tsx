import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Settings,
  LogOut,
  Menu,
  X,
  CreditCard,
  BarChart3
} from 'lucide-react';
import { supabase } from '../lib/supabase';

const navigation = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Clientes', href: '/admin/clients', icon: Users },
  { name: 'Suscripciones', href: '/admin/subscriptions', icon: BarChart3 },
  { name: 'Pagos', href: '/admin/payments', icon: CreditCard },
  { name: 'Configuración', href: '/admin/settings', icon: Settings },
];

export const AdminLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex h-screen">
        {/* Mobile menu button */}
        <div className="md:hidden fixed top-0 left-0 w-full bg-white z-10 flex items-center p-4 border-b border-gray-200">
          <button
            type="button"
            className="text-gray-500 hover:text-gray-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
          <div className="ml-4 flex items-center">
            <BarChart3 className="h-6 w-6 text-indigo-600" />
            <span className="ml-2 text-lg font-bold text-gray-900">
              Admin Panel
            </span>
          </div>
        </div>
        
        {/* Mobile sidebar */}
        <div className={`fixed inset-0 z-40 md:hidden transform ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out`}>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-indigo-700 pt-5 pb-4">
            <div className="flex items-center flex-shrink-0 px-4">
              <BarChart3 className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold text-white">
                Admin Panel
              </span>
            </div>
            <div className="mt-5 flex-1 h-0 overflow-y-auto">
              <nav className="px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`${
                        location.pathname === item.href
                          ? 'bg-indigo-800 text-white'
                          : 'text-indigo-100 hover:bg-indigo-600'
                      } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Icon
                        className="mr-4 h-6 w-6 text-indigo-300"
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-indigo-800 p-4">
              <button
                onClick={handleSignOut}
                className="flex items-center text-indigo-100 hover:text-white"
              >
                <LogOut className="h-6 w-6 mr-3" />
                Cerrar sesión
              </button>
            </div>
          </div>
          <div className="flex-shrink-0 w-14" onClick={() => setMobileMenuOpen(false)}></div>
        </div>

        {/* Desktop sidebar */}
        <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
          <div className="flex flex-col flex-grow pt-5 bg-indigo-700 overflow-y-auto">
            <div className="flex items-center flex-shrink-0 px-4">
              <BarChart3 className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold text-white">
                Admin Panel
              </span>
            </div>
            <div className="mt-5 flex-grow flex flex-col">
              <nav className="flex-1 px-2 space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`${
                        location.pathname === item.href || location.pathname.startsWith(item.href + '/')
                          ? 'bg-indigo-800 text-white'
                          : 'text-indigo-100 hover:bg-indigo-600'
                      } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                    >
                      <Icon
                        className="mr-3 h-5 w-5 text-indigo-300"
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-indigo-800 p-4">
              <button
                onClick={handleSignOut}
                className="flex items-center text-indigo-100 hover:text-white"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Cerrar sesión
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="md:pl-64 flex flex-col flex-1">
          <div className="md:hidden h-16"></div> {/* Spacer for mobile menu */}
          <main className="flex-1 p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
};
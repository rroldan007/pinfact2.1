import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Loader2 } from 'lucide-react';

// Importaciones de las vistas previas reales de los templates
import { ClassicTemplate } from './InvoiceTemplates/ClassicTemplate';
import { ModernTemplate } from './InvoiceTemplates/ModernTemplate';
import { MinimalTemplate } from './InvoiceTemplates/MinimalTemplate';
import { ProfessionalTemplate } from './InvoiceTemplates/ProfessionalTemplate';

type Template = {
  id: string;
  name: string;
  description: string;
  style: 'classic' | 'modern' | 'minimal' | 'professional';
  preview_url: string;
};

type InvoiceTemplateSelectorProps = {
  selectedTemplateId: string | null;
  onChange: (templateId: string) => void;
};

// Ejemplo de factura para la vista previa
const sampleInvoice = {
  invoice_number: 'INV-0001',
  date: new Date().toISOString(),
  due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
  status: 'draft',
  subtotal: 650,
  tax_amount: 50.05,
  total: 700.05,
  client: {
    name: 'Cliente Ejemplo, SA',
    address: 'Calle Principal 123',
    postal_code: '08001',
    city: 'Barcelona',
    country: 'España',
    email: 'cliente@ejemplo.com'
  },
  company: {
    company_name: 'Mi Empresa',
    company_address: 'Avenida Business 456',
    company_postal_code: '1000',
    company_city: 'Ginebra',
    company_country: 'Suiza',
    company_email: 'info@miempresa.com',
    company_phone: '+41 123 456 789',
    company_vat_number: 'CHE-123.456.789',
    company_iban: 'CH56 0483 5012 3456 7800 9',
    company_logo_url: null
  },
  items: [
    {
      id: '1',
      description: 'Servicio de consultoría',
      secondary_description: '10 horas de análisis de negocio',
      quantity: 10,
      unit_price: 50,
      tax_rate: 7.7,
      total: 500
    },
    {
      id: '2',
      description: 'Implementación de software',
      secondary_description: 'Desarrollo e instalación',
      quantity: 1,
      unit_price: 150,
      tax_rate: 7.7,
      total: 150
    }
  ]
};

export const InvoiceTemplateSelector: React.FC<InvoiceTemplateSelectorProps> = ({
  selectedTemplateId,
  onChange
}) => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hoveredTemplate, setHoveredTemplate] = useState<string | null>(null);

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        setLoading(true);
        
        // Safely check if the invoice_templates table exists first
        try {
          const { data: checkData, error: checkError } = await supabase
            .from('invoice_templates')
            .select('id', { count: 'exact', head: true })
            .limit(1);
            
          // Continue only if there was no error
          if (!checkError) {
            const { data, error } = await supabase
              .from('invoice_templates')
              .select('*')
              .order('name');
              
            if (error) throw error;
            
            setTemplates(data || []);
            
            // If no template is selected and we have templates, select the first one
            if (!selectedTemplateId && data && data.length > 0) {
              onChange(data[0].id);
            }
          } else {
            // If the table doesn't exist, we'll just show an informative message
            console.warn("Invoice templates table not available:", checkError);
            throw new Error("Invoice templates are not fully set up yet. Please try again later.");
          }
        } catch (err) {
          console.error("Failed to check for invoice_templates table:", err);
          throw new Error("Invoice templates feature is still being set up. Please try again later.");
        }
      } catch (err) {
        console.error('Error fetching templates:', err);
        setError(err instanceof Error ? err.message : 'Failed to load invoice templates');
      } finally {
        setLoading(false);
      }
    };
    
    fetchTemplates();
  }, [selectedTemplateId, onChange]);

  // Renderiza la vista previa de un estilo específico de plantilla
  const renderTemplatePreview = (style: string) => {
    const scale = "scale-[0.25] origin-top-left w-[400%] h-[400%]";
    const containerClass = "w-full h-40 overflow-hidden relative bg-white";
    
    switch (style) {
      case 'modern':
        return (
          <div className={containerClass}>
            <div className={scale}>
              <ModernTemplate invoice={sampleInvoice} />
            </div>
          </div>
        );
      case 'minimal':
        return (
          <div className={containerClass}>
            <div className={scale}>
              <MinimalTemplate invoice={sampleInvoice} />
            </div>
          </div>
        );
      case 'professional':
        return (
          <div className={containerClass}>
            <div className={scale}>
              <ProfessionalTemplate invoice={sampleInvoice} />
            </div>
          </div>
        );
      case 'classic':
      default:
        return (
          <div className={containerClass}>
            <div className={scale}>
              <ClassicTemplate invoice={sampleInvoice} />
            </div>
          </div>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="h-6 w-6 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-sm text-amber-600 bg-amber-50 rounded-md">
        {error}
      </div>
    );
  }

  if (templates.length === 0) {
    return (
      <div className="p-4 text-sm text-gray-600 bg-gray-50 rounded-md">
        No invoice templates are available. Default template styles will be used.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.map((template) => (
          <div 
            key={template.id}
            className={`border rounded-lg overflow-hidden cursor-pointer transition-all ${
              selectedTemplateId === template.id
                ? 'ring-2 ring-indigo-500 border-indigo-500'
                : 'hover:border-gray-300'
            }`}
            onClick={() => onChange(template.id)}
            onMouseEnter={() => setHoveredTemplate(template.id)}
            onMouseLeave={() => setHoveredTemplate(null)}
          >
            <div className="relative bg-gray-100">
              {/* Renderiza la vista previa real del template */}
              {renderTemplatePreview(template.style)}
              
              <div className={`absolute top-2 right-2 px-2 py-1 text-xs rounded-full ${
                template.style === 'classic' ? 'bg-blue-100 text-blue-800' :
                template.style === 'modern' ? 'bg-purple-100 text-purple-800' :
                template.style === 'minimal' ? 'bg-gray-100 text-gray-800' :
                'bg-slate-100 text-slate-800'
              }`}>
                {template.style}
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-center">
                <h3 className="font-medium text-gray-900">{template.name}</h3>
                {selectedTemplateId === template.id && (
                  <div className="h-4 w-4 rounded-full bg-indigo-500"></div>
                )}
              </div>
              <p className="mt-1 text-sm text-gray-500">{template.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
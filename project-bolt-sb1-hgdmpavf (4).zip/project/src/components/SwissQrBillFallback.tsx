import React, { useEffect, useState, useRef } from 'react';
import { generateQrCodeContent, getQrCodeStyles, QrBillData } from '../utils/swissQrBill';
import { generateQrBillPDF } from '../utils/pdfUtils';
import { CreditCard, Download, Loader2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface SwissQrBillFallbackProps {
  invoice: any;
  companyData: any;
  className?: string;
}

export const SwissQrBillFallback: React.FC<SwissQrBillFallbackProps> = ({ invoice, companyData, className = '' }) => {
  const [qrData, setQrData] = useState<QrBillData | null>(null);
  const [qrCodeValue, setQrCodeValue] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfGenerating, setPdfGenerating] = useState(false);
  const qrCodeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prepareQrBill = () => {
      if (!invoice || !companyData) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // Check if we have all required data
        if (!companyData.company_iban) {
          throw new Error('Company IBAN is required for QR bill generation');
        }

        // Prepare data for QR bill
        const qrBillData: QrBillData = {
          invoiceNumber: invoice.invoice_number,
          amount: invoice.total,
          currency: companyData.default_currency || 'CHF',
          creditorName: companyData.company_name,
          creditorAddress: companyData.company_address || '',
          creditorPostalCode: companyData.company_postal_code || '',
          creditorCity: companyData.company_city || '',
          creditorCountry: companyData.company_country || 'CH',
          creditorIban: companyData.company_iban,
          
          // Include debtor (client) info if available
          ...(invoice.client && {
            debtorName: invoice.client.name,
            debtorAddress: invoice.client.address,
            debtorPostalCode: invoice.client.postal_code,
            debtorCity: invoice.client.city,
            debtorCountry: invoice.client.country || 'CH'
          }),
          
          // Empty message field
          message: 'Fallback QR implementation'
        };

        // Generate QR code content string using the fallback implementation
        const qrContent = generateQrCodeContent(qrBillData);
        setQrCodeValue(qrContent);
        setQrData(qrBillData);
      } catch (err) {
        console.error('Error generating QR bill:', err);
        setError(err instanceof Error ? err.message : 'Failed to generate QR bill');
      } finally {
        setLoading(false);
      }
    };

    prepareQrBill();
  }, [invoice, companyData]);

  const handleDownloadPdf = async () => {
    if (!qrData || !qrCodeRef.current) return;
    
    try {
      setPdfGenerating(true);
      
      // Get the QR code SVG element
      const qrCodeSvgEl = qrCodeRef.current.querySelector('svg');
      if (!qrCodeSvgEl) {
        throw new Error('QR code element not found');
      }
      
      // Create a canvas from the SVG
      const canvas = document.createElement('canvas');
      canvas.width = 500;
      canvas.height = 500;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        throw new Error('Failed to create canvas context');
      }
      
      // Create an image from the SVG
      const img = new Image();
      const svgData = new XMLSerializer().serializeToString(qrCodeSvgEl);
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);
      
      // When the image is loaded, draw it on the canvas
      img.onload = () => {
        ctx.drawImage(img, 0, 0, 500, 500);
        URL.revokeObjectURL(url);
        
        // Get data URL from the canvas
        const qrCodeDataUrl = canvas.toDataURL('image/png');
        
        // Generate the PDF using jsPDF
        const filename = `QRBill_${invoice.invoice_number.replace(/[^a-zA-Z0-9]/g, '_')}_fallback.pdf`;
        generateQrBillPDF(qrData, qrCodeDataUrl, filename);
        
        setPdfGenerating(false);
      };
      
      img.onerror = () => {
        URL.revokeObjectURL(url);
        throw new Error('Failed to load SVG as image');
      };
      
      img.src = url;
    } catch (error) {
      console.error('Error generating QR bill PDF:', error);
      setError('Failed to generate QR bill PDF. Please try again.');
      setPdfGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className={`flex justify-center items-center p-4 ${className}`}>
        <Loader2 className="h-8 w-8 text-gray-400 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className={`p-4 bg-red-50 text-red-600 rounded-md ${className}`}>
        <p className="text-sm">{error}</p>
        <p className="text-xs mt-1">Make sure your company profile has an IBAN set.</p>
      </div>
    );
  }

  if (!qrData || !qrCodeValue) {
    return (
      <div className={`p-4 bg-gray-50 text-gray-500 rounded-md ${className}`}>
        <p className="text-sm">Unable to generate QR bill. Check company profile settings.</p>
      </div>
    );
  }

  // Get QR code styling
  const qrCodeStyles = getQrCodeStyles();

  return (
    <div className={`qr-bill-container ${className}`}>
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm font-medium text-gray-700">
          Swiss QR Bill Payment Slip (Fallback Implementation)
        </div>
        
        <button
          onClick={handleDownloadPdf}
          disabled={pdfGenerating}
          className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
        >
          {pdfGenerating ? (
            <>
              <Loader2 className="animate-spin -ml-0.5 mr-2 h-4 w-4" />
              Generating...
            </>
          ) : (
            <>
              <Download className="-ml-0.5 mr-2 h-4 w-4" />
              Download QR Bill PDF
            </>
          )}
        </button>
      </div>
      
      <div className="border border-gray-100 bg-amber-50 p-4 mb-4 text-amber-800 text-sm rounded-md">
        <p>This is using the fallback implementation - if bank scanning doesn't work, please try the primary implementation.</p>
      </div>
      
      {/* A4 format with tear-off receipt and payment part - based on official specifications */}
      <div className="border border-gray-300 bg-white" style={{ width: '210mm', minHeight: '105mm' }}>
        {/* Main container with 2:1 ratio for payment part vs receipt */}
        <div style={{ display: 'flex', minHeight: '105mm' }}>
          {/* Receipt part (1/3) - exactly 62mm wide per specs */}
          <div style={{ 
            width: '62mm',
            borderRight: '1px dashed #999',
            padding: '5mm',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column'
          }} className="receipt-section">
            <div style={{ fontSize: '11pt', fontWeight: 'bold', marginBottom: '2mm' }}>Receipt</div>
            
            {/* Account information */}
            <div style={{ marginBottom: '4mm' }}>
              <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Account / Payable to</div>
              <div style={{ fontSize: '8pt' }}>{qrData.creditorIban}</div>
              <div style={{ fontSize: '8pt' }}>{qrData.creditorName}</div>
              <div style={{ fontSize: '8pt' }}>{qrData.creditorAddress}</div>
              <div style={{ fontSize: '8pt' }}>{qrData.creditorPostalCode} {qrData.creditorCity}</div>
              <div style={{ fontSize: '8pt' }}>{qrData.creditorCountry}</div>
            </div>
            
            {/* Reference number - empty */}
            <div style={{ marginBottom: '4mm' }}>
              <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Reference</div>
              <div style={{ fontSize: '8pt' }}></div>
            </div>
            
            {/* Payer information if available */}
            {qrData.debtorName && (
              <div style={{ marginBottom: '4mm' }}>
                <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Payable by</div>
                <div style={{ fontSize: '8pt' }}>{qrData.debtorName}</div>
                {qrData.debtorAddress && <div style={{ fontSize: '8pt' }}>{qrData.debtorAddress}</div>}
                {(qrData.debtorPostalCode || qrData.debtorCity) && (
                  <div style={{ fontSize: '8pt' }}>{qrData.debtorPostalCode} {qrData.debtorCity}</div>
                )}
                {qrData.debtorCountry && <div style={{ fontSize: '8pt' }}>{qrData.debtorCountry}</div>}
              </div>
            )}
            
            {/* Amount */}
            <div style={{ marginTop: 'auto', display: 'flex', marginBottom: '4mm' }}>
              <div style={{ width: '50%' }}>
                <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Currency</div>
                <div style={{ fontSize: '8pt', fontWeight: 'bold' }}>{qrData.currency}</div>
              </div>
              <div style={{ width: '50%' }}>
                <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Amount</div>
                <div style={{ fontSize: '8pt', fontWeight: 'bold' }}>{qrData.amount.toFixed(2)}</div>
              </div>
            </div>
            
            {/* Acceptance point - official footer */}
            <div style={{ 
              position: 'absolute',
              bottom: '5mm',
              left: '5mm',
              right: '5mm',
              borderTop: '1px solid #ccc',
              paddingTop: '4mm'
            }}>
              <div style={{ fontSize: '6pt' }}>Acceptance point</div>
            </div>
          </div>
          
          {/* Payment part (2/3) - exactly 148mm wide per specs */}
          <div style={{ 
            width: '148mm',
            padding: '5mm',
            position: 'relative'
          }} className="payment-section">
            <div style={{ fontSize: '11pt', fontWeight: 'bold', marginBottom: '5mm' }}>Payment part</div>
            
            {/* QR code with Swiss cross */}
            <div style={{ display: 'flex' }}>
              <div style={{ position: 'relative', width: '46mm', height: '46mm' }} ref={qrCodeRef}>
                {/* QR code - exactly 46x46mm per Swiss standards */}
                <QRCodeSVG 
                  value={qrCodeValue} 
                  size={qrCodeStyles.width}
                  level="M"
                  bgColor="#FFFFFF"
                  fgColor="#000000"
                  includeMargin={false}
                />
                
                {/* Swiss cross overlay - EXACTLY as in the reference implementation */}
                <div className="swiss-cross" style={{
                  position: 'absolute',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  width: '7mm',
                  height: '7mm',
                  background: 'white',
                }}>
                  <svg width="100%" height="100%" viewBox="0 0 100 100">
                    <rect width="100" height="100" fill="white" />
                    <rect x="10" y="10" width="80" height="80" fill="black" />
                    <rect x="35" y="10" width="30" height="80" fill="white" />
                    <rect x="10" y="35" width="80" height="30" fill="white" />
                  </svg>
                </div>
                
                {/* Amount text below QR code */}
                <div style={{ marginTop: '2mm', textAlign: 'center' }}>
                  <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Currency</div>
                  <div style={{ fontSize: '8pt', fontWeight: 'bold' }}>{qrData.currency}</div>
                </div>
                <div style={{ marginTop: '1mm', textAlign: 'center' }}>
                  <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Amount</div>
                  <div style={{ fontSize: '8pt', fontWeight: 'bold' }}>{qrData.amount.toFixed(2)}</div>
                </div>
              </div>
              
              {/* Right section with all payment information */}
              <div style={{ marginLeft: '4mm', flex: 1 }}>
                {/* Account information */}
                <div style={{ marginBottom: '4mm' }}>
                  <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Account / Payable to</div>
                  <div style={{ fontSize: '8pt' }}>{qrData.creditorIban}</div>
                  <div style={{ fontSize: '8pt' }}>{qrData.creditorName}</div>
                  <div style={{ fontSize: '8pt' }}>{qrData.creditorAddress}</div>
                  <div style={{ fontSize: '8pt' }}>{qrData.creditorPostalCode} {qrData.creditorCity}</div>
                  <div style={{ fontSize: '8pt' }}>{qrData.creditorCountry}</div>
                </div>
                
                {/* Reference information - empty */}
                <div style={{ marginBottom: '4mm' }}>
                  <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Reference</div>
                  <div style={{ fontSize: '8pt' }}></div>
                </div>
                
                {/* Additional information - show invoice number */}
                <div style={{ marginBottom: '4mm' }}>
                  <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Additional information</div>
                  <div style={{ fontSize: '8pt' }}>Invoice {invoice.invoice_number} (Fallback)</div>
                </div>
                
                {/* Payer information if available */}
                {qrData.debtorName && (
                  <div style={{ marginBottom: '4mm' }}>
                    <div style={{ fontSize: '6pt', marginBottom: '1mm' }}>Payable by</div>
                    <div style={{ fontSize: '8pt' }}>{qrData.debtorName}</div>
                    {qrData.debtorAddress && <div style={{ fontSize: '8pt' }}>{qrData.debtorAddress}</div>}
                    {(qrData.debtorPostalCode || qrData.debtorCity) && (
                      <div style={{ fontSize: '8pt' }}>{qrData.debtorPostalCode} {qrData.debtorCity}</div>
                    )}
                    {qrData.debtorCountry && <div style={{ fontSize: '8pt' }}>{qrData.debtorCountry}</div>}
                  </div>
                )}
              </div>
            </div>
            
            {/* Scissors line at the bottom - exactly as spec */}
            <div style={{ 
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: '20mm',
              borderTop: '1px dashed #999',
              textAlign: 'center'
            }}>
              <div style={{ 
                display: 'inline-block',
                backgroundColor: 'white',
                padding: '0 2mm',
                marginTop: '-1.5mm',
                fontSize: '6pt',
                color: '#666'
              }}>
                ✂︎ Separate before paying in ✂︎
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Instructions - not part of the official form but helpful for users */}
      <div className="mt-3 text-center text-xs text-gray-500">
        <p>This QR bill is generated using the fallback implementation.</p>
        <p>If bank scanning doesn't work properly, please try the primary implementation.</p>
      </div>
    </div>
  );
};
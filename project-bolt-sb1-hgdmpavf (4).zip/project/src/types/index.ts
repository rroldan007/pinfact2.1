export interface Company {
  id: string;
  user_id: string;
  name: string;
  tax_id: string;
  address: string;
  postal_code: string;
  city: string;
  country: string;
  phone?: string;
  email: string;
  bank_account?: string;
  bank_name?: string;
  swift?: string;
  iban?: string;
  logo_url?: string;
}

export interface Product {
  id: string;
  company_id: string;
  name: string;
  description: string;
  price: number;
  unit: string;
  tax_rate: number;
  created_at: string;
}

export interface Invoice {
  id: string;
  company_id: string;
  invoice_number: string;
  issue_date: string;
  due_date: string;
  client_name: string;
  client_tax_id: string;
  client_address: string;
  client_postal_code: string;
  client_city: string;
  client_country: string;
  items: InvoiceItem[];
  subtotal: number;
  tax_total: number;
  total: number;
  notes?: string;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
  created_at: string;
}

export interface InvoiceItem {
  product_id: string;
  description: string;
  quantity: number;
  unit_price: number;
  tax_rate: number;
  total: number;
}
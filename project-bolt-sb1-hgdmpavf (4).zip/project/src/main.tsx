import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { createSwissQRBillV1_6Beta, createSwissQRBillV2_0 } from './utils/versionControl';

// Create backups of the current implementations
createSwissQRBillV1_6Beta();
createSwissQRBillV2_0();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
import React, { useEffect, useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '../lib/supabase';
import { Save, Loader2, Upload, X } from 'lucide-react';
import { InvoiceTemplateSelector } from '../components/InvoiceTemplateSelector';

const companySchema = z.object({
  company_name: z.string().min(1, 'Company name is required'),
  company_email: z.string().email('Invalid email').optional().or(z.literal('')),
  company_phone: z.string().optional().or(z.literal('')),
  company_address: z.string().optional().or(z.literal('')),
  company_postal_code: z.string().optional().or(z.literal('')),
  company_city: z.string().optional().or(z.literal('')),
  company_country: z.string().default('Suisse'),
  company_website: z.string().optional().or(z.literal('')),
  company_vat_number: z.string().optional().or(z.literal('')),
  company_iban: z.string().optional().or(z.literal('')),
  company_bic: z.string().optional().or(z.literal('')),
  company_bank: z.string().optional().or(z.literal('')),
  invoice_prefix: z.string().default('INV-'),
  next_invoice_number: z.number().int().positive().default(1),
  default_payment_terms: z.number().int().positive().default(30),
  default_tax_rate: z.number().min(0).default(7.7),
  default_currency: z.string().default('CHF'),
  default_notes: z.string().optional().or(z.literal('')),
  default_terms: z.string().default('Paiement dû dans les 30 jours suivant la réception de la facture.')
});

type CompanyForm = z.infer<typeof companySchema>;

export const CompanyProfile = () => {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(null);
  const [templatesAvailable, setTemplatesAvailable] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isDirty },
  } = useForm<CompanyForm>({
    resolver: zodResolver(companySchema),
    defaultValues: {
      default_payment_terms: 30,
      default_tax_rate: 7.7,
      default_currency: 'CHF',
      company_country: 'Suisse',
      invoice_prefix: 'INV-',
      next_invoice_number: 1,
      default_terms: 'Paiement dû dans les 30 jours suivant la réception de la facture.'
    }
  });

  useEffect(() => {
    const checkTemplatesTable = async () => {
      try {
        // Safely check if the invoice_templates table exists
        const { data: checkData, error: checkError } = await supabase
          .from('invoice_templates')
          .select('id', { count: 'exact', head: true })
          .limit(1);
          
        setTemplatesAvailable(!checkError);
      } catch (err) {
        console.warn("Error checking for templates table:", err);
        setTemplatesAvailable(false);
      }
    };
    
    checkTemplatesTable();
  }, []);

  useEffect(() => {
    const fetchCompanySettings = async () => {
      setLoading(true);
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          setUserId(user.id);
          
          // Check if default_template_id column exists using a safer approach
          let templateColumnExists = false;
          
          try {
            // First check using the RPC function if available
            const { data: columnCheck, error: rpcError } = await supabase
              .rpc('check_column_exists', { 
                table_name: 'company_settings', 
                column_name: 'default_template_id' 
              });
              
            if (!rpcError) {
              templateColumnExists = !!columnCheck;
            } else {
              // Fallback to a direct query, suppressing errors
              try {
                await supabase
                  .from('company_settings')
                  .select('default_template_id')
                  .eq('user_id', user.id)
                  .limit(1)
                  .single();
                  
                templateColumnExists = true;
              } catch {
                templateColumnExists = false;
              }
            }
          } catch (err) {
            console.warn("Error checking for default_template_id column:", err);
            templateColumnExists = false;
          }
          
          // Now fetch the company settings
          const selectColumns = templateColumnExists 
            ? '*' 
            : 'id, company_name, company_email, company_phone, company_address, company_postal_code, company_city, company_country, company_website, company_vat_number, company_iban, company_bic, company_bank, company_logo_url, invoice_prefix, next_invoice_number, default_payment_terms, default_tax_rate, default_currency, default_notes, default_terms, created_at, updated_at';
          
          const { data, error } = await supabase
            .from('company_settings')
            .select(selectColumns)
            .eq('user_id', user.id)
            .single();
          
          if (error && error.code !== 'PGRST116') {
            console.error('Error fetching company settings:', error);
          } else if (data) {
            setCompanyId(data.id);
            setLogoUrl(data.company_logo_url);
            
            if (templateColumnExists && data.default_template_id) {
              setSelectedTemplateId(data.default_template_id);
            }
            
            // Convert string numbers to actual numbers for the form
            const formData = {
              ...data,
              next_invoice_number: Number(data.next_invoice_number),
              default_payment_terms: Number(data.default_payment_terms),
              default_tax_rate: Number(data.default_tax_rate)
            };
            reset(formData);
          }
        }
      } catch (error) {
        console.error('Error fetching company settings:', error);
        setNotification({
          type: 'error',
          message: 'Failed to load company settings. Please try again.'
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchCompanySettings();
  }, [reset]);

  const onSubmit = async (data: CompanyForm) => {
    setSaving(true);
    setNotification(null);
    
    try {
      // Get the current user
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('No authenticated user found');
      }
      
      // Prepare data with logo URL
      const dataToSave = {
        ...data,
        company_logo_url: logoUrl
      };
      
      // Add template ID only if templates are available
      const finalData = templatesAvailable && selectedTemplateId 
        ? { ...dataToSave, default_template_id: selectedTemplateId }
        : dataToSave;
      
      // If we have a companyId, update the existing record
      // Otherwise, insert a new one
      let error;
      if (companyId) {
        const { error: updateError } = await supabase
          .from('company_settings')
          .update(finalData)
          .eq('id', companyId);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('company_settings')
          .insert({
            ...finalData,
            user_id: user.id
          });
        error = insertError;
      }
      
      // Handle column not found errors by retrying without the problematic column
      if (error && error.message && error.message.includes('default_template_id')) {
        console.warn('default_template_id column issue, retrying without it');
        
        const { error: retryError } = await (companyId
          ? supabase
              .from('company_settings')
              .update(dataToSave)
              .eq('id', companyId)
          : supabase
              .from('company_settings')
              .insert({
                ...dataToSave,
                user_id: user.id
              })
        );
        
        if (retryError) throw retryError;
      } else if (error) {
        throw error;
      }
      
      setNotification({
        type: 'success', 
        message: 'Company settings saved successfully'
      });
      
      // If we don't have a companyId yet (new record), fetch it now
      if (!companyId) {
        const { data: newData } = await supabase
          .from('company_settings')
          .select('id')
          .eq('user_id', user.id)
          .single();
          
        if (newData) {
          setCompanyId(newData.id);
        }
      }
    } catch (error) {
      console.error('Error saving company settings:', error);
      setNotification({
        type: 'error',
        message: error instanceof Error 
          ? error.message 
          : 'An error occurred while saving company settings'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !userId) return;

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
    if (!allowedTypes.includes(file.type)) {
      setNotification({
        type: 'error',
        message: 'Invalid file type. Please upload a JPG, PNG, GIF, or SVG image.'
      });
      return;
    }

    // Validate file size (max 2MB)
    const maxSizeInBytes = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSizeInBytes) {
      setNotification({
        type: 'error',
        message: 'File size exceeds 2MB. Please upload a smaller image.'
      });
      return;
    }

    try {
      setUploadingLogo(true);
      setNotification(null);

      // Create a unique filename to avoid collisions
      const fileExt = file.name.split('.').pop();
      const fileName = `${userId}/${Date.now()}-${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      
      // Upload to company-logos bucket
      const { data, error } = await supabase.storage
        .from('company-logos')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('company-logos')
        .getPublicUrl(fileName);

      // Update the company settings with the logo URL
      setLogoUrl(urlData.publicUrl);

      if (companyId) {
        const { error: updateError } = await supabase
          .from('company_settings')
          .update({ company_logo_url: urlData.publicUrl })
          .eq('id', companyId);

        if (updateError) throw updateError;
      }

      setNotification({
        type: 'success',
        message: 'Logo uploaded successfully'
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      setNotification({
        type: 'error',
        message: error instanceof Error 
          ? error.message 
          : 'An error occurred while uploading logo'
      });
    } finally {
      setUploadingLogo(false);
      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemoveLogo = async () => {
    if (!companyId || !logoUrl) return;

    try {
      setUploadingLogo(true);
      setNotification(null);

      // Update the company settings to remove the logo URL
      const { error: updateError } = await supabase
        .from('company_settings')
        .update({ company_logo_url: null })
        .eq('id', companyId);

      if (updateError) throw updateError;

      // Update the logo URL state
      setLogoUrl(null);

      setNotification({
        type: 'success',
        message: 'Logo removed successfully'
      });
    } catch (error) {
      console.error('Error removing logo:', error);
      setNotification({
        type: 'error',
        message: error instanceof Error 
          ? error.message 
          : 'An error occurred while removing logo'
      });
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleTemplateChange = async (templateId: string) => {
    setSelectedTemplateId(templateId);
    
    // If we have a company ID, immediately update the template selection
    if (companyId && templatesAvailable) {
      try {
        setNotification(null);
        
        const { error } = await supabase
          .from('company_settings')
          .update({ default_template_id: templateId })
          .eq('id', companyId);
          
        if (error) {
          // If column doesn't exist yet, just save the selection in state
          if (error.message && error.message.includes('default_template_id')) {
            console.warn('default_template_id column not ready yet, will save later');
            return;
          }
          throw error;
        }
        
        setNotification({
          type: 'success',
          message: 'Invoice template updated successfully'
        });
      } catch (error) {
        console.error('Error updating template:', error);
        setNotification({
          type: 'error',
          message: error instanceof Error 
            ? error.message 
            : 'An error occurred while updating template'
        });
      }
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Company Profile</h1>
      
      <div className="mt-6 bg-white shadow rounded-lg p-6">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {notification && (
              <div className={`p-4 rounded-md ${notification.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                {notification.message}
              </div>
            )}
            
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
              <div className="sm:col-span-6">
                <h2 className="text-lg font-medium text-gray-900">Company Logo</h2>
                <div className="mt-2 flex items-center space-x-4">
                  <div className="w-40 h-40 border border-gray-300 rounded-md overflow-hidden flex items-center justify-center bg-gray-50">
                    {logoUrl ? (
                      <img 
                        src={logoUrl} 
                        alt="Company Logo" 
                        className="max-w-full max-h-full object-contain"
                      />
                    ) : (
                      <span className="text-gray-400">No logo uploaded</span>
                    )}
                  </div>
                  <div className="flex flex-col space-y-2">
                    <div>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/gif,image/svg+xml"
                        id="company-logo"
                        ref={fileInputRef}
                        onChange={handleLogoUpload}
                        className="sr-only"
                      />
                      <label
                        htmlFor="company-logo"
                        className={`inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 cursor-pointer ${uploadingLogo ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {uploadingLogo ? (
                          <>
                            <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="-ml-1 mr-2 h-4 w-4" />
                            Upload Logo
                          </>
                        )}
                      </label>
                    </div>
                    {logoUrl && (
                      <button
                        type="button"
                        onClick={handleRemoveLogo}
                        disabled={uploadingLogo}
                        className={`inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-red-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 ${uploadingLogo ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <X className="-ml-1 mr-2 h-4 w-4" />
                        Remove Logo
                      </button>
                    )}
                    <p className="text-xs text-gray-500">
                      Upload a company logo to display on invoices (JPG, PNG, GIF, SVG, max 2MB)
                    </p>
                  </div>
                </div>
              </div>

              <div className="sm:col-span-6">
                <h2 className="text-lg font-medium text-gray-900">Company Information</h2>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_name" className="block text-sm font-medium text-gray-700">
                  Company Name *
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_name"
                    className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.company_name ? 'border-red-300' : ''}`}
                    {...register('company_name')}
                  />
                  {errors.company_name && (
                    <p className="mt-1 text-sm text-red-600">{errors.company_name.message}</p>
                  )}
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <div className="mt-1">
                  <input
                    type="email"
                    id="company_email"
                    className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.company_email ? 'border-red-300' : ''}`}
                    {...register('company_email')}
                  />
                  {errors.company_email && (
                    <p className="mt-1 text-sm text-red-600">{errors.company_email.message}</p>
                  )}
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_phone" className="block text-sm font-medium text-gray-700">
                  Phone
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_phone"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_phone')}
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_website" className="block text-sm font-medium text-gray-700">
                  Website
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_website"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_website')}
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_vat_number" className="block text-sm font-medium text-gray-700">
                  VAT Number
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_vat_number"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_vat_number')}
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <h3 className="text-lg font-medium text-gray-900">Address</h3>
              </div>

              <div className="sm:col-span-6">
                <label htmlFor="company_address" className="block text-sm font-medium text-gray-700">
                  Street Address
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_address"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_address')}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="company_postal_code" className="block text-sm font-medium text-gray-700">
                  Postal Code
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_postal_code"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_postal_code')}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="company_city" className="block text-sm font-medium text-gray-700">
                  City
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_city"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_city')}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="company_country" className="block text-sm font-medium text-gray-700">
                  Country
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_country"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_country')}
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <h3 className="text-lg font-medium text-gray-900">Payment Information</h3>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_bank" className="block text-sm font-medium text-gray-700">
                  Bank Name
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_bank"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_bank')}
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_iban" className="block text-sm font-medium text-gray-700">
                  IBAN
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_iban"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_iban')}
                  />
                </div>
              </div>

              <div className="sm:col-span-3">
                <label htmlFor="company_bic" className="block text-sm font-medium text-gray-700">
                  BIC/SWIFT
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="company_bic"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('company_bic')}
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <h3 className="text-lg font-medium text-gray-900">Invoice Settings</h3>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="invoice_prefix" className="block text-sm font-medium text-gray-700">
                  Invoice Prefix
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="invoice_prefix"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('invoice_prefix')}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="next_invoice_number" className="block text-sm font-medium text-gray-700">
                  Next Invoice Number
                </label>
                <div className="mt-1">
                  <input
                    type="number"
                    id="next_invoice_number"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('next_invoice_number', { valueAsNumber: true })}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="default_currency" className="block text-sm font-medium text-gray-700">
                  Default Currency
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    id="default_currency"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('default_currency')}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="default_tax_rate" className="block text-sm font-medium text-gray-700">
                  Default Tax Rate (%)
                </label>
                <div className="mt-1">
                  <input
                    type="number"
                    step="0.01"
                    id="default_tax_rate"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('default_tax_rate', { valueAsNumber: true })}
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="default_payment_terms" className="block text-sm font-medium text-gray-700">
                  Payment Terms (days)
                </label>
                <div className="mt-1">
                  <input
                    type="number"
                    id="default_payment_terms"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('default_payment_terms', { valueAsNumber: true })}
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <label htmlFor="default_terms" className="block text-sm font-medium text-gray-700">
                  Default Terms & Conditions
                </label>
                <div className="mt-1">
                  <textarea
                    id="default_terms"
                    rows={3}
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('default_terms')}
                  />
                </div>
              </div>

              <div className="sm:col-span-6">
                <label htmlFor="default_notes" className="block text-sm font-medium text-gray-700">
                  Default Notes
                </label>
                <div className="mt-1">
                  <textarea
                    id="default_notes"
                    rows={3}
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    {...register('default_notes')}
                  />
                </div>
              </div>
            </div>

            <div className="pt-5">
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={saving || !isDirty}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving ? (
                    <>
                      <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="-ml-1 mr-2 h-4 w-4" />
                      Save
                    </>
                  )}
                </button>
              </div>
            </div>
            
            {/* Invoice Template selector moved below save button with spacing */}
            {templatesAvailable && (
              <div className="sm:col-span-6 mt-10 pt-6 border-t border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Invoice Template</h2>
                <p className="mt-1 text-sm text-gray-500">
                  Select a template design for your invoices. The selected template will be used for all new invoices.
                </p>
                <div className="mt-3">
                  <InvoiceTemplateSelector 
                    selectedTemplateId={selectedTemplateId}
                    onChange={handleTemplateChange}
                  />
                </div>
              </div>
            )}
          </form>
        )}
      </div>
    </div>
  );
};
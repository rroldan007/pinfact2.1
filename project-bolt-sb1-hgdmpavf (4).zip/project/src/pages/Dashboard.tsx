import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, FileCheck, Users, CreditCard, TrendingUp, Package, ArrowRightCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface DashboardStats {
  invoiceCount: number;
  quoteCount: number;
  clientCount: number;
  productCount: number;
  revenueThisMonth: number;
  pendingInvoicesAmount: number;
  pendingInvoicesCount: number;
  quoteConversionRate: number;
  acceptedQuotesAmount: number;
}

export const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    invoiceCount: 0,
    quoteCount: 0,
    clientCount: 0,
    productCount: 0,
    revenueThisMonth: 0,
    pendingInvoicesAmount: 0,
    pendingInvoicesCount: 0,
    quoteConversionRate: 0,
    acceptedQuotesAmount: 0
  });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get user ID first
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          throw new Error('User not authenticated');
        }
        
        // Run queries in parallel for better performance
        const [
          invoicesResult,
          quotesResult,
          clientsResult,
          productsResult,
          revenueResult,
          pendingInvoicesResult,
          acceptedQuotesResult,
          convertedQuotesResult
        ] = await Promise.all([
          // Get invoice count
          supabase
            .from('invoices')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id),
            
          // Get quote count
          supabase
            .from('quotes')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id),
            
          // Get client count
          supabase
            .from('clients')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id),
            
          // Get product count
          supabase
            .from('products')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id),
            
          // Get revenue this month
          supabase
            .from('invoices')
            .select('total')
            .eq('user_id', user.id)
            .eq('status', 'paid')
            .gte('date', new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()),
            
          // Get pending invoices
          supabase
            .from('invoices')
            .select('total')
            .eq('user_id', user.id)
            .in('status', ['draft', 'sent', 'overdue']),
            
          // Get accepted quotes
          supabase
            .from('quotes')
            .select('total')
            .eq('user_id', user.id)
            .eq('status', 'accepted'),
            
          // Get converted quotes count
          supabase
            .from('quotes')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id)
            .eq('status', 'converted')
        ]);
        
        // Calculate revenue
        const revenueThisMonth = revenueResult.data?.reduce((sum, invoice) => sum + invoice.total, 0) || 0;
        
        // Calculate pending invoices
        const pendingInvoicesAmount = pendingInvoicesResult.data?.reduce((sum, invoice) => sum + invoice.total, 0) || 0;
        const pendingInvoicesCount = pendingInvoicesResult.data?.length || 0;
        
        // Calculate accepted quotes amount
        const acceptedQuotesAmount = acceptedQuotesResult.data?.reduce((sum, quote) => sum + quote.total, 0) || 0;
        
        // Calculate quote conversion rate
        const convertedQuotesCount = convertedQuotesResult.count || 0;
        const totalQuotesCount = quotesResult.count || 1; // Avoid division by zero
        const quoteConversionRate = (convertedQuotesCount / totalQuotesCount) * 100;
        
        setStats({
          invoiceCount: invoicesResult.count || 0,
          quoteCount: quotesResult.count || 0,
          clientCount: clientsResult.count || 0,
          productCount: productsResult.count || 0,
          revenueThisMonth,
          pendingInvoicesAmount,
          pendingInvoicesCount,
          quoteConversionRate,
          acceptedQuotesAmount
        });
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  const statCards = [
    { 
      name: 'Invoices',
      value: stats.invoiceCount,
      icon: FileText,
      link: '/app/invoices',
      color: 'bg-blue-500',
      loading 
    },
    { 
      name: 'Quotes',
      value: stats.quoteCount,
      icon: FileCheck,
      link: '/app/quotes',
      color: 'bg-purple-500',
      loading 
    },
    { 
      name: 'Clients',
      value: stats.clientCount,
      icon: Users,
      link: '/app/clients',
      color: 'bg-green-500',
      loading 
    },
    { 
      name: 'Products',
      value: stats.productCount,
      icon: Package,
      link: '/app/products',
      color: 'bg-amber-500',
      loading 
    }
  ];

  const metricsCards = [
    {
      name: 'Revenue (This Month)',
      value: `CHF ${stats.revenueThisMonth.toFixed(2)}`,
      icon: CreditCard,
      color: 'bg-emerald-500',
      loading
    },
    {
      name: 'Pending Invoices',
      value: `${stats.pendingInvoicesCount} (CHF ${stats.pendingInvoicesAmount.toFixed(2)})`,
      icon: FileText,
      color: 'bg-orange-500',
      loading
    },
    {
      name: 'Quote Conversion Rate',
      value: `${stats.quoteConversionRate.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'bg-indigo-500',
      loading
    },
    {
      name: 'Accepted Quotes Value',
      value: `CHF ${stats.acceptedQuotesAmount.toFixed(2)}`,
      icon: FileCheck,
      color: 'bg-teal-500',
      loading
    }
  ];

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-md text-red-800">
        <p>{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-2 text-sm text-red-600 hover:text-red-800"
        >
          Try again
        </button>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
      
      {/* Quick Actions */}
      <div className="mt-6 bg-white p-5 shadow rounded-lg">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Link
            to="/app/invoices/new"
            className="flex items-center p-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all"
          >
            <FileText className="h-6 w-6 mr-2" />
            <span>Create Invoice</span>
            <ArrowRightCircle className="ml-auto h-5 w-5" />
          </Link>
          
          <Link
            to="/app/quotes/new"
            className="flex items-center p-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg hover:from-purple-600 hover:to-purple-700 transition-all"
          >
            <FileCheck className="h-6 w-6 mr-2" />
            <span>Create Quote</span>
            <ArrowRightCircle className="ml-auto h-5 w-5" />
          </Link>
          
          <Link
            to="/app/clients"
            className="flex items-center p-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-all"
          >
            <Users className="h-6 w-6 mr-2" />
            <span>Manage Clients</span>
            <ArrowRightCircle className="ml-auto h-5 w-5" />
          </Link>
          
          <Link
            to="/app/company"
            className="flex items-center p-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-lg hover:from-amber-600 hover:to-amber-700 transition-all"
          >
            <CreditCard className="h-6 w-6 mr-2" />
            <span>Company Profile</span>
            <ArrowRightCircle className="ml-auto h-5 w-5" />
          </Link>
        </div>
      </div>
      
      {/* Main Stats */}
      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              to={item.link}
              className="bg-white rounded-lg shadow hover:shadow-md transition-shadow overflow-hidden"
            >
              <div className="p-5">
                <div className="flex items-center">
                  <div className={`${item.color} rounded-lg p-3`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-5">
                    <div className="text-sm font-medium text-gray-500">
                      {item.name}
                    </div>
                    <div className="mt-1 text-2xl font-semibold text-gray-900">
                      {item.loading ? (
                        <div className="h-8 w-16 bg-gray-200 animate-pulse rounded"></div>
                      ) : (
                        item.value
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
      
      {/* Metrics */}
      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {metricsCards.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.name}
              className="bg-white rounded-lg shadow overflow-hidden"
            >
              <div className="p-5">
                <div className="flex items-center">
                  <div className={`${item.color} rounded-lg p-3`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-5">
                    <div className="text-sm font-medium text-gray-500">
                      {item.name}
                    </div>
                    <div className="mt-1 text-xl font-semibold text-gray-900">
                      {item.loading ? (
                        <div className="h-7 w-24 bg-gray-200 animate-pulse rounded"></div>
                      ) : (
                        item.value
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
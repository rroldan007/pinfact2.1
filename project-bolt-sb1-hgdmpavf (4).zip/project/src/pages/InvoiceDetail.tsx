import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { 
  ArrowLeft, 
  Download, 
  Printer, 
  Send, 
  FileText, 
  AlertTriangle,
  Check,
  Clock,
  Ban,
  Edit,
  CreditCard
} from 'lucide-react';
import { Loader2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { InvoiceTemplateRenderer } from '../components/InvoiceTemplates';
import { SwissQrBill } from '../components/SwissQrBill';

type Invoice = {
  id: string;
  invoice_number: string;
  date: string;
  due_date: string;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  notes: string | null;
  terms: string | null;
  subtotal: number;
  tax_amount: number;
  total: number;
  client: {
    id: string;
    name: string;
    email: string | null;
    phone: string | null;
    address: string | null;
    postal_code: string | null;
    city: string | null;
    country: string | null;
  };
  items: Array<{
    id: string;
    description: string;
    secondary_description: string | null;
    quantity: number;
    unit_price: number;
    tax_rate: number;
    total: number;
  }>;
  company: {
    company_name: string;
    company_address: string | null;
    company_postal_code: string | null;
    company_city: string | null;
    company_country: string | null;
    company_email: string | null;
    company_phone: string | null;
    company_vat_number: string | null;
    company_iban: string | null;
    company_logo_url: string | null;
    default_currency: string | null;
  };
};

type TemplateStyle = 'classic' | 'modern' | 'minimal' | 'professional';

export const InvoiceDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loadingStatus, setLoadingStatus] = useState({
    invoice: true,
    company: false,
    overall: true
  });
  const [error, setError] = useState<string | null>(null);
  const [generatePdfLoading, setGeneratePdfLoading] = useState(false);
  const [templateStyle, setTemplateStyle] = useState<TemplateStyle>('classic');
  const [showQrBill, setShowQrBill] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);
  const qrBillRef = useRef<HTMLDivElement>(null);

  // Use memoized fetchInvoice function to avoid recreation on every render
  const fetchInvoice = useCallback(async () => {
    if (!id) return;
    
    setLoadingStatus(prev => ({ ...prev, invoice: true, overall: true }));
    setError(null);
    
    try {
      // Start measuring performance
      const startTime = performance.now();
      
      // Fetch invoice with client and items in a single query to reduce roundtrips
      const { data, error: invoiceError } = await supabase
        .from('invoices')
        .select(`
          id,
          invoice_number,
          date,
          due_date,
          status,
          notes,
          terms,
          subtotal,
          tax_amount,
          total,
          client:clients(
            id,
            name,
            email,
            phone,
            address,
            postal_code,
            city,
            country
          ),
          items:invoice_items(
            id,
            description,
            secondary_description,
            quantity,
            unit_price,
            tax_rate,
            total
          )
        `)
        .eq('id', id)
        .single();
        
      if (invoiceError) throw invoiceError;
      
      setLoadingStatus(prev => ({ ...prev, invoice: false, company: true }));
      
      // Fetch company information
      const { data: userData } = await supabase.auth.getUser();
      
      if (!userData.user) {
        throw new Error('User not authenticated');
      }
      
      const { data: companyData, error: companyError } = await supabase
        .from('company_settings')
        .select(`
          company_name,
          company_address,
          company_postal_code,
          company_city,
          company_country,
          company_email,
          company_phone,
          company_vat_number,
          company_iban,
          company_logo_url,
          default_currency
        `)
        .eq('user_id', userData.user.id)
        .single();
        
      if (companyError && companyError.code !== 'PGRST116') {
        // PGRST116 is "row not found" error
        throw companyError;
      }
      
      // Try to determine template style from database if available
      try {
        // Check if invoice_templates table exists (safely)
        const { data: templateCheck, error: templateCheckError } = await supabase
          .from('invoice_templates')
          .select('id')
          .limit(1);
          
        if (!templateCheckError) {
          // Table exists, try to get default template
          const { data: templateData } = await supabase
            .from('company_settings')
            .select('default_template_id')
            .eq('user_id', userData.user.id)
            .single();
            
          if (templateData?.default_template_id) {
            const { data: template } = await supabase
              .from('invoice_templates')
              .select('style')
              .eq('id', templateData.default_template_id)
              .single();
              
            if (template?.style) {
              setTemplateStyle(template.style as TemplateStyle);
            }
          }
        }
      } catch (err) {
        console.warn('Could not determine template style, using default:', err);
        // Default to classic if anything fails
        setTemplateStyle('classic');
      }
      
      // Combine all data
      setInvoice({
        ...data,
        company: companyData || {
          company_name: '',
          company_address: null,
          company_postal_code: null,
          company_city: null,
          company_country: null,
          company_email: null,
          company_phone: null,
          company_vat_number: null,
          company_iban: null,
          company_logo_url: null,
          default_currency: null
        }
      });
      
      // Log total performance
      const endTime = performance.now();
      console.log(`Total data fetch took: ${endTime - startTime}ms`);
      
    } catch (err: any) {
      console.error('Error fetching invoice:', err);
      setError(err.message || 'Failed to load invoice');
    } finally {
      setLoadingStatus(prev => ({ ...prev, company: false, overall: false }));
    }
  }, [id]);

  useEffect(() => {
    fetchInvoice();
  }, [fetchInvoice]);

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'sent':
        return 'bg-blue-100 text-blue-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      case 'cancelled':
        return 'bg-gray-100 text-gray-500';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <Check className="h-5 w-5" />;
      case 'sent':
        return <Send className="h-5 w-5" />;
      case 'draft':
        return <FileText className="h-5 w-5" />;
      case 'overdue':
        return <AlertTriangle className="h-5 w-5" />;
      case 'cancelled':
        return <Ban className="h-5 w-5" />;
      default:
        return <Clock className="h-5 w-5" />;
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEditInvoice = () => {
    navigate(`/app/invoices/${id}/edit`);
  };

  const generatePDF = async () => {
    if (!invoiceRef.current || !invoice) return;
    
    try {
      setGeneratePdfLoading(true);

      // Create a container to combine invoice and QR bill if shown
      const container = document.createElement('div');
      
      // Clone the invoice and style it for PDF
      const invoiceClone = invoiceRef.current.cloneNode(true) as HTMLElement;
      invoiceClone.classList.add('pdf-export');
      container.appendChild(invoiceClone);
      
      // Add QR bill if shown
      if (showQrBill && qrBillRef.current) {
        const qrClone = qrBillRef.current.cloneNode(true) as HTMLElement;
        // Add page break before QR bill
        const pageBreak = document.createElement('div');
        pageBreak.style.pageBreakBefore = 'always';
        pageBreak.style.height = '1px';
        
        container.appendChild(pageBreak);
        container.appendChild(qrClone);
      }
      
      // Insert the container into the document temporarily
      document.body.appendChild(container);
      
      // Style the container to be invisible but rendered
      container.style.position = 'absolute';
      container.style.left = '-9999px';
      container.style.top = '-9999px';
      container.style.width = '210mm'; // Set to A4 width for better rendering
      
      // Wait a moment to ensure all content is rendered
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Basic configuration for html2canvas
      const canvasOptions = {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#FFFFFF'
      };
      
      // Create PDF (A4 dimensions)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true
      });
      
      // Get canvas of each page
      const elements = container.children;
      
      for (let i = 0; i < elements.length; i++) {
        if (elements[i].tagName) { // Skip text nodes
          const element = elements[i] as HTMLElement;
          
          // Don't generate for page break elements
          if (element.style.pageBreakBefore === 'always' && element.style.height === '1px') {
            continue;
          }
          
          // Generate canvas for this element
          const canvas = await html2canvas(element, canvasOptions);
          const imgData = canvas.toDataURL('image/jpeg', 1.0);
          
          // Add page for each element (except the first)
          if (i > 0) {
            pdf.addPage();
          }
          
          const imgWidth = 210; // A4 width in mm
          const imgHeight = (canvas.height * imgWidth) / canvas.width;
          
          pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, Math.min(imgHeight, 297));
          
          // If content is taller than A4 height, create additional pages
          if (imgHeight > 297) {
            let heightLeft = imgHeight - 297;
            let position = -297;
            
            while (heightLeft > 0) {
              pdf.addPage();
              pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
              heightLeft -= 297;
              position -= 297;
            }
          }
        }
      }
      
      // Add filename with invoice number
      const filename = `Invoice_${invoice.invoice_number.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
      pdf.save(filename);
      
      // Remove the temporary container
      document.body.removeChild(container);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      setGeneratePdfLoading(false);
    }
  };

  const toggleQrBill = () => {
    setShowQrBill(!showQrBill);
  };

  const canEditInvoice = invoice && (invoice.status === 'draft' || invoice.status === 'sent');
  const canShowQrBill = invoice && invoice.company && invoice.company.company_iban;

  if (loadingStatus.overall) {
    return (
      <div className="flex flex-col justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
        <p className="mt-4 text-gray-600">
          {loadingStatus.invoice ? 'Loading invoice details...' : 
           loadingStatus.company ? 'Loading company information...' :
           'Loading...'}
        </p>
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="bg-red-50 p-4 rounded-md">
        <h2 className="text-lg font-medium text-red-800">Error</h2>
        <p className="mt-1 text-sm text-red-700">{error || 'Invoice not found'}</p>
        <button
          onClick={() => navigate('/app/invoices')}
          className="mt-3 inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
        >
          <ArrowLeft className="-ml-0.5 mr-2 h-4 w-4" />
          Back to Invoices
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={() => navigate('/app/invoices')}
          className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <ArrowLeft className="-ml-0.5 mr-2 h-4 w-4" />
          Back
        </button>
        
        <div className="flex space-x-2">
          {canEditInvoice && (
            <button
              onClick={handleEditInvoice}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Edit className="-ml-0.5 mr-2 h-4 w-4" />
              Edit
            </button>
          )}
          
          {canShowQrBill && (
            <button
              onClick={toggleQrBill}
              className={`inline-flex items-center px-3 py-2 border shadow-sm text-sm leading-4 font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                showQrBill 
                  ? 'text-indigo-700 bg-indigo-50 border-indigo-300 hover:bg-indigo-100' 
                  : 'text-gray-700 bg-white border-gray-300 hover:bg-gray-50'
              }`}
            >
              <CreditCard className="-ml-0.5 mr-2 h-4 w-4" />
              {showQrBill ? 'Hide QR Bill' : 'Show QR Bill'}
            </button>
          )}
          
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Printer className="-ml-0.5 mr-2 h-4 w-4" />
            Print
          </button>
          
          <button
            onClick={generatePDF}
            disabled={generatePdfLoading}
            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {generatePdfLoading ? (
              <>
                <Loader2 className="animate-spin -ml-0.5 mr-2 h-4 w-4" />
                Generating...
              </>
            ) : (
              <>
                <Download className="-ml-0.5 mr-2 h-4 w-4" />
                Download PDF
              </>
            )}
          </button>
          
          <button
            className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Send className="-ml-0.5 mr-2 h-4 w-4" />
            Send Invoice
          </button>
        </div>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-6" ref={invoiceRef}>
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Invoice {invoice.invoice_number}
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Created on {formatDate(invoice.date)} - Due on {formatDate(invoice.due_date)}
            </p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${getStatusBadgeColor(invoice.status)}`}>
            {getStatusIcon(invoice.status)}
            <span className="ml-1">{invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}</span>
          </div>
        </div>
        
        {/* Use the InvoiceTemplateRenderer to display the invoice using the appropriate template */}
        <InvoiceTemplateRenderer 
          invoice={invoice} 
          templateStyle={templateStyle} 
          logoUrl={invoice.company.company_logo_url} 
        />
      </div>
      
      {/* Swiss QR Bill */}
      {showQrBill && (
        <div className="mt-6 bg-white shadow overflow-hidden sm:rounded-lg p-6" ref={qrBillRef}>
          <SwissQrBill invoice={invoice} companyData={invoice.company} />
        </div>
      )}
      
      <div className="hidden print:block text-center text-xs text-gray-500 mt-8">
        <p>Generated by PinFac Invoice System</p>
      </div>
    </div>
  );
};
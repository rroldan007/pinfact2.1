import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, addDays } from 'date-fns';
import { Save, Plus, Trash2, Loader2 } from 'lucide-react';

type Product = {
  id: string;
  name: string;
  price: number;
  tax_rate: number;
  description: string | null;
};

type CompanySettings = {
  default_payment_terms: number;
  default_tax_rate: number;
  quote_prefix: string;
  next_quote_number: number;
};

const quoteItemSchema = z.object({
  id: z.string().optional(),
  description: z.string().min(1, 'Description is required'),
  secondary_description: z.string().optional().nullable(),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  unit_price: z.number().min(0, 'Price must be a positive number'),
  tax_rate: z.number().min(0, 'Tax rate must be a positive number'),
  product_id: z.string().optional().nullable(),
  total: z.number().min(0)
});

const quoteSchema = z.object({
  client_id: z.string().min(1, 'Client is required'),
  quote_number: z.string().min(1, 'Quote number is required'),
  date: z.string().min(1, 'Date is required'),
  expiry_date: z.string().min(1, 'Expiry date is required'),
  status: z.enum(['draft', 'sent', 'accepted', 'rejected', 'expired', 'converted']).default('draft'),
  notes: z.string().optional().nullable(),
  terms: z.string().optional().nullable(),
  items: z.array(quoteItemSchema).min(1, 'At least one item is required'),
  subtotal: z.number().min(0),
  tax_amount: z.number().min(0),
  total: z.number().min(0)
});

type QuoteForm = z.infer<typeof quoteSchema>;

export const CreateQuote = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const [clients, setClients] = useState<Client[]>([]);
  const convertFromInvoiceId = searchParams.get('convertFromInvoice');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [companySettings, setCompanySettings] = useState<CompanySettings | null>(null);
  const navigate = useNavigate();
  const quoteItemsRef = useRef<HTMLDivElement>(null);

  const {
    register,
    handleSubmit,
    control,
    setValue,
    watch,
    getValues,
    reset,
    formState: { errors },
  } = useForm<QuoteForm>({
    resolver: zodResolver(quoteSchema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      expiry_date: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
      status: 'draft',
      items: [
        {
          description: '',
          secondary_description: '',
          quantity: 1,
          unit_price: 0,
          tax_rate: 7.7,
          total: 0
        }
      ],
      subtotal: 0,
      tax_amount: 0,
      total: 0
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items'
  });

  const watchItems = watch('items');

  // Calculate item total whenever quantity or unit_price changes
  const calculateItemTotal = useCallback((index: number) => {
    try {
      const quantity = getValues(`items.${index}.quantity`) || 0;
      const unitPrice = getValues(`items.${index}.unit_price`) || 0;
      const total = quantity * unitPrice;
      
      setValue(`items.${index}.total`, total);
    } catch (err) {
      console.error("Error calculating item total:", err);
    }
  }, [getValues, setValue]);

  // Calculate quote totals
  const calculateQuoteTotals = useCallback(() => {
    try {
      const items = getValues('items');
      let subtotal = 0;
      let taxAmount = 0;
      
      items.forEach((item) => {
        if (item) {
          const itemTotal = (item.quantity || 0) * (item.unit_price || 0);
          subtotal += itemTotal;
          taxAmount += itemTotal * ((item.tax_rate || 0) / 100);
        }
      });
      
      setValue('subtotal', subtotal);
      setValue('tax_amount', taxAmount);
      setValue('total', subtotal + taxAmount);
    } catch (err) {
      console.error("Error calculating quote totals:", err);
    }
  }, [getValues, setValue]);

  // Calculate totals whenever items change
  useEffect(() => {
    if (watchItems) {
      calculateQuoteTotals();
    }
  }, [watchItems, calculateQuoteTotals]);

  // Initialize form with company settings
  useEffect(() => {
    const initializeForm = async () => {
      try {
        setLoading(true);
        setError(null);

        // Get current user
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          throw new Error('User not authenticated');
        }

        // Get company settings
        const { data: settings, error: settingsError } = await supabase
          .from('company_settings')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (settingsError) {
          if (settingsError.code === 'PGRST116') {
            // No settings found, create default
            const { data: newSettings, error: createError } = await supabase
              .from('company_settings')
              .insert({
                user_id: user.id,
                company_name: 'My Company',
                default_payment_terms: 30,
                default_tax_rate: 7.7,
                quote_prefix: 'DEV-',
                next_quote_number: 1
              })
              .select()
              .single();

            if (createError) throw createError;
            setCompanySettings(newSettings);

            // Set initial values
            setValue('quote_number', `DEV-0001`);
            setValue('expiry_date', format(addDays(new Date(), 30), 'yyyy-MM-dd'));
            if (fields.length > 0) {
              setValue(`items.0.tax_rate`, 7.7);
            }
          } else {
            throw settingsError;
          }
        } else {
          setCompanySettings(settings);

          // Set initial values from settings
          const quoteNumber = `${settings.quote_prefix}${String(settings.next_quote_number).padStart(4, '0')}`;
          setValue('quote_number', quoteNumber);
          setValue('expiry_date', format(addDays(new Date(), settings.default_payment_terms), 'yyyy-MM-dd'));
          if (fields.length > 0) {
            setValue(`items.0.tax_rate`, settings.default_tax_rate);
          }
        }
      } catch (err) {
        console.error('Error initializing form:', err);
        setError('Failed to initialize form. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    initializeForm();
  }, [setValue, fields.length]);

  const handleAddItem = () => {
    append({
      description: '',
      secondary_description: '',
      quantity: 1,
      unit_price: 0,
      tax_rate: companySettings?.default_tax_rate || 7.7,
      product_id: null,
      total: 0
    });
  };

  const onSubmit = async (data: QuoteForm) => {
    try {
      setSaving(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Create quote
      const { data: quote, error: quoteError } = await supabase
        .from('quotes')
        .insert({
          ...data,
          user_id: user.id
        })
        .select()
        .single();

      if (quoteError) throw quoteError;

      // Update company settings
      if (companySettings) {
        const { error: updateError } = await supabase
          .from('company_settings')
          .update({
            next_quote_number: companySettings.next_quote_number + 1
          })
          .eq('user_id', user.id);

        if (updateError) {
          console.error('Error updating quote number:', updateError);
        }
      }

      navigate('/app/quotes');
    } catch (err) {
      console.error('Error saving quote:', err);
      setError('Failed to save quote. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 rounded-lg text-red-700">
        <p>{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-2 text-sm font-medium text-red-600 hover:text-red-500"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Create Quote</h1>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <label htmlFor="client_id" className="block text-sm font-medium text-gray-700">
                Client *
              </label>
              <div className="mt-1">
                <select
                  id="client_id"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.client_id ? 'border-red-300' : ''}`}
                  {...register('client_id')}
                >
                  <option value="">Select a client</option>
                </select>
                {errors.client_id && (
                  <p className="mt-1 text-sm text-red-600">{errors.client_id.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="quote_number" className="block text-sm font-medium text-gray-700">
                Quote Number *
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  id="quote_number"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.quote_number ? 'border-red-300' : ''}`}
                  {...register('quote_number')}
                />
                {errors.quote_number && (
                  <p className="mt-1 text-sm text-red-600">{errors.quote_number.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                Date *
              </label>
              <div className="mt-1">
                <input
                  type="date"
                  id="date"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.date ? 'border-red-300' : ''}`}
                  {...register('date')}
                />
                {errors.date && (
                  <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="expiry_date" className="block text-sm font-medium text-gray-700">
                Expiry Date *
              </label>
              <div className="mt-1">
                <input
                  type="date"
                  id="expiry_date"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.expiry_date ? 'border-red-300' : ''}`}
                  {...register('expiry_date')}
                />
                {errors.expiry_date && (
                  <p className="mt-1 text-sm text-red-600">{errors.expiry_date.message}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6" ref={quoteItemsRef}>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Quote Items</h3>
          
          {errors.items?.message && (
            <p className="text-sm text-red-600 mb-4">{errors.items.message}</p>
          )}
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                    Qty
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                    Price
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                    Tax %
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                    Total
                  </th>
                  <th scope="col" className="relative px-3 py-3 w-12">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {fields.map((field, index) => (
                  <tr key={field.id}>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <div className="space-y-1">
                        <input
                          type="text"
                          className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.description ? 'border-red-300' : ''}`}
                          placeholder="Description"
                          {...register(`items.${index}.description`)}
                        />
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Additional details (optional)"
                          {...register(`items.${index}.secondary_description`)}
                        />
                      </div>
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        min="1"
                        className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.quantity ? 'border-red-300' : ''}`}
                        {...register(`items.${index}.quantity`, { 
                          valueAsNumber: true,
                          onChange: () => {
                            calculateItemTotal(index);
                            calculateQuoteTotals();
                          }
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.unit_price ? 'border-red-300' : ''}`}
                        {...register(`items.${index}.unit_price`, { 
                          valueAsNumber: true,
                          onChange: () => {
                            calculateItemTotal(index);
                            calculateQuoteTotals();
                          }
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        {...register(`items.${index}.tax_rate`, { 
                          valueAsNumber: true,
                          onChange: () => calculateQuoteTotals()
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="text"
                        readOnly
                        className="shadow-sm bg-gray-50 block w-full sm:text-sm border-gray-300 rounded-md"
                        value={(watchItems[index]?.total || 0).toFixed(2)}
                      />
                      <input 
                        type="hidden" 
                        {...register(`items.${index}.total`, { valueAsNumber: true })}
                      />
                    </td>
                    <td className="px-3 py-4 text-right text-sm font-medium">
                      {fields.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            remove(index);
                            setTimeout(() => calculateQuoteTotals(), 0);
                          }}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-4">
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Plus className="-ml-0.5 mr-2 h-4 w-4" />
              Add Item
            </button>
          </div>
          
          <div className="mt-6 border-t border-gray-200 pt-6">
            <div className="flex justify-end text-sm">
              <div className="w-64 space-y-2">
                <div className="flex justify-between">
                  <dt className="font-medium text-gray-700">Subtotal:</dt>
                  <dd className="text-gray-900">CHF {watch('subtotal').toFixed(2)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="font-medium text-gray-700">Tax:</dt>
                  <dd className="text-gray-900">CHF {watch('tax_amount').toFixed(2)}</dd>
                </div>
                <div className="border-t border-gray-200 pt-2 flex justify-between">
                  <dt className="font-bold text-gray-900">Total:</dt>
                  <dd className="font-bold text-gray-900">CHF {watch('total').toFixed(2)}</dd>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Additional Information</h3>
          
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Notes (visible to client)
              </label>
              <div className="mt-1">
                <textarea
                  id="notes"
                  rows={4}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  {...register('notes')}
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="terms" className="block text-sm font-medium text-gray-700">
                Terms and Conditions
              </label>
              <div className="mt-1">
                <textarea
                  id="terms"
                  rows={4}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  {...register('terms')}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={() => navigate('/app/quotes')}
            className="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {saving ? (
              <>
                <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                Saving...
              </>
            ) : (
              <>
                <Save className="-ml-1 mr-2 h-4 w-4" />
                Save Quote
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateQuote;
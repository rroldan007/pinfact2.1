import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { ArrowLeft, Download, Printer, Send, FileText, AlertTriangle, Check, Clock, Ban, Edit, FileInput as FileInvoice, X } from 'lucide-react';
import { Loader2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { InvoiceTemplateRenderer } from '../components/InvoiceTemplates';

type Quote = {
  id: string;
  quote_number: string;
  date: string;
  expiry_date: string;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired' | 'converted';
  notes: string | null;
  terms: string | null;
  subtotal: number;
  tax_amount: number;
  total: number;
  client: {
    id: string;
    name: string;
    email: string | null;
    phone: string | null;
    address: string | null;
    postal_code: string | null;
    city: string | null;
    country: string | null;
  };
  items: Array<{
    id: string;
    description: string;
    secondary_description: string | null;
    quantity: number;
    unit_price: number;
    tax_rate: number;
    total: number;
  }>;
  company: {
    company_name: string;
    company_address: string | null;
    company_postal_code: string | null;
    company_city: string | null;
    company_country: string | null;
    company_email: string | null;
    company_phone: string | null;
    company_vat_number: string | null;
    company_iban: string | null;
    company_logo_url: string | null;
  };
};

type TemplateStyle = 'classic' | 'modern' | 'minimal' | 'professional';

export const QuoteDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loadingStatus, setLoadingStatus] = useState({
    quote: true,
    company: false,
    overall: true
  });
  const [error, setError] = useState<string | null>(null);
  const [generatePdfLoading, setGeneratePdfLoading] = useState(false);
  const [templateStyle, setTemplateStyle] = useState<TemplateStyle>('classic');
  const [changeStatusLoading, setChangeStatusLoading] = useState(false);
  const quoteRef = useRef<HTMLDivElement>(null);

  // Use memoized fetchQuote function to avoid recreation on every render
  const fetchQuote = useCallback(async () => {
    if (!id) return;
    
    setLoadingStatus(prev => ({ ...prev, quote: true, overall: true }));
    setError(null);
    
    try {
      // Start measuring performance
      const startTime = performance.now();
      
      // Fetch quote with client and items in a single query to reduce roundtrips
      const { data, error: quoteError } = await supabase
        .from('quotes')
        .select(`
          id,
          quote_number,
          date,
          expiry_date,
          status,
          notes,
          terms,
          subtotal,
          tax_amount,
          total,
          client:clients(
            id,
            name,
            email,
            phone,
            address,
            postal_code,
            city,
            country
          ),
          items:quote_items(
            id,
            description,
            secondary_description,
            quantity,
            unit_price,
            tax_rate,
            total
          )
        `)
        .eq('id', id)
        .single();
        
      if (quoteError) throw quoteError;
      
      setLoadingStatus(prev => ({ ...prev, quote: false, company: true }));
      
      // Fetch company information
      const { data: userData } = await supabase.auth.getUser();
      
      if (!userData.user) {
        throw new Error('User not authenticated');
      }
      
      const { data: companyData, error: companyError } = await supabase
        .from('company_settings')
        .select(`
          company_name,
          company_address,
          company_postal_code,
          company_city,
          company_country,
          company_email,
          company_phone,
          company_vat_number,
          company_iban,
          company_logo_url
        `)
        .eq('user_id', userData.user.id)
        .single();
        
      if (companyError && companyError.code !== 'PGRST116') {
        // PGRST116 is "row not found" error
        throw companyError;
      }
      
      // Try to determine template style from database if available
      try {
        // Check if invoice_templates table exists (safely)
        const { data: templateCheck, error: templateCheckError } = await supabase
          .from('invoice_templates')
          .select('id')
          .limit(1);
          
        if (!templateCheckError) {
          // Table exists, try to get default template
          const { data: templateData } = await supabase
            .from('company_settings')
            .select('default_template_id')
            .eq('user_id', userData.user.id)
            .single();
            
          if (templateData?.default_template_id) {
            const { data: template } = await supabase
              .from('invoice_templates')
              .select('style')
              .eq('id', templateData.default_template_id)
              .single();
              
            if (template?.style) {
              setTemplateStyle(template.style as TemplateStyle);
            }
          }
        }
      } catch (err) {
        console.warn('Could not determine template style, using default:', err);
        // Default to classic if anything fails
        setTemplateStyle('classic');
      }
      
      // Combine all data
      setQuote({
        ...data,
        company: companyData || {
          company_name: '',
          company_address: null,
          company_postal_code: null,
          company_city: null,
          company_country: null,
          company_email: null,
          company_phone: null,
          company_vat_number: null,
          company_iban: null,
          company_logo_url: null
        }
      });
      
      // Log total performance
      const endTime = performance.now();
      console.log(`Total data fetch took: ${endTime - startTime}ms`);
      
    } catch (err: any) {
      console.error('Error fetching quote:', err);
      setError(err.message || 'Failed to load quote');
    } finally {
      setLoadingStatus(prev => ({ ...prev, company: false, overall: false }));
    }
  }, [id]);

  useEffect(() => {
    fetchQuote();
  }, [fetchQuote]);

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'sent':
        return 'bg-blue-100 text-blue-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-yellow-100 text-yellow-800';
      case 'converted':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted':
        return <Check className="h-5 w-5" />;
      case 'sent':
        return <Send className="h-5 w-5" />;
      case 'draft':
        return <FileText className="h-5 w-5" />;
      case 'rejected':
        return <X className="h-5 w-5" />;
      case 'expired':
        return <Clock className="h-5 w-5" />;
      case 'converted':
        return <FileInvoice className="h-5 w-5" />;
      default:
        return <Clock className="h-5 w-5" />;
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEditQuote = () => {
    navigate(`/app/quotes/${id}/edit`);
  };

  const handleConvertToInvoice = () => {
    navigate(`/app/quotes/${id}/convert`);
  };

  const generatePDF = async () => {
    if (!quoteRef.current || !quote) return;
    
    try {
      setGeneratePdfLoading(true);
      
      // Create a clone of the element to prevent modifying the original DOM
      const element = quoteRef.current.cloneNode(true) as HTMLElement;
      
      // Apply PDF-specific styles to reduce font sizes
      element.classList.add('pdf-export');
      
      // Insert the cloned element into the document temporarily
      document.body.appendChild(element);
      
      // Style the element to be invisible but rendered
      element.style.position = 'absolute';
      element.style.left = '-9999px';
      element.style.top = '-9999px';
      element.style.width = '210mm'; // Set to A4 width for better rendering
      
      // Wait a moment to ensure all content is rendered
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Basic configuration for html2canvas
      const canvasOptions = {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#FFFFFF'
      };
      
      // Generate canvas
      const canvas = await html2canvas(element, canvasOptions);
      
      // Check if canvas has content
      const context = canvas.getContext('2d');
      const pixelBuffer = new Uint32Array(
        context?.getImageData(0, 0, canvas.width, canvas.height).data.buffer || []
      );
      
      // If canvas is empty (all pixels are 0), try with a different approach
      const isCanvasBlank = !pixelBuffer.some(color => color !== 0);
      
      if (isCanvasBlank) {
        console.warn("Canvas appears to be blank, trying alternative approach");
        
        // Try with a lower scale factor for better compatibility
        const canvas2 = await html2canvas(element, {
          ...canvasOptions,
          scale: 1,
          width: element.offsetWidth,
          height: element.offsetHeight
        });
        
        const imgData = canvas2.toDataURL('image/jpeg', 1.0);
        
        // Create PDF (A4 dimensions)
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
          compress: true
        });
        
        const imgWidth = 210; // A4 width in mm
        const imgHeight = (canvas2.height * imgWidth) / canvas2.width;
        
        pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, Math.min(imgHeight, 297));
        
        // If content is taller than A4 height, create additional pages
        if (imgHeight > 297) {
          let heightLeft = imgHeight - 297;
          let position = -297;
          
          while (heightLeft > 0) {
            pdf.addPage();
            pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
            heightLeft -= 297;
            position -= 297;
          }
        }
        
        // Add filename with quote number
        const filename = `Quote_${quote.quote_number.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
        pdf.save(filename);
      } else {
        // Original approach if canvas has content
        const imgData = canvas.toDataURL('image/jpeg', 1.0);
        
        // Create PDF (A4 dimensions)
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
          compress: true
        });
        
        const imgWidth = 210; // A4 width in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, Math.min(imgHeight, 297));
        
        // If content is taller than A4 height, create additional pages
        if (imgHeight > 297) {
          let heightLeft = imgHeight - 297;
          let position = -297;
          
          while (heightLeft > 0) {
            pdf.addPage();
            pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
            heightLeft -= 297;
            position -= 297;
          }
        }
        
        // Add filename with quote number
        const filename = `Quote_${quote.quote_number.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
        pdf.save(filename);
      }
      
      // Remove the temporary element
      document.body.removeChild(element);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      setGeneratePdfLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: 'accepted' | 'rejected' | 'sent' | 'expired') => {
    if (!id || !quote) return;
    
    try {
      setChangeStatusLoading(true);
      
      const { error } = await supabase
        .from('quotes')
        .update({ status: newStatus })
        .eq('id', id);
        
      if (error) throw error;
      
      // Update local state
      setQuote({
        ...quote,
        status: newStatus
      });
      
    } catch (error) {
      console.error('Error updating quote status:', error);
      alert('Failed to update quote status. Please try again.');
    } finally {
      setChangeStatusLoading(false);
    }
  };

  const canEditQuote = quote && (quote.status === 'draft' || quote.status === 'sent');
  const canMarkAccepted = quote && (quote.status === 'sent');
  const canMarkRejected = quote && (quote.status === 'sent');
  const canConvertToInvoice = quote && (quote.status === 'accepted');
  const canMarkSent = quote && (quote.status === 'draft');

  if (loadingStatus.overall) {
    return (
      <div className="flex flex-col justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
        <p className="mt-4 text-gray-600">
          {loadingStatus.quote ? 'Loading quote details...' : 
           loadingStatus.company ? 'Loading company information...' :
           'Loading...'}
        </p>
      </div>
    );
  }

  if (error || !quote) {
    return (
      <div className="bg-red-50 p-4 rounded-md">
        <h2 className="text-lg font-medium text-red-800">Error</h2>
        <p className="mt-1 text-sm text-red-700">{error || 'Quote not found'}</p>
        <button
          onClick={() => navigate('/app/quotes')}
          className="mt-3 inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
        >
          <ArrowLeft className="-ml-0.5 mr-2 h-4 w-4" />
          Back to Quotes
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={() => navigate('/app/quotes')}
          className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <ArrowLeft className="-ml-0.5 mr-2 h-4 w-4" />
          Back
        </button>
        
        <div className="flex space-x-2">
          {canEditQuote && (
            <button
              onClick={handleEditQuote}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Edit className="-ml-0.5 mr-2 h-4 w-4" />
              Edit
            </button>
          )}
          
          {canMarkSent && (
            <button
              onClick={() => handleStatusChange('sent')}
              disabled={changeStatusLoading}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              <Send className="-ml-0.5 mr-2 h-4 w-4" />
              Mark as Sent
            </button>
          )}
          
          {canMarkAccepted && (
            <button
              onClick={() => handleStatusChange('accepted')}
              disabled={changeStatusLoading}
              className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
            >
              <Check className="-ml-0.5 mr-2 h-4 w-4" />
              Mark as Accepted
            </button>
          )}
          
          {canMarkRejected && (
            <button
              onClick={() => handleStatusChange('rejected')}
              disabled={changeStatusLoading}
              className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
            >
              <X className="-ml-0.5 mr-2 h-4 w-4" />
              Mark as Rejected
            </button>
          )}
          
          {canConvertToInvoice && (
            <button
              onClick={handleConvertToInvoice}
              className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
            >
              <FileInvoice className="-ml-0.5 mr-2 h-4 w-4" />
              Convert to Invoice
            </button>
          )}
          
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Printer className="-ml-0.5 mr-2 h-4 w-4" />
            Print
          </button>
          
          <button
            onClick={generatePDF}
            disabled={generatePdfLoading}
            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {generatePdfLoading ? (
              <>
                <Loader2 className="animate-spin -ml-0.5 mr-2 h-4 w-4" />
                Generating...
              </>
            ) : (
              <>
                <Download className="-ml-0.5 mr-2 h-4 w-4" />
                Download PDF
              </>
            )}
          </button>
          
          <button
            className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Send className="-ml-0.5 mr-2 h-4 w-4" />
            Send Quote
          </button>
        </div>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-6" ref={quoteRef}>
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Quote {quote.quote_number}
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Created on {formatDate(quote.date)} - Valid until {formatDate(quote.expiry_date)}
            </p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${getStatusBadgeColor(quote.status)}`}>
            {getStatusIcon(quote.status)}
            <span className="ml-1">{quote.status.charAt(0).toUpperCase() + quote.status.slice(1)}</span>
          </div>
        </div>
        
        {/* Use the InvoiceTemplateRenderer component to render the quote using the appropriate template */}
        <InvoiceTemplateRenderer 
          invoice={{
            ...quote,
            invoice_number: quote.quote_number,
            due_date: quote.expiry_date
          }} 
          templateStyle={templateStyle} 
          logoUrl={quote.company.company_logo_url} 
        />
      </div>
      
      <div className="hidden print:block text-center text-xs text-gray-500 mt-8">
        <p>Generated by PinFac Quote System</p>
      </div>
    </div>
  );
};
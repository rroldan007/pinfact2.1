import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader2, Search, Filter, RefreshCw, UserPlus } from 'lucide-react';

interface Client {
  id: string;
  email: string;
  name: string;
  created_at: string;
  subscription: {
    plan_type: string;
    status: string;
  };
  last_login: string;
  last_invoice_date: string;
}

export const AdminClients = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState('all');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchClients();
  }, [planFilter]);

  const fetchClients = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get all users
      let query = supabase
        .from('users')
        .select(`
          id,
          email,
          created_at,
          profiles(first_name, last_name),
          subscriptions(plan_type, status, updated_at),
          (
            SELECT MAX(created_at) 
            FROM invoices 
            WHERE invoices.user_id = users.id
          ) as last_invoice_date
        `);

      // Apply plan filter if not "all"
      if (planFilter !== 'all') {
        query = query.eq('subscriptions.plan_type', planFilter);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Format the data for display
      const formattedClients = data?.map((user: any) => ({
        id: user.id,
        email: user.email,
        name: user.profiles?.[0] 
          ? `${user.profiles[0].first_name || ''} ${user.profiles[0].last_name || ''}`.trim() 
          : 'Sin nombre',
        created_at: user.created_at,
        subscription: user.subscriptions?.[0] || { plan_type: 'free', status: 'active' },
        last_login: user.last_login || 'Nunca',
        last_invoice_date: user.last_invoice_date || 'Sin facturas'
      }));

      setClients(formattedClients || []);
    } catch (err: any) {
      console.error('Error fetching clients:', err);
      setError(err.message || 'Error al cargar los clientes');
    } finally {
      setLoading(false);
    }
  };

  // Filter clients based on search term
  const filteredClients = clients.filter(client => 
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getPlanBadgeClass = (plan: string) => {
    switch(plan) {
      case 'premium': return 'bg-purple-100 text-purple-800';
      case 'standard': return 'bg-blue-100 text-blue-800';
      case 'free': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'trial': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Clientes</h1>
      
      {/* Search and filter controls */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Buscar por nombre o email..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="sm:w-48">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-5 w-5 text-gray-400" />
            </div>
            <select
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              value={planFilter}
              onChange={(e) => setPlanFilter(e.target.value)}
            >
              <option value="all">Todos los planes</option>
              <option value="free">Plan Gratuito</option>
              <option value="standard">Plan Estándar</option>
              <option value="premium">Plan Premium</option>
            </select>
          </div>
        </div>
        
        <button
          onClick={fetchClients}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Actualizar
        </button>
        
        <button
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <UserPlus className="h-4 w-4 mr-2" />
          Nuevo Cliente
        </button>
      </div>
      
      {error && (
        <div className="mb-6 bg-red-50 p-4 rounded-md text-red-800">
          {error}
        </div>
      )}
      
      {/* Clients table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            <p className="text-lg">No se encontraron clientes</p>
            <p className="text-sm mt-1">Intenta con otros criterios de búsqueda</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cliente
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Plan
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Registro
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Última Factura
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredClients.map((client) => (
                  <tr key={client.id} className="hover:bg-gray-50 cursor-pointer">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{client.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{client.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPlanBadgeClass(client.subscription.plan_type)}`}>
                        {client.subscription.plan_type.charAt(0).toUpperCase() + client.subscription.plan_type.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(client.subscription.status)}`}>
                        {client.subscription.status.charAt(0).toUpperCase() + client.subscription.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(client.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {client.last_invoice_date && client.last_invoice_date !== 'Sin facturas'
                        ? new Date(client.last_invoice_date).toLocaleDateString()
                        : 'Sin facturas'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
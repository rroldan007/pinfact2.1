import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '../../lib/supabase';
import { BarChart3, Loader2 } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().email('Por favor, introduce un email válido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
});

type LoginForm = z.infer<typeof loginSchema>;

export const AdminLogin = () => {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [setupAdmin, setSetupAdmin] = useState(false);
  const [hasExistingAdmins, setHasExistingAdmins] = useState<boolean | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  // Check if there are any existing admins
  useEffect(() => {
    const checkExistingAdmins = async () => {
      try {
        // Use RPC function to check admin status
        const { data: adminCount, error: countError } = await supabase
          .rpc('check_admin_count');

        if (!countError) {
          setHasExistingAdmins(adminCount > 0);
          return;
        }

        // Fallback: Try to get at least one admin record
        const { data, error } = await supabase
          .from('admins')
          .select('id')
          .limit(1)
          .maybeSingle();

        // If we get data, there are admins
        setHasExistingAdmins(!!data);
        
      } catch (err) {
        console.error('Error checking for existing admins:', err);
        // Default to assuming admins exist if we can't check
        setHasExistingAdmins(true);
      }
    };

    checkExistingAdmins();
  }, []);

  const onSubmit = async (data: LoginForm) => {
    try {
      setLoading(true);
      setError(null);
      
      // Sign in using Supabase auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (authError) throw authError;
      
      // Check if user is admin using RPC function
      const { data: isAdmin, error: adminError } = await supabase
        .rpc('check_admin_status', {
          checking_user_id: authData.user.id
        });
        
      if (adminError) throw adminError;
      
      // Verify admin status
      if (!isAdmin) {
        throw new Error('No tienes permisos de administrador');
      }
      
      navigate('/admin');
    } catch (error: any) {
      console.error('Error signing in:', error);
      setError(error.message || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  // Setup first admin user
  const setupFirstAdmin = async (data: LoginForm) => {
    try {
      setLoading(true);
      setError(null);

      // Double check there are no existing admins
      const { data: adminCount, error: countError } = await supabase
        .rpc('check_admin_count');

      if (adminCount > 0) {
        setHasExistingAdmins(true);
        throw new Error('Ya existe un administrador. Por favor, inicia sesión.');
      }
      
      // Create the admin user
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
      });
      
      if (signUpError) throw signUpError;
      if (!signUpData.user) throw new Error('No se pudo crear el usuario');

      // Create admin record
      const { error: adminError } = await supabase
        .from('admins')
        .insert({
          user_id: signUpData.user.id,
          role: 'super_admin',
          permissions: {
            can_manage_users: true,
            can_manage_admins: true,
            can_view_payments: true,
            can_manage_settings: true
          }
        });
        
      if (adminError) throw adminError;
      
      // Sign in with the new credentials
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });
      
      if (signInError) throw signInError;
      
      // Navigate to admin panel
      navigate('/admin');
      
    } catch (error: any) {
      console.error('Error setting up admin:', error);
      setError(error.message || 'Error al configurar el administrador');
    } finally {
      setLoading(false);
    }
  };

  // Show loading state while checking for existing admins
  if (hasExistingAdmins === null) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="flex justify-center">
          <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <BarChart3 className="h-12 w-12 text-indigo-600" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          {setupAdmin ? 'Configurar administrador' : 'Acceso de administrador'}
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          {setupAdmin 
            ? 'Configura la primera cuenta de administrador'
            : 'Inicia sesión para acceder al panel de administración'
          }
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit(setupAdmin ? setupFirstAdmin : onSubmit)}>
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700"
              >
                Email
              </label>
              <div className="mt-1">
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  className={`appearance-none block w-full px-3 py-2 border rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${
                    errors.email ? 'border-red-300' : 'border-gray-300'
                  }`}
                  {...register('email')}
                />
                {errors.email && (
                  <p className="mt-2 text-sm text-red-600">
                    {errors.email.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                Contraseña
              </label>
              <div className="mt-1">
                <input
                  id="password"
                  type="password"
                  autoComplete={setupAdmin ? 'new-password' : 'current-password'}
                  className={`appearance-none block w-full px-3 py-2 border rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${
                    errors.password ? 'border-red-300' : 'border-gray-300'
                  }`}
                  {...register('password')}
                />
                {errors.password && (
                  <p className="mt-2 text-sm text-red-600">
                    {errors.password.message}
                  </p>
                )}
              </div>
            </div>

            {error && (
              <div className="rounded-md bg-red-50 p-4">
                <div className="flex">
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">{error}</h3>
                  </div>
                </div>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                    {setupAdmin ? 'Configurando...' : 'Iniciando sesión...'}
                  </>
                ) : (
                  setupAdmin ? 'Configurar administrador' : 'Iniciar sesión'
                )}
              </button>
            </div>
          </form>

          {/* Only show the toggle if no admins exist */}
          {!hasExistingAdmins && (
            <div className="mt-6">
              <button
                onClick={() => setSetupAdmin(!setupAdmin)}
                className="w-full text-center text-sm text-indigo-600 hover:text-indigo-500"
              >
                {setupAdmin 
                  ? '¿Ya tienes una cuenta? Inicia sesión'
                  : '¿Necesitas configurar un administrador?'
                }
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
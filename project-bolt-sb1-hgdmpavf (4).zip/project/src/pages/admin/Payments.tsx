import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader2, Search, Filter, Calendar, RefreshCw, Download } from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from 'recharts';

interface Payment {
  id: string;
  user_id: string;
  user_email: string;
  amount: number;
  status: string;
  payment_method: string;
  created_at: string;
  invoice_id?: string;
  invoice_number?: string;
}

interface PaymentStats {
  totalRevenue: number;
  revenueThisMonth: number;
  paymentsMade: number;
  averageValue: number;
  dailyRevenue: { date: string; amount: number }[];
  methodBreakdown: { name: string; value: number }[];
}

export const AdminPayments = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [stats, setStats] = useState<PaymentStats>({
    totalRevenue: 0,
    revenueThisMonth: 0,
    paymentsMade: 0,
    averageValue: 0,
    dailyRevenue: [],
    methodBreakdown: []
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState('30days'); // 7days, 30days, 90days, 365days
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPayments();
  }, [statusFilter, dateRange]);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      setError(null);

      // Calculate date range
      const endDate = new Date();
      let startDate = new Date();
      
      switch (dateRange) {
        case '7days':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case '90days':
          startDate.setDate(endDate.getDate() - 90);
          break;
        case '365days':
          startDate.setDate(endDate.getDate() - 365);
          break;
        default: // 30days
          startDate.setDate(endDate.getDate() - 30);
      }

      // Fetch all payments
      let query = supabase
        .from('payments')
        .select(`
          id,
          user_id,
          amount,
          status,
          payment_method,
          created_at,
          invoice_id,
          users(email)
        `)
        .gte('created_at', startDate.toISOString());

      // Apply status filter if not "all"
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Format the data for display
      const formattedPayments = data?.map((payment: any) => ({
        id: payment.id,
        user_id: payment.user_id,
        user_email: payment.users?.email || 'Unknown',
        amount: payment.amount,
        status: payment.status,
        payment_method: payment.payment_method,
        created_at: payment.created_at,
        invoice_id: payment.invoice_id
      }));

      setPayments(formattedPayments || []);

      // Calculate stats
      if (data) {
        // Total revenue
        const totalRevenue = data.reduce((sum, payment) => sum + payment.amount, 0);
        
        // Revenue this month
        const thisMonth = new Date().getMonth();
        const revenueThisMonth = data
          .filter(p => new Date(p.created_at).getMonth() === thisMonth)
          .reduce((sum, p) => sum + p.amount, 0);
        
        // Average value
        const averageValue = totalRevenue / (data.length || 1);
        
        // Daily revenue (for chart)
        const dailyData: Record<string, number> = {};
        const days = 30; // Show last 30 days
        
        // Initialize all days with 0
        for (let i = 0; i < days; i++) {
          const day = new Date();
          day.setDate(day.getDate() - i);
          const dayString = day.toISOString().split('T')[0];
          dailyData[dayString] = 0;
        }
        
        // Sum up payments by day
        data.forEach(payment => {
          const day = payment.created_at.split('T')[0];
          if (dailyData[day] !== undefined) {
            dailyData[day] += payment.amount;
          }
        });
        
        const dailyRevenue = Object.entries(dailyData)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([date, amount]) => ({ 
            date: date.substring(5), // Format as MM-DD
            amount 
          }));
        
        // Payment method breakdown
        const methodCounts: Record<string, number> = {};
        data.forEach(payment => {
          const method = payment.payment_method || 'Unknown';
          methodCounts[method] = (methodCounts[method] || 0) + 1;
        });
        
        const methodBreakdown = Object.entries(methodCounts)
          .map(([name, value]) => ({ name, value }));
        
        setStats({
          totalRevenue,
          revenueThisMonth,
          paymentsMade: data.length,
          averageValue,
          dailyRevenue,
          methodBreakdown
        });
      }
    } catch (err: any) {
      console.error('Error fetching payments:', err);
      setError(err.message || 'Error al cargar los pagos');
    } finally {
      setLoading(false);
    }
  };

  // Filter payments based on search term
  const filteredPayments = payments.filter(payment => 
    payment.user_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    payment.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (payment.invoice_id && payment.invoice_id.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getStatusBadgeClass = (status: string) => {
    switch(status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'refunded': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const COLORS = ['#60A5FA', '#34D399', '#F87171', '#FBBF24'];

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Pagos</h1>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 shadow rounded-lg">
          <p className="text-sm text-gray-500">Ingresos Totales</p>
          <p className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</p>
        </div>
        <div className="bg-white p-4 shadow rounded-lg">
          <p className="text-sm text-gray-500">Ingresos Este Mes</p>
          <p className="text-2xl font-bold">${stats.revenueThisMonth.toFixed(2)}</p>
        </div>
        <div className="bg-white p-4 shadow rounded-lg">
          <p className="text-sm text-gray-500">Pagos Realizados</p>
          <p className="text-2xl font-bold">{stats.paymentsMade}</p>
        </div>
        <div className="bg-white p-4 shadow rounded-lg">
          <p className="text-sm text-gray-500">Valor Medio</p>
          <p className="text-2xl font-bold">${stats.averageValue.toFixed(2)}</p>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Revenue Chart */}
        <div className="bg-white p-4 shadow rounded-lg">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Ingresos Diarios</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.dailyRevenue}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value}`, 'Ingresos']} />
                <Line 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#6366F1" 
                  strokeWidth={2}
                  dot={{ fill: '#6366F1' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Payment Method Chart */}
        <div className="bg-white p-4 shadow rounded-lg">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Métodos de Pago</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.methodBreakdown} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip />
                <Bar dataKey="value" name="Cantidad" radius={[0, 4, 4, 0]}>
                  {stats.methodBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Filters */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Buscar por email, ID o factura..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="sm:w-48">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-5 w-5 text-gray-400" />
            </div>
            <select
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Todos los estados</option>
              <option value="completed">Completados</option>
              <option value="pending">Pendientes</option>
              <option value="failed">Fallidos</option>
              <option value="refunded">Reembolsados</option>
            </select>
          </div>
        </div>
        
        <div className="sm:w-48">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Calendar className="h-5 w-5 text-gray-400" />
            </div>
            <select
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
            >
              <option value="7days">Últimos 7 días</option>
              <option value="30days">Últimos 30 días</option>
              <option value="90days">Últimos 90 días</option>
              <option value="365days">Último año</option>
            </select>
          </div>
        </div>
        
        <button
          onClick={fetchPayments}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Actualizar
        </button>
        
        <button
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Download className="h-4 w-4 mr-2" />
          Exportar
        </button>
      </div>
      
      {error && (
        <div className="mb-6 bg-red-50 p-4 rounded-md text-red-800">
          {error}
        </div>
      )}
      
      {/* Payments table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
          </div>
        ) : filteredPayments.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            <p className="text-lg">No se encontraron pagos</p>
            <p className="text-sm mt-1">Intenta con otros criterios de búsqueda</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cliente
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cantidad
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Método
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fecha
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600">
                      {payment.id.substring(0, 8)}...
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {payment.user_email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      ${payment.amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {payment.payment_method || 'Credit Card'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(payment.status)}`}>
                        {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(payment.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
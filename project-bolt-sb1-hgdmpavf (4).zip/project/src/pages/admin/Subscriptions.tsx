import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { 
  BarChart, PieChart, Pie, Cell, ResponsiveContainer, Tooltip, 
  Bar, XAxis, YAxis, CartesianGrid, Legend
} from 'recharts';
import { Loader2, TrendingUp, Users, CreditCard } from 'lucide-react';

interface SubscriptionStats {
  totalSubscriptions: number;
  activeSubscriptions: number;
  planDistribution: { name: string; value: number }[];
  planGrowth: { month: string; free: number; standard: number; premium: number }[];
  retentionRate: number;
  churnRate: number;
  averageRevenue: number;
}

const COLORS = ['#94A3B8', '#60A5FA', '#818CF8'];

export const AdminSubscriptions = () => {
  const [stats, setStats] = useState<SubscriptionStats>({
    totalSubscriptions: 0,
    activeSubscriptions: 0,
    planDistribution: [],
    planGrowth: [],
    retentionRate: 0,
    churnRate: 0,
    averageRevenue: 0
  });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState('6months'); // Options: 1month, 3months, 6months, 1year

  useEffect(() => {
    fetchSubscriptionData();
  }, [timeRange]);

  const fetchSubscriptionData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get date range
      const endDate = new Date();
      let startDate = new Date();
      
      switch (timeRange) {
        case '1month':
          startDate.setMonth(endDate.getMonth() - 1);
          break;
        case '3months':
          startDate.setMonth(endDate.getMonth() - 3);
          break;
        case '1year':
          startDate.setFullYear(endDate.getFullYear() - 1);
          break;
        default: // 6months
          startDate.setMonth(endDate.getMonth() - 6);
      }

      // Fetch subscriptions data
      const { data: subscriptionsData, error: subscriptionsError } = await supabase
        .from('subscriptions')
        .select('plan_type, status, created_at, updated_at');
        
      if (subscriptionsError) throw subscriptionsError;

      // Calculate plan distribution
      const planCount = {
        free: 0,
        standard: 0,
        premium: 0
      };
      
      subscriptionsData?.forEach(sub => {
        if (sub.plan_type in planCount) {
          planCount[sub.plan_type as keyof typeof planCount]++;
        }
      });
      
      const planDistribution = Object.entries(planCount).map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        value
      }));

      // Calculate active subscriptions
      const activeSubscriptions = subscriptionsData?.filter(sub => sub.status === 'active').length || 0;

      // Generate mock retention and churn rates
      const retentionRate = 85 + Math.random() * 10; // Between 85-95%
      const churnRate = 100 - retentionRate;

      // Generate mock average revenue
      const averageRevenue = 45 + Math.random() * 30; // Between $45-75

      // Generate mock growth data for chart
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const currentMonth = new Date().getMonth();
      
      const planGrowth = Array(6).fill(null).map((_, index) => {
        const monthIndex = (currentMonth - 5 + index) % 12;
        const month = months[monthIndex >= 0 ? monthIndex : monthIndex + 12];
        
        // Create some realistic growth patterns
        const baseFree = 40 + index * 5;
        const baseStandard = 25 + index * 3;
        const basePremium = 10 + index * 2;
        
        // Add some random variation
        const free = Math.max(0, baseFree + Math.floor(Math.random() * 10 - 5));
        const standard = Math.max(0, baseStandard + Math.floor(Math.random() * 8 - 4));
        const premium = Math.max(0, basePremium + Math.floor(Math.random() * 5 - 2));
        
        return { month, free, standard, premium };
      });

      // Set data
      setStats({
        totalSubscriptions: subscriptionsData?.length || 0,
        activeSubscriptions,
        planDistribution,
        planGrowth,
        retentionRate,
        churnRate,
        averageRevenue
      });
    } catch (err: any) {
      console.error('Error fetching subscription data:', err);
      setError(err.message || 'Failed to load subscription data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-red-50 rounded-lg text-red-800">
        {error}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Suscripciones</h1>
        
        <div className="flex space-x-2">
          <select
            className="border border-gray-300 rounded-md text-sm px-3 py-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          >
            <option value="1month">Último mes</option>
            <option value="3months">Últimos 3 meses</option>
            <option value="6months">Últimos 6 meses</option>
            <option value="1year">Último año</option>
          </select>
          
          <button
            onClick={fetchSubscriptionData}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Actualizar
          </button>
        </div>
      </div>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-indigo-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Suscripciones</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.totalSubscriptions}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Suscripciones Activas</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.activeSubscriptions}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-amber-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Tasa de Retención</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.retentionRate.toFixed(1)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Ingreso Medio</p>
              <p className="text-2xl font-semibold text-gray-900">${stats.averageRevenue.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Plan Distribution */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Distribución de Planes</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.planDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                >
                  {stats.planDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value} usuarios`, 'Cantidad']} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Growth Trend */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Tendencia de Crecimiento</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.planGrowth}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="free" name="Gratuito" stackId="a" fill={COLORS[0]} />
                <Bar dataKey="standard" name="Estándar" stackId="a" fill={COLORS[1]} />
                <Bar dataKey="premium" name="Premium" stackId="a" fill={COLORS[2]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Additional metrics */}
      <div className="grid grid-cols-1 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Indicadores de Rendimiento</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-sm text-gray-500">Tasa de Conversión</p>
              <p className="text-2xl font-bold text-indigo-600">18.2%</p>
              <p className="text-xs text-gray-400 mt-1">+2.1% vs mes anterior</p>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-sm text-gray-500">Tasa de Abandono</p>
              <p className="text-2xl font-bold text-red-600">{stats.churnRate.toFixed(1)}%</p>
              <p className="text-xs text-gray-400 mt-1">-0.8% vs mes anterior</p>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-sm text-gray-500">Tiempo Medio de Suscripción</p>
              <p className="text-2xl font-bold text-green-600">7.4 meses</p>
              <p className="text-xs text-gray-400 mt-1">+0.3 vs mes anterior</p>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-sm text-gray-500">Valor de Cliente (LTV)</p>
              <p className="text-2xl font-bold text-amber-600">$342.50</p>
              <p className="text-xs text-gray-400 mt-1">+$12.75 vs mes anterior</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
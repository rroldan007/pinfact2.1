import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader2, Save, UserPlus, Users, Shield } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

interface Admin {
  id: string;
  user_id: string;
  role: string;
  permissions: any;
  created_at: string;
  email?: string;
}

const newAdminSchema = z.object({
  email: z.string().email('Email inválido'),
  role: z.enum(['admin', 'super_admin']),
  permissions: z.object({
    can_manage_users: z.boolean().default(false),
    can_manage_admins: z.boolean().default(false),
    can_view_payments: z.boolean().default(true),
    can_manage_settings: z.boolean().default(false)
  }).optional()
});

type NewAdminForm = z.infer<typeof newAdminSchema>;

export const AdminSettings = () => {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showAdminForm, setShowAdminForm] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<NewAdminForm>({
    resolver: zodResolver(newAdminSchema),
    defaultValues: {
      role: 'admin',
      permissions: {
        can_manage_users: false,
        can_manage_admins: false,
        can_view_payments: true,
        can_manage_settings: false
      }
    }
  });

  useEffect(() => {
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get all admins
      const { data: adminData, error: adminError } = await supabase
        .from('admins')
        .select('*')
        .order('created_at', { ascending: false });

      if (adminError) throw adminError;

      // Get user emails for each admin
      if (adminData && adminData.length > 0) {
        const userIds = adminData.map(admin => admin.user_id);
        
        const { data: userData, error: userError } = await supabase
          .from('users')
          .select('id, email')
          .in('id', userIds);
          
        if (userError) throw userError;
        
        // Merge admin data with user emails
        const mergedData = adminData.map(admin => {
          const user = userData?.find(u => u.id === admin.user_id);
          return {
            ...admin,
            email: user?.email
          };
        });
        
        setAdmins(mergedData);
      } else {
        setAdmins([]);
      }
    } catch (err: any) {
      console.error('Error fetching admins:', err);
      setError(err.message || 'Error al cargar administradores');
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: NewAdminForm) => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);

      // First check if the user exists
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('email', data.email)
        .single();

      if (userError) {
        if (userError.code === 'PGRST116') {
          throw new Error(`No existe un usuario con el email ${data.email}`);
        }
        throw userError;
      }

      // Check if user is already an admin
      const { data: existingAdmin, error: adminCheckError } = await supabase
        .from('admins')
        .select('id')
        .eq('user_id', userData.id)
        .single();

      if (existingAdmin) {
        throw new Error('Este usuario ya es un administrador');
      }

      // Add user as admin
      const { error: insertError } = await supabase
        .from('admins')
        .insert({
          user_id: userData.id,
          role: data.role,
          permissions: data.permissions
        });

      if (insertError) throw insertError;

      setSuccess('Administrador añadido correctamente');
      reset();
      setShowAdminForm(false);
      fetchAdmins();
    } catch (err: any) {
      console.error('Error adding admin:', err);
      setError(err.message || 'Error al añadir administrador');
    } finally {
      setSaving(false);
    }
  };

  const removeAdmin = async (adminId: string) => {
    if (!confirm('¿Estás seguro que deseas eliminar este administrador?')) {
      return;
    }

    try {
      setError(null);
      setSuccess(null);

      const { error } = await supabase
        .from('admins')
        .delete()
        .eq('id', adminId);

      if (error) throw error;

      setSuccess('Administrador eliminado correctamente');
      fetchAdmins();
    } catch (err: any) {
      console.error('Error removing admin:', err);
      setError(err.message || 'Error al eliminar administrador');
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Configuración</h1>
      
      {/* General Settings Section */}
      <div className="bg-white shadow rounded-lg mb-6">
        <div className="px-4 py-5 sm:p-6">
          <h2 className="text-lg leading-6 font-medium text-gray-900">Configuración General</h2>
          <div className="mt-2 max-w-xl text-sm text-gray-500">
            <p>Configura los ajustes generales de la plataforma.</p>
          </div>
          
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="company_name" className="block text-sm font-medium text-gray-700">
                Nombre de la Empresa
              </label>
              <input
                type="text"
                name="company_name"
                id="company_name"
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                defaultValue="PinFac"
              />
            </div>
            
            <div>
              <label htmlFor="support_email" className="block text-sm font-medium text-gray-700">
                Email de Soporte
              </label>
              <input
                type="email"
                name="support_email"
                id="support_email"
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                defaultValue="soporte@pinfac.com"
              />
            </div>
          </div>

          <div className="mt-4 space-y-4">
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="allow_signups"
                  name="allow_signups"
                  type="checkbox"
                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                  defaultChecked
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="allow_signups" className="font-medium text-gray-700">Permitir Registros</label>
                <p className="text-gray-500">Permitir que nuevos usuarios se registren en la plataforma</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="require_email_verification"
                  name="require_email_verification"
                  type="checkbox"
                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                  defaultChecked
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="require_email_verification" className="font-medium text-gray-700">Requerir Verificación de Email</label>
                <p className="text-gray-500">Los usuarios deben verificar su email antes de usar la plataforma</p>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Save className="h-4 w-4 mr-2" />
              Guardar Cambios
            </button>
          </div>
        </div>
      </div>
      
      {/* Administrators Section */}
      <div className="bg-white shadow rounded-lg mb-6">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex justify-between items-center">
            <h2 className="text-lg leading-6 font-medium text-gray-900">Administradores</h2>
            <button
              onClick={() => setShowAdminForm(!showAdminForm)}
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {showAdminForm ? (
                <>
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Añadir Administrador
                </>
              )}
            </button>
          </div>
          
          <div className="mt-2 max-w-xl text-sm text-gray-500">
            <p>Gestiona quién tiene acceso de administrador a la plataforma.</p>
          </div>
          
          {error && (
            <div className="mt-4 bg-red-50 p-4 rounded-md text-red-800">
              {error}
            </div>
          )}
          
          {success && (
            <div className="mt-4 bg-green-50 p-4 rounded-md text-green-800">
              {success}
            </div>
          )}
          
          {showAdminForm && (
            <div className="mt-5 bg-gray-50 p-4 rounded-md">
              <h3 className="text-md font-medium text-gray-900 mb-4">Añadir Nuevo Administrador</h3>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email del Usuario *
                  </label>
                  <input
                    type="email"
                    id="email"
                    className={`mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${errors.email ? 'border-red-300' : ''}`}
                    {...register('email')}
                    placeholder="email@ejemplo.com"
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                    Rol *
                  </label>
                  <select
                    id="role"
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    {...register('role')}
                  >
                    <option value="admin">Administrador</option>
                    <option value="super_admin">Super Administrador</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Permisos
                  </label>
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="can_manage_users"
                          {...register('permissions.can_manage_users')}
                          type="checkbox"
                          className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="can_manage_users" className="font-medium text-gray-700">Gestionar Usuarios</label>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="can_manage_admins"
                          {...register('permissions.can_manage_admins')}
                          type="checkbox"
                          className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="can_manage_admins" className="font-medium text-gray-700">Gestionar Administradores</label>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="can_view_payments"
                          {...register('permissions.can_view_payments')}
                          type="checkbox"
                          className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="can_view_payments" className="font-medium text-gray-700">Ver Pagos</label>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="can_manage_settings"
                          {...register('permissions.can_manage_settings')}
                          type="checkbox"
                          className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="can_manage_settings" className="font-medium text-gray-700">Gestionar Configuración</label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowAdminForm(false)}
                    className="mr-3 bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
                  >
                    {saving ? (
                      <>
                        <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                        Guardando...
                      </>
                    ) : (
                      <>
                        <Save className="-ml-1 mr-2 h-4 w-4" />
                        Guardar
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}
          
          <div className="mt-5">
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
              </div>
            ) : admins.length === 0 ? (
              <div className="bg-gray-50 p-4 rounded-md text-center">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-gray-100 mb-3">
                  <Users className="h-6 w-6 text-gray-500" />
                </div>
                <p className="text-gray-500">No hay administradores configurados</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rol
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Permisos
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fecha Creación
                      </th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Acciones</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {admins.map((admin) => (
                      <tr key={admin.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {admin.email || 'Unknown'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            admin.role === 'super_admin' 
                              ? 'bg-purple-100 text-purple-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex space-x-1">
                            {admin.permissions && admin.permissions.can_manage_users && (
                              <span className="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800">Users</span>
                            )}
                            {admin.permissions && admin.permissions.can_manage_admins && (
                              <span className="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800">Admins</span>
                            )}
                            {admin.permissions && admin.permissions.can_view_payments && (
                              <span className="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800">Payments</span>
                            )}
                            {admin.permissions && admin.permissions.can_manage_settings && (
                              <span className="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800">Settings</span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(admin.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => removeAdmin(admin.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            Eliminar
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Security Settings Section */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center">
            <Shield className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-lg leading-6 font-medium text-gray-900">Seguridad</h2>
          </div>
          
          <div className="mt-2 max-w-xl text-sm text-gray-500">
            <p>Configura los ajustes de seguridad de la plataforma.</p>
          </div>
          
          <div className="mt-5 space-y-4">
            <div>
              <label htmlFor="password_policy" className="block text-sm font-medium text-gray-700">
                Política de Contraseñas
              </label>
              <select
                id="password_policy"
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                defaultValue="medium"
              >
                <option value="low">Básica (mínimo 6 caracteres)</option>
                <option value="medium">Media (mínimo 8 caracteres, letras y números)</option>
                <option value="high">Alta (mínimo 10 caracteres, letras, números y símbolos)</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="session_timeout" className="block text-sm font-medium text-gray-700">
                Tiempo de Sesión (minutos)
              </label>
              <input
                type="number"
                id="session_timeout"
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                defaultValue="60"
                min="5"
                max="1440"
              />
            </div>
            
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="enable_2fa"
                  name="enable_2fa"
                  type="checkbox"
                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="enable_2fa" className="font-medium text-gray-700">Habilitar 2FA</label>
                <p className="text-gray-500">Requerir autenticación de dos factores para todos los administradores</p>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Save className="h-4 w-4 mr-2" />
              Guardar Configuración
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell
} from 'recharts';
import { 
  Users, CreditCard, FileText, Package, TrendingUp, 
  AlertCircle, CheckCircle, Clock, Ban
} from 'lucide-react';

interface DashboardStats {
  totalCustomers: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  customersByPlan: {
    free: number;
    standard: number;
    premium: number;
  };
  invoicesLastMonth: number;
  revenueHistory: Array<{
    month: string;
    revenue: number;
    invoices: number;
  }>;
  paymentStatus: {
    completed: number;
    pending: number;
    failed: number;
  };
}

const COLORS = {
  free: '#94A3B8',
  standard: '#60A5FA',
  premium: '#818CF8',
  completed: '#34D399',
  pending: '#FBBF24',
  failed: '#F87171'
};

export const AdminDashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalCustomers: 0,
    monthlyRevenue: 0,
    yearlyRevenue: 0,
    customersByPlan: { free: 0, standard: 0, premium: 0 },
    invoicesLastMonth: 0,
    revenueHistory: [],
    paymentStatus: { completed: 0, pending: 0, failed: 0 }
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Get current user to verify admin status
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Not authenticated');

        // Verify admin role (you should implement proper role checking)
        const { data: adminCheck } = await supabase
          .from('admins')
          .select('role')
          .eq('user_id', user.id)
          .single();

        if (!adminCheck || adminCheck.role !== 'admin') {
          throw new Error('Unauthorized access');
        }

        // Fetch all required data in parallel
        const [
          customersResult,
          revenueResult,
          invoicesResult,
          plansResult,
          paymentsResult
        ] = await Promise.all([
          // Total customers
          supabase
            .from('users')
            .select('id', { count: 'exact' }),

          // Revenue data
          supabase
            .from('payments')
            .select('amount, created_at')
            .gte('created_at', new Date(new Date().getFullYear(), 0, 1).toISOString()),

          // Recent invoices
          supabase
            .from('invoices')
            .select('id, created_at')
            .gte('created_at', new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString()),

          // Customers by plan
          supabase
            .from('subscriptions')
            .select('plan_type, count', { count: 'exact' })
            .in('plan_type', ['free', 'standard', 'premium'])
            .group('plan_type'),

          // Payment status
          supabase
            .from('payments')
            .select('status, count', { count: 'exact' })
            .in('status', ['completed', 'pending', 'failed'])
            .group('status')
        ]);

        // Process revenue history
        const revenueByMonth = revenueResult.data?.reduce((acc: any, payment) => {
          const month = new Date(payment.created_at).toLocaleString('default', { month: 'short' });
          if (!acc[month]) acc[month] = { revenue: 0, invoices: 0 };
          acc[month].revenue += payment.amount;
          return acc;
        }, {});

        // Transform data for charts
        const revenueHistory = Object.entries(revenueByMonth || {}).map(([month, data]: [string, any]) => ({
          month,
          revenue: data.revenue,
          invoices: data.invoices
        }));

        // Calculate totals
        const monthlyRevenue = revenueResult.data
          ?.filter(p => new Date(p.created_at).getMonth() === new Date().getMonth())
          .reduce((sum, p) => sum + p.amount, 0) || 0;

        const yearlyRevenue = revenueResult.data
          ?.reduce((sum, p) => sum + p.amount, 0) || 0;

        // Process plans data
        const planCounts = plansResult.data?.reduce((acc: any, plan) => {
          acc[plan.plan_type] = plan.count;
          return acc;
        }, { free: 0, standard: 0, premium: 0 });

        // Process payment status
        const paymentCounts = paymentsResult.data?.reduce((acc: any, status) => {
          acc[status.status] = status.count;
          return acc;
        }, { completed: 0, pending: 0, failed: 0 });

        setStats({
          totalCustomers: customersResult.count || 0,
          monthlyRevenue,
          yearlyRevenue,
          customersByPlan: planCounts,
          invoicesLastMonth: invoicesResult.count || 0,
          revenueHistory,
          paymentStatus: paymentCounts
        });

      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-lg text-red-800">
        <AlertCircle className="h-5 w-5 inline mr-2" />
        {error}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-indigo-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Customers</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.totalCustomers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <CreditCard className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
              <p className="text-2xl font-semibold text-gray-900">
                ${stats.monthlyRevenue.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <FileText className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Invoices (Last Month)</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.invoicesLastMonth}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Yearly Revenue</p>
              <p className="text-2xl font-semibold text-gray-900">
                ${stats.yearlyRevenue.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue History */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Revenue History</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.revenueHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#6366F1" 
                  strokeWidth={2}
                  dot={{ fill: '#6366F1' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Customers by Plan */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Customers by Plan</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[
                { name: 'Free', value: stats.customersByPlan.free },
                { name: 'Standard', value: stats.customersByPlan.standard },
                { name: 'Premium', value: stats.customersByPlan.premium }
              ]}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value">
                  {[COLORS.free, COLORS.standard, COLORS.premium].map((color, index) => (
                    <Cell key={`cell-${index}`} fill={color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Payment Status Distribution */}
        <div className="bg-white p-6 rounded-lg shadow lg:col-span-2">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Payment Status Distribution</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { name: 'Completed', value: stats.paymentStatus.completed },
                    { name: 'Pending', value: stats.paymentStatus.pending },
                    { name: 'Failed', value: stats.paymentStatus.failed }
                  ]}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label
                >
                  {[COLORS.completed, COLORS.pending, COLORS.failed].map((color, index) => (
                    <Cell key={`cell-${index}`} fill={color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-4">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-green-400 mr-2"></div>
                <span className="text-sm text-gray-600">Completed</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-yellow-400 mr-2"></div>
                <span className="text-sm text-gray-600">Pending</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-400 mr-2"></div>
                <span className="text-sm text-gray-600">Failed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
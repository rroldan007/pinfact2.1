import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, addDays } from 'date-fns';
import { Save, Plus, Trash2, Loader2 } from 'lucide-react';

type Client = {
  id: string;
  name: string;
  email: string | null;
  address: string | null;
};

type Product = {
  id: string;
  name: string;
  price: number;
  tax_rate: number;
  description: string | null;
};

type CompanySettings = {
  default_payment_terms: number;
  default_tax_rate: number;
  invoice_prefix: string;
  next_invoice_number: number;
};

const invoiceItemSchema = z.object({
  id: z.string().optional(),
  description: z.string().min(1, 'Description is required'),
  secondary_description: z.string().optional().nullable(),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  unit_price: z.number().min(0, 'Price must be a positive number'),
  tax_rate: z.number().min(0, 'Tax rate must be a positive number'),
  product_id: z.string().optional().nullable(),
  total: z.number().min(0)
});

const invoiceSchema = z.object({
  client_id: z.string().min(1, 'Client is required'),
  invoice_number: z.string().min(1, 'Invoice number is required'),
  date: z.string().min(1, 'Date is required'),
  due_date: z.string().min(1, 'Due date is required'),
  status: z.enum(['draft', 'sent', 'paid', 'overdue', 'cancelled']).default('draft'),
  notes: z.string().optional().nullable(),
  terms: z.string().optional().nullable(),
  items: z.array(invoiceItemSchema).min(1, 'At least one item is required'),
  subtotal: z.number().min(0),
  tax_amount: z.number().min(0),
  total: z.number().min(0)
});

type InvoiceForm = z.infer<typeof invoiceSchema>;

export const CreateInvoice = () => {
  const { id } = useParams<{ id: string }>();
  const [clients, setClients] = useState<Client[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingStatus, setLoadingStatus] = useState({
    clients: true,
    products: true,
    companySettings: true,
    invoice: id ? true : false,
    overall: true
  });
  const [saving, setSaving] = useState(false);
  const [companySettings, setCompanySettings] = useState<CompanySettings | null>(null);
  const [isEditMode, setIsEditMode] = useState(!!id);
  const navigate = useNavigate();
  const invoiceItemsRef = useRef<HTMLDivElement>(null);
  const latestItemRef = useRef<HTMLSelectElement>(null);
  const lastItemAddedRef = useRef<HTMLElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [rowsToRender, setRowsToRender] = useState(10);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showAddClient, setShowAddClient] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    setValue,
    watch,
    getValues,
    reset,
    formState: { errors },
  } = useForm<InvoiceForm>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      due_date: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
      status: 'draft',
      items: [
        {
          description: '',
          secondary_description: '',
          quantity: 1,
          unit_price: 0,
          tax_rate: 7.7,
          total: 0
        }
      ],
      subtotal: 0,
      tax_amount: 0,
      total: 0
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items'
  });

  const watchItems = watch('items');
  const watchedClientId = watch('client_id');

  // Calculate item total whenever quantity or unit_price changes
  const calculateItemTotal = useCallback((index: number) => {
    try {
      const quantity = getValues(`items.${index}.quantity`) || 0;
      const unitPrice = getValues(`items.${index}.unit_price`) || 0;
      const total = quantity * unitPrice;
      
      setValue(`items.${index}.total`, total);
    } catch (err) {
      console.error("Error calculating item total:", err);
    }
  }, [getValues, setValue]);

  // Calculate invoice totals
  const calculateInvoiceTotals = useCallback(() => {
    try {
      const items = getValues('items');
      let subtotal = 0;
      let taxAmount = 0;
      
      items.forEach((item) => {
        if (item) {
          const itemTotal = (item.quantity || 0) * (item.unit_price || 0);
          subtotal += itemTotal;
          taxAmount += itemTotal * ((item.tax_rate || 0) / 100);
        }
      });
      
      setValue('subtotal', subtotal);
      setValue('tax_amount', taxAmount);
      setValue('total', subtotal + taxAmount);
    } catch (err) {
      console.error("Error calculating invoice totals:", err);
    }
  }, [getValues, setValue]);

  // Use debounced version for intensive operations
  const debouncedCalculateInvoiceTotals = useCallback(() => {
    const handler = setTimeout(() => {
      calculateInvoiceTotals();
    }, 100);
    
    return () => {
      clearTimeout(handler);
    };
  }, [calculateInvoiceTotals]);

  // Calculate totals whenever items change
  useEffect(() => {
    if (watchItems) {
      debouncedCalculateInvoiceTotals();
    }
  }, [watchItems, debouncedCalculateInvoiceTotals]);

  // Focus on the newly added item's product selector
  useEffect(() => {
    if (latestItemRef.current) {
      latestItemRef.current.focus();
    }
    
    // Scroll to the last added item if available
    if (lastItemAddedRef.current) {
      setTimeout(() => {
        if (lastItemAddedRef.current) {
          lastItemAddedRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
          lastItemAddedRef.current = null;
        }
      }, 100);
    }
  }, [fields.length]);

  // Fetch invoice data if in edit mode
  const fetchInvoiceData = useCallback(async () => {
    if (!id) return;

    try {
      setLoadingStatus(prev => ({ ...prev, invoice: true }));
      
      const { data: invoiceData, error: invoiceError } = await supabase
        .from('invoices')
        .select(`
          *,
          items:invoice_items(*)
        `)
        .eq('id', id)
        .single();
      
      if (invoiceError) throw invoiceError;
      
      if (invoiceData) {
        // Only allow editing invoices in draft or sent status
        if (invoiceData.status !== 'draft' && invoiceData.status !== 'sent') {
          setError(`This invoice cannot be edited because its status is "${invoiceData.status}". Only draft and sent invoices can be edited.`);
          setLoadingStatus(prev => ({ ...prev, invoice: false, overall: false }));
          return;
        }

        // Format dates to YYYY-MM-DD
        const formattedDate = format(new Date(invoiceData.date), 'yyyy-MM-dd');
        const formattedDueDate = format(new Date(invoiceData.due_date), 'yyyy-MM-dd');

        // Set form values
        setValue('client_id', invoiceData.client_id);
        setValue('invoice_number', invoiceData.invoice_number);
        setValue('date', formattedDate);
        setValue('due_date', formattedDueDate);
        setValue('status', invoiceData.status);
        setValue('notes', invoiceData.notes);
        setValue('terms', invoiceData.terms);
        setValue('subtotal', invoiceData.subtotal);
        setValue('tax_amount', invoiceData.tax_amount);
        setValue('total', invoiceData.total);

        // Clear default items and add the ones from the invoice
        if (invoiceData.items && invoiceData.items.length > 0) {
          const formattedItems = invoiceData.items.map(item => ({
            id: item.id,
            description: item.description,
            secondary_description: item.secondary_description,
            quantity: item.quantity,
            unit_price: item.unit_price,
            tax_rate: item.tax_rate,
            product_id: item.product_id,
            total: item.total
          }));
          
          reset({
            ...getValues(),
            items: formattedItems
          });
        }
      }
    } catch (error) {
      console.error('Error fetching invoice:', error);
      setError('Failed to load invoice data. Please try again.');
    } finally {
      setLoadingStatus(prev => ({ ...prev, invoice: false }));
    }
  }, [id, setValue, reset, getValues]);

  // Performance optimization: memoized fetchData function
  const fetchData = useCallback(async () => {
    setLoadingStatus({
      clients: true,
      products: true,
      companySettings: true,
      invoice: id ? true : false,
      overall: true
    });
    setError(null);
    
    try {
      const startTime = performance.now();
      
      // Run all queries in parallel for better performance
      const [clientsResult, productsResult, userData] = await Promise.all([
        // Fetch clients
        supabase
          .from('clients')
          .select('id, name, email, address')
          .order('name'),
          
        // Fetch active products
        supabase
          .from('products')
          .select('id, name, price, tax_rate, description')
          .eq('active', true)
          .order('name'),
          
        // Get current user
        supabase.auth.getUser()
      ]);
      
      setLoadingStatus(prev => ({ ...prev, clients: false, products: false }));
      
      // Handle any errors from the parallel queries
      if (clientsResult.error) throw clientsResult.error;
      if (productsResult.error) throw productsResult.error;
      
      setClients(clientsResult.data || []);
      setProducts(productsResult.data || []);
      
      // Only fetch company settings if we have a user
      if (userData.data.user) {
        const { data: settingsData, error: settingsError } = await supabase
          .from('company_settings')
          .select('default_payment_terms, default_tax_rate, invoice_prefix, next_invoice_number')
          .eq('user_id', userData.data.user.id)
          .single();
          
        setLoadingStatus(prev => ({ ...prev, companySettings: false }));
          
        if (settingsError && settingsError.code !== 'PGRST116') {
          // PGRST116 is "row not found" error, which is fine for new users
          console.warn('No company settings found:', settingsError);
        }
        
        if (settingsData) {
          setCompanySettings(settingsData);
          
          // Only set default values if not in edit mode
          if (!isEditMode) {
            // Set default values from company settings
            const invoiceNumber = `${settingsData.invoice_prefix}${String(settingsData.next_invoice_number).padStart(4, '0')}`;
            setValue('invoice_number', invoiceNumber);
            setValue('due_date', format(addDays(new Date(), settingsData.default_payment_terms), 'yyyy-MM-dd'));
            
            // Set default tax rate for the first item
            if (fields.length > 0) {
              setValue(`items.0.tax_rate`, settingsData.default_tax_rate);
            }
          }
        }
      }
      
      // If in edit mode, fetch the invoice data
      if (isEditMode) {
        await fetchInvoiceData();
      }
      
      const endTime = performance.now();
      console.log(`Data fetching completed in ${endTime - startTime}ms`);
      
    } catch (error: any) {
      console.error('Error fetching data:', error);
      setError(`Failed to load data: ${error.message || 'Unknown error'}`);
    } finally {
      setLoadingStatus(prev => ({ ...prev, overall: false }));
    }
  }, [setValue, fields.length, isEditMode, fetchInvoiceData]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Load more rows as the user scrolls
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      
      // If we're near the bottom and have more rows to render
      if (scrollPosition + windowHeight > documentHeight - 300 && rowsToRender < fields.length) {
        setRowsToRender(prev => Math.min(prev + 5, fields.length));
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [rowsToRender, fields.length]);

  const handleAddItem = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Save current scroll position
    const currentScrollPosition = window.scrollY;
    
    // Add the new item
    append({
      description: '',
      secondary_description: '',
      quantity: 1,
      unit_price: 0,
      tax_rate: companySettings?.default_tax_rate || 7.7,
      product_id: null,
      total: 0
    });
    
    // Set a small timeout to allow the DOM to update
    setTimeout(() => {
      // Restore scroll position first, then scroll to the item
      window.scrollTo(0, currentScrollPosition);
      
      // Find the last row in the table to scroll to
      const tableRows = document.querySelectorAll('table tbody tr');
      if (tableRows.length > 0) {
        lastItemAddedRef.current = tableRows[tableRows.length - 1] as HTMLElement;
      }
    }, 100);
  };

  const handleProductSelect = useCallback((index: number, productId: string) => {
    try {
      const selectedProduct = products.find(p => p.id === productId);
      
      if (selectedProduct) {
        setValue(`items.${index}.description`, selectedProduct.name);
        setValue(`items.${index}.secondary_description`, selectedProduct.description || '');
        setValue(`items.${index}.unit_price`, selectedProduct.price);
        setValue(`items.${index}.tax_rate`, selectedProduct.tax_rate);
        setValue(`items.${index}.product_id`, selectedProduct.id);
        
        // Calculate total for this item
        calculateItemTotal(index);
        calculateInvoiceTotals();
      }
    } catch (err) {
      console.error("Error selecting product:", err);
    }
  }, [products, setValue, calculateItemTotal, calculateInvoiceTotals]);

  const onSubmit = async (data: InvoiceForm) => {
    setSaving(true);
    setError(null);
    
    try {
      // Get the current user
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      if (isEditMode && id) {
        // Update existing invoice
        const { error: invoiceError } = await supabase
          .from('invoices')
          .update({
            client_id: data.client_id,
            invoice_number: data.invoice_number,
            date: data.date,
            due_date: data.due_date,
            status: data.status,
            notes: data.notes,
            terms: data.terms,
            subtotal: data.subtotal,
            tax_amount: data.tax_amount,
            total: data.total,
            updated_at: new Date().toISOString()
          })
          .eq('id', id);
          
        if (invoiceError) throw invoiceError;
        
        // Handle invoice items - first delete existing items
        const { error: deleteError } = await supabase
          .from('invoice_items')
          .delete()
          .eq('invoice_id', id);
          
        if (deleteError) throw deleteError;
        
        // Then insert new items
        const invoiceItems = data.items.map(item => ({
          invoice_id: id,
          description: item.description,
          secondary_description: item.secondary_description,
          quantity: item.quantity,
          unit_price: item.unit_price,
          tax_rate: item.tax_rate,
          product_id: item.product_id,
          total: item.total
        }));
        
        const { error: itemsError } = await supabase
          .from('invoice_items')
          .insert(invoiceItems);
          
        if (itemsError) throw itemsError;
        
      } else {
        // Insert new invoice
        const { data: newInvoice, error: invoiceError } = await supabase
          .from('invoices')
          .insert({
            client_id: data.client_id,
            invoice_number: data.invoice_number,
            date: data.date,
            due_date: data.due_date,
            status: data.status,
            notes: data.notes,
            terms: data.terms,
            subtotal: data.subtotal,
            tax_amount: data.tax_amount,
            total: data.total,
            user_id: user.id // Add user_id to comply with RLS policy
          })
          .select('id')
          .single();
          
        if (invoiceError) throw invoiceError;
        
        // Insert the invoice items
        const invoiceItems = data.items.map(item => ({
          invoice_id: newInvoice.id,
          description: item.description,
          secondary_description: item.secondary_description,
          quantity: item.quantity,
          unit_price: item.unit_price,
          tax_rate: item.tax_rate,
          product_id: item.product_id,
          total: item.total
        }));
        
        const { error: itemsError } = await supabase
          .from('invoice_items')
          .insert(invoiceItems);
          
        if (itemsError) throw itemsError;
        
        // Update next invoice number in company settings if we have company settings
        if (companySettings) {
          const { error: updateError } = await supabase
            .from('company_settings')
            .update({
              next_invoice_number: companySettings.next_invoice_number + 1
            })
            .eq('next_invoice_number', companySettings.next_invoice_number);
            
          if (updateError) {
            console.error('Error updating next invoice number:', updateError);
          }
        }
      }
      
      // Navigate to invoices list
      navigate('/app/invoices');
    } catch (error: any) {
      console.error('Error saving invoice:', error);
      setError(`Failed to save invoice: ${error.message || 'Unknown error'}`);
    } finally {
      setSaving(false);
    }
  };

  // Memoize selected client to prevent unnecessary re-renders
  const selectedClient = useMemo(() => 
    clients.find(c => c.id === watchedClientId),
    [clients, watchedClientId]
  );

  // Show loading state with more detailed information
  if (loadingStatus.overall) {
    return (
      <div className="flex flex-col justify-center items-center h-64">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
        <p className="mt-4 text-gray-600">
          {loadingStatus.clients ? 'Loading clients...' : 
           loadingStatus.products ? 'Loading products...' : 
           loadingStatus.companySettings ? 'Loading company settings...' : 
           loadingStatus.invoice ? 'Loading invoice data...' :
           'Loading...'}
        </p>
      </div>
    );
  }

  // Show error if invoice cannot be edited
  if (error && isEditMode) {
    return (
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">{isEditMode ? 'Edit Invoice' : 'Create Invoice'}</h1>
        <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
          {error}
        </div>
        <div className="mt-4">
          <button
            onClick={() => navigate('/app/invoices')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Back to Invoices
          </button>
        </div>
      </div>
    );
  }

  // Only render visible fields for better performance
  const visibleFields = fields.slice(0, rowsToRender);

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">{isEditMode ? 'Edit Invoice' : 'Create Invoice'}</h1>
      
      {error && (
        <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-8">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <label htmlFor="client_id" className="block text-sm font-medium text-gray-700">
                Client *
              </label>
              <div className="mt-1">
                <select
                  id="client_id"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.client_id ? 'border-red-300' : ''}`}
                  {...register('client_id')}
                >
                  <option value="">Select a client</option>
                  {clients.map(client => (
                    <option key={client.id} value={client.id}>
                      {client.name}
                    </option>
                  ))}
                </select>
                {errors.client_id && (
                  <p className="mt-1 text-sm text-red-600">{errors.client_id.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="invoice_number" className="block text-sm font-medium text-gray-700">
                Invoice Number *
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  id="invoice_number"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.invoice_number ? 'border-red-300' : ''}`}
                  {...register('invoice_number')}
                />
                {errors.invoice_number && (
                  <p className="mt-1 text-sm text-red-600">{errors.invoice_number.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                Invoice Date *
              </label>
              <div className="mt-1">
                <input
                  type="date"
                  id="date"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.date ? 'border-red-300' : ''}`}
                  {...register('date')}
                />
                {errors.date && (
                  <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="due_date" className="block text-sm font-medium text-gray-700">
                Due Date *
              </label>
              <div className="mt-1">
                <input
                  type="date"
                  id="due_date"
                  className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.due_date ? 'border-red-300' : ''}`}
                  {...register('due_date')}
                />
                {errors.due_date && (
                  <p className="mt-1 text-sm text-red-600">{errors.due_date.message}</p>
                )}
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="status" className="block text-sm font-medium text-gray-700">
                Status
              </label>
              <div className="mt-1">
                <select
                  id="status"
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  {...register('status')}
                >
                  <option value="draft">Draft</option>
                  <option value="sent">Sent</option>
                  <option value="paid">Paid</option>
                  <option value="overdue">Overdue</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            </div>
          </div>

          {selectedClient && (
            <div className="mt-6 border-t border-gray-200 pt-6">
              <h3 className="text-lg font-medium text-gray-900">Client Information</h3>
              <div className="mt-2 text-sm text-gray-500">
                <p className="font-medium text-gray-900">{selectedClient.name}</p>
                {selectedClient.email && <p>{selectedClient.email}</p>}
                {selectedClient.address && <p>{selectedClient.address}</p>}
              </div>
            </div>
          )}
        </div>

        <div className="bg-white shadow rounded-lg p-6" ref={invoiceItemsRef}>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Invoice Items</h3>
          
          {errors.items?.message && (
            <p className="text-sm text-red-600 mb-4">{errors.items.message}</p>
          )}
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Item
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                    Qty
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                    Price
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                    Tax %
                  </th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28">
                    Total
                  </th>
                  <th scope="col" className="relative px-3 py-3 w-12">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {visibleFields.map((field, index) => (
                  <tr key={field.id} id={`invoice-item-${index}`}>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <select
                        className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        onChange={(e) => handleProductSelect(index, e.target.value)}
                        value={watchItems[index]?.product_id || ''}
                        ref={index === fields.length - 1 ? latestItemRef : null}
                      >
                        <option value="">Select a product</option>
                        {products.map(product => (
                          <option key={product.id} value={product.id}>
                            {product.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <div className="space-y-1">
                        <input
                          type="text"
                          className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.description ? 'border-red-300' : ''}`}
                          placeholder="Description"
                          {...register(`items.${index}.description`)}
                        />
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Additional details (optional)"
                          {...register(`items.${index}.secondary_description`)}
                        />
                      </div>
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        min="1"
                        className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.quantity ? 'border-red-300' : ''}`}
                        {...register(`items.${index}.quantity`, { 
                          valueAsNumber: true,
                          onChange: () => {
                            calculateItemTotal(index);
                            calculateInvoiceTotals();
                          }
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className={`shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ${errors.items?.[index]?.unit_price ? 'border-red-300' : ''}`}
                        {...register(`items.${index}.unit_price`, { 
                          valueAsNumber: true,
                          onChange: () => {
                            calculateItemTotal(index);
                            calculateInvoiceTotals();
                          }
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        {...register(`items.${index}.tax_rate`, { 
                          valueAsNumber: true,
                          onChange: () => calculateInvoiceTotals()
                        })}
                      />
                    </td>
                    <td className="px-3 py-4 text-sm text-gray-500">
                      <input
                        type="text"
                        readOnly
                        className="shadow-sm bg-gray-50 block w-full sm:text-sm border-gray-300 rounded-md"
                        value={(watchItems[index]?.total || 0).toFixed(2)}
                      />
                      <input 
                        type="hidden" 
                        {...register(`items.${index}.total`, { valueAsNumber: true })}
                      />
                    </td>
                    <td className="px-3 py-4 text-right text-sm font-medium">
                      {fields.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            remove(index);
                            setTimeout(() => calculateInvoiceTotals(), 0);
                          }}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {fields.length > rowsToRender && (
            <div className="mt-2 text-center text-sm text-gray-500">
              <button 
                type="button" 
                onClick={() => setRowsToRender(fields.length)}
                className="text-indigo-600 hover:text-indigo-900"
              >
                Show all {fields.length} items
              </button>
            </div>
          )}
          
          <div className="mt-4">
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Plus className="-ml-0.5 mr-2 h-4 w-4" />
              Add Item
            </button>
          </div>
          
          <div className="mt-6 border-t border-gray-200 pt-6">
            <div className="flex justify-end text-sm">
              <div className="w-64 space-y-2">
                <div className="flex justify-between">
                  <dt className="font-medium text-gray-700">Subtotal:</dt>
                  <dd className="text-gray-900">CHF {watch('subtotal').toFixed(2)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="font-medium text-gray-700">Tax:</dt>
                  <dd className="text-gray-900">CHF {watch('tax_amount').toFixed(2)}</dd>
                </div>
                <div className="border-t border-gray-200 pt-2 flex justify-between">
                  <dt className="font-bold text-gray-900">Total:</dt>
                  <dd className="font-bold text-gray-900">CHF {watch('total').toFixed(2)}</dd>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Additional Information</h3>
          
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Notes (visible to client)
              </label>
              <div className="mt-1">
                <textarea
                  id="notes"
                  rows={4}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  placeholder="Additional notes for the invoice..."
                  {...register('notes')}
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="terms" className="block text-sm font-medium text-gray-700">
                Terms and Conditions
              </label>
              <div className="mt-1">
                <textarea
                  id="terms"
                  rows={4}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  placeholder="e.g. Payment is due within 30 days"
                  {...register('terms')}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={() => navigate('/app/invoices')}
            className="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {saving ? (
              <>
                <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                Saving...
              </>
            ) : (
              <>
                <Save className="-ml-1 mr-2 h-4 w-4" />
                {isEditMode ? 'Update Invoice' : 'Save Invoice'}
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
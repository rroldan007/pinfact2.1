/**
 * Script to fetch and build the qrinvoice-cpp library for use in the browser
 * 
 * This script:
 * 1. Clones the qrinvoice-cpp repository from BitBucket
 * 2. Sets up Emscripten (if needed)
 * 3. Builds the library to WebAssembly
 * 4. Copies the built files to the public directory
 */

import { execSync } from 'child_process';
import { existsSync, mkdirSync, copyFileSync } from 'fs';
import { join } from 'path';

const REPO_URL = 'https://bitbucket.org/codeblockgmbh/qrinvoice-cpp.git';
const CLONE_DIR = 'temp/qrinvoice-cpp';
const BUILD_DIR = join(CLONE_DIR, 'build');
const DEST_DIR = 'public/lib';

// Make sure the destination directory exists
if (!existsSync(DEST_DIR)) {
  mkdirSync(DEST_DIR, { recursive: true });
}

// Make sure the temp directory exists
if (!existsSync('temp')) {
  mkdirSync('temp', { recursive: true });
}

try {
  console.log('Starting qrinvoice-cpp fetch and build process...');
  
  // Check if the repository is already cloned
  if (!existsSync(CLONE_DIR)) {
    console.log(`Cloning ${REPO_URL} to ${CLONE_DIR}...`);
    execSync(`git clone ${REPO_URL} ${CLONE_DIR}`, { stdio: 'inherit' });
  } else {
    console.log(`${CLONE_DIR} already exists, pulling latest changes...`);
    execSync(`cd ${CLONE_DIR} && git pull`, { stdio: 'inherit' });
  }
  
  // Create build directory if it doesn't exist
  if (!existsSync(BUILD_DIR)) {
    mkdirSync(BUILD_DIR, { recursive: true });
  }

  // Check if Emscripten is available
  try {
    execSync('emcc --version', { stdio: 'inherit' });
    console.log('Emscripten found!');
  } catch (error) {
    console.error('Emscripten (emcc) not found. Please install and set up Emscripten first.');
    console.error('Visit https://emscripten.org/docs/getting_started/downloads.html for instructions.');
    process.exit(1);
  }
  
  // Build the library with Emscripten
  console.log('Building qrinvoice-cpp with Emscripten...');
  execSync(`cd ${CLONE_DIR} && mkdir -p build && cd build && emcmake cmake .. && emmake make`, { stdio: 'inherit' });
  
  // Check if build was successful
  if (existsSync(join(BUILD_DIR, 'qrinvoice.js')) && existsSync(join(BUILD_DIR, 'qrinvoice.wasm'))) {
    console.log('Build successful!');
    
    // Copy the built files to the public directory
    copyFileSync(join(BUILD_DIR, 'qrinvoice.js'), join(DEST_DIR, 'qrinvoice.js'));
    copyFileSync(join(BUILD_DIR, 'qrinvoice.wasm'), join(DEST_DIR, 'qrinvoice.wasm'));
    
    console.log(`Files copied to ${DEST_DIR}`);
    console.log('Done!');
  } else {
    console.error('Build failed or output files not found.');
    process.exit(1);
  }
} catch (error) {
  console.error('Error:', error.message);
  process.exit(1);
}
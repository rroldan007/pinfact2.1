/*
  # Add Admin Count Function
  
  1. New Functions
    - Add RPC function to safely check admin count
    - Add helper function for admin existence check
  
  2. Security
    - Security definer functions
    - Proper permissions
*/

-- Create function to check admin count
CREATE OR REPLACE FUNCTION public.check_admin_count()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)::integer
    FROM admins
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_count() TO authenticated;

-- Add caching hint
COMMENT ON FUNCTION check_admin_count() IS 'Get total number of admin users - result stable within transaction';
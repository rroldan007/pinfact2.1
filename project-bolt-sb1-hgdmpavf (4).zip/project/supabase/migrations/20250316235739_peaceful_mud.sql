/*
  # Admin Functions and Policies Migration
  
  1. Changes
    - Drop and recreate admin functions with proper parameter names
    - Create optimized RLS policies
    - Add performance indexes
    - Set up proper security settings
  
  2. Security
    - Enable RLS
    - Set up proper function permissions
    - Create secure policies
*/

-- First drop existing policies to avoid dependency issues
DROP POLICY IF EXISTS "View admins policy" ON admins;
DROP POLICY IF EXISTS "Insert admins policy" ON admins;
DROP POLICY IF EXISTS "Update admins policy" ON admins;
DROP POLICY IF EXISTS "Delete admins policy" ON admins;

-- Drop existing functions to avoid conflicts
DROP FUNCTION IF EXISTS public.check_admin_status(uuid);
DROP FUNCTION IF EXISTS public.is_super_admin(uuid);
DROP FUNCTION IF EXISTS public.check_admin_count();

-- Create optimized admin status check function
CREATE OR REPLACE FUNCTION public.check_admin_status(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role IN ('admin', 'super_admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;

-- Add caching hint
COMMENT ON FUNCTION check_admin_status(uuid) IS 'Check if a user is an admin - result stable within transaction';

-- Create super admin check function
CREATE OR REPLACE FUNCTION public.is_super_admin(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role = 'super_admin'
  );
END;
$$;

-- Create admin count function
CREATE OR REPLACE FUNCTION public.check_admin_count()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)::integer
    FROM admins
  );
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.check_admin_count() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_super_admin(uuid) TO authenticated;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_admins_user_id_role ON admins(user_id, role);
CREATE INDEX IF NOT EXISTS idx_admins_role ON admins(role);

-- Create RLS policies
CREATE POLICY "View admins policy"
ON admins
FOR SELECT
TO public
USING (
  check_admin_status(auth.uid())
);

CREATE POLICY "Insert admins policy"
ON admins
FOR INSERT
TO public
WITH CHECK (
  is_super_admin(auth.uid())
);

CREATE POLICY "Update admins policy"
ON admins
FOR UPDATE
TO public
USING (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
)
WITH CHECK (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
);

CREATE POLICY "Delete admins policy"
ON admins
FOR DELETE
TO public
USING (
  is_super_admin(auth.uid())
);
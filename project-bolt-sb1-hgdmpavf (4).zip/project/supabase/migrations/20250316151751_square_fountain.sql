/*
  # Fix check_column_exists function

  1. Update
    - Drop the existing function first to avoid parameter name conflict
    - Create a new function with non-ambiguous parameter names
    - Fix parameter references in the query
  
  2. Security
    - Maintain existing permissions
*/

-- First drop the existing function
DROP FUNCTION IF EXISTS check_column_exists(text, text);

-- Then create the function with non-ambiguous parameter names
CREATE OR REPLACE FUNCTION check_column_exists(
  p_table_name text,
  p_column_name text
)
RETURNS boolean AS
$$
DECLARE
  _exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = p_table_name
      AND column_name = p_column_name
  ) INTO _exists;
  
  RETURN _exists;
END;
$$ LANGUAGE plpgsql;
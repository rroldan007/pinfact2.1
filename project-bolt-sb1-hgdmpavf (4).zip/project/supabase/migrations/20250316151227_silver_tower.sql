/*
  # Add Invoice Templates Schema

  1. New Type
    - `template_style` enum type with options for invoice template styles
  
  2. New Tables
    - `invoice_templates` table for storing invoice template designs

  3. Changes to Existing Tables
    - Add `default_template_id` column to `company_settings`
    - Add reference from `invoices.template_id` to `invoice_templates.id`

  4. Security
    - Enable RLS on `invoice_templates` table
    - Add policies for authenticated users to manage their own templates
    - Allow all users to view system templates

  5. Utility Functions
    - Create `check_column_exists` function to safely check for column existence
*/

-- Create the template_style enum type
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'template_style') THEN
    CREATE TYPE template_style AS ENUM ('classic', 'modern', 'minimal', 'professional');
  END IF;
END
$$;

-- Create invoice_templates table
CREATE TABLE IF NOT EXISTS invoice_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  style template_style NOT NULL DEFAULT 'classic',
  format text DEFAULT 'european',
  template_data jsonb DEFAULT '{}',
  is_system boolean DEFAULT false,
  is_default boolean DEFAULT false,
  preview_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add template reference to company_settings table
ALTER TABLE company_settings 
  ADD COLUMN IF NOT EXISTS default_template_id uuid REFERENCES invoice_templates(id);

-- Enable RLS on invoice_templates table
ALTER TABLE invoice_templates ENABLE ROW LEVEL SECURITY;

-- Create policies for accessing templates
CREATE POLICY "Users can view system templates" 
  ON invoice_templates 
  FOR SELECT 
  USING (is_system = true);

CREATE POLICY "Users can manage their own templates" 
  ON invoice_templates 
  FOR ALL 
  TO authenticated
  USING (user_id = auth.uid());

-- Create utility function for checking column existence
CREATE OR REPLACE FUNCTION check_column_exists(
  table_name text,
  column_name text
)
RETURNS boolean AS
$$
DECLARE
  _exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = $1
      AND column_name = $2
  ) INTO _exists;
  
  RETURN _exists;
END;
$$ LANGUAGE plpgsql;

-- Insert default templates
INSERT INTO invoice_templates (
  name, 
  description, 
  style, 
  template_data, 
  is_system,
  preview_url
)
VALUES 
(
  'Classic',
  'A traditional invoice layout with a clean, professional design',
  'classic',
  '{"primaryColor":"#2563eb","secondaryColor":"#e5e7eb","fontFamily":"Arial, sans-serif","showLogo":true,"showSignature":false,"showPaymentQR":false,"footerText":"Thank you for your business!","layout":{"headerStyle":"standard","itemsTableStyle":"bordered","totalSection":"right-aligned"}}',
  true,
  'https://images.unsplash.com/photo-1633409361618-c73427e4e206?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO invoice_templates (
  name, 
  description, 
  style, 
  template_data, 
  is_system,
  preview_url
)
VALUES 
(
  'Modern',
  'A contemporary design with emphasis on visuals and clean typography',
  'modern',
  '{"primaryColor":"#8b5cf6","secondaryColor":"#f3f4f6","fontFamily":"Helvetica, Arial, sans-serif","showLogo":true,"showSignature":true,"showPaymentQR":true,"footerText":"Thank you for choosing our services","layout":{"headerStyle":"centered","itemsTableStyle":"alternating-rows","totalSection":"boxed"}}',
  true,
  'https://images.unsplash.com/photo-1634733988138-bf2c3a2a13fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO invoice_templates (
  name, 
  description, 
  style, 
  template_data, 
  is_system,
  preview_url
)
VALUES 
(
  'Minimal',
  'A clean, simple design focusing on essential information',
  'minimal',
  '{"primaryColor":"#6b7280","secondaryColor":"#f9fafb","fontFamily":"Roboto, sans-serif","showLogo":true,"showSignature":false,"showPaymentQR":false,"footerText":"","layout":{"headerStyle":"simple","itemsTableStyle":"borderless","totalSection":"simple"}}',
  true,
  'https://images.unsplash.com/photo-1586861635167-e5223ebe5e9e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO invoice_templates (
  name, 
  description, 
  style, 
  template_data, 
  is_system,
  preview_url
)
VALUES 
(
  'Professional',
  'A business-focused template with a corporate feel',
  'professional',
  '{"primaryColor":"#1f2937","secondaryColor":"#e5e7eb","fontFamily":"Georgia, serif","showLogo":true,"showSignature":true,"showPaymentQR":true,"footerText":"Terms: Payment due within 30 days","layout":{"headerStyle":"business","itemsTableStyle":"detailed","totalSection":"detailed"}}',
  true,
  'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250'
)
ON CONFLICT (id) DO NOTHING;
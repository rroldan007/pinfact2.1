/*
  # Fix Admin Access Final
  
  1. Changes
    - Drop and recreate admin functions with proper permissions
    - Ensure proper RLS policies
    - Fix admin record for r.roldan@live.com
  
  2. Security
    - Maintain RLS policies
    - Set proper admin role and permissions
*/

-- First drop existing policies and functions
DROP POLICY IF EXISTS "View admins policy" ON admins;
DROP POLICY IF EXISTS "Insert admins policy" ON admins;
DROP POLICY IF EXISTS "Update admins policy" ON admins;
DROP POLICY IF EXISTS "Delete admins policy" ON admins;

DROP FUNCTION IF EXISTS public.check_admin_status(uuid);
DROP FUNCTION IF EXISTS public.is_super_admin(uuid);
DROP FUNCTION IF EXISTS public.check_admin_count();

-- Create optimized admin status check function
CREATE OR REPLACE FUNCTION public.check_admin_status(checking_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  -- Direct query without going through RLS
  SELECT EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role IN ('admin', 'super_admin')
  );
$$;

-- Create super admin check function
CREATE OR REPLACE FUNCTION public.is_super_admin(checking_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  -- Direct query without going through RLS
  SELECT EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role = 'super_admin'
  );
$$;

-- Create admin count function
CREATE OR REPLACE FUNCTION public.check_admin_count()
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  -- Direct query without going through RLS
  SELECT COUNT(*)::integer
  FROM admins;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_super_admin(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.check_admin_count() TO authenticated;

-- Add caching hints
COMMENT ON FUNCTION check_admin_status(uuid) IS 'Check if a user is an admin - result stable within transaction';
COMMENT ON FUNCTION is_super_admin(uuid) IS 'Check if a user is a super admin - result stable within transaction';
COMMENT ON FUNCTION check_admin_count() IS 'Get total number of admin users - result stable within transaction';

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_admins_user_id_role ON admins(user_id, role);
CREATE INDEX IF NOT EXISTS idx_admins_role ON admins(role);

-- Make sure RLS is enabled
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "View admins policy"
ON admins
FOR SELECT
TO authenticated
USING (true);  -- Allow all authenticated users to view admin records

CREATE POLICY "Insert admins policy"
ON admins
FOR INSERT
TO authenticated
WITH CHECK (
  is_super_admin(auth.uid())
);

CREATE POLICY "Update admins policy"
ON admins
FOR UPDATE
TO authenticated
USING (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
)
WITH CHECK (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
);

CREATE POLICY "Delete admins policy"
ON admins
FOR DELETE
TO authenticated
USING (
  is_super_admin(auth.uid())
);

-- Fix admin record for r.roldan@live.com
DO $$ 
DECLARE
  target_user_id uuid;
BEGIN
  -- Get the user ID for r.roldan@live.com
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = 'r.roldan@live.com';

  -- If user exists, ensure they have an admin record
  IF target_user_id IS NOT NULL THEN
    -- Delete any existing admin record to avoid conflicts
    DELETE FROM admins WHERE user_id = target_user_id;
    
    -- Create new admin record with super_admin role
    INSERT INTO admins (
      user_id,
      role,
      permissions
    )
    VALUES (
      target_user_id,
      'super_admin',
      jsonb_build_object(
        'can_manage_users', true,
        'can_manage_admins', true,
        'can_view_payments', true,
        'can_manage_settings', true
      )
    );
  END IF;
END $$;
/*
  # Creación de Tablas de Administración

  1. Nuevas Tablas
    - `admins`: Tabla para almacenar información sobre usuarios administradores
  
  2. Seguridad
    - Políticas RLS para proteger datos de administradores
*/

-- Crear tabla de administradores
CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  permissions jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Habilitar RLS en tabla de administradores
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Crear políticas de seguridad para administradores
CREATE POLICY "Solo administradores pueden ver otros administradores"
  ON admins
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
    )
  );

CREATE POLICY "Los administradores pueden crear otros administradores"
  ON admins
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
    )
  );

CREATE POLICY "Los administradores solo pueden actualizar sus propios registros"
  ON admins
  FOR UPDATE
  USING (user_id = auth.uid());

-- Función para comprobar si un usuario es administrador
CREATE OR REPLACE FUNCTION is_admin(user_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admins 
    WHERE user_id = user_uuid
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función para añadir el primer administrador (bootstrap)
CREATE OR REPLACE FUNCTION add_initial_admin(
  admin_email text,
  admin_password text
)
RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
  new_admin_id uuid;
BEGIN
  -- Insertar nuevo usuario en auth.users si no existe
  INSERT INTO auth.users (
    email,
    raw_user_meta_data,
    created_at,
    updated_at
  )
  VALUES (
    admin_email,
    json_build_object('admin', true),
    now(),
    now()
  )
  ON CONFLICT (email) DO NOTHING
  RETURNING id INTO new_user_id;

  -- Si no se insertó, obtener el ID de usuario existente
  IF new_user_id IS NULL THEN
    SELECT id INTO new_user_id FROM auth.users WHERE email = admin_email;
  END IF;

  -- Insertar en la tabla de administradores
  INSERT INTO admins (
    user_id,
    role,
    permissions
  )
  VALUES (
    new_user_id,
    'super_admin',
    '{"can_manage_users": true, "can_manage_admins": true}'
  )
  ON CONFLICT (user_id) DO NOTHING
  RETURNING id INTO new_admin_id;

  RETURN new_admin_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can manage their own quotes" ON quotes;
DROP POLICY IF EXISTS "Users can manage their own quote items" ON quote_items;

-- Make sure RLS is enabled
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_items ENABLE ROW LEVEL SECURITY;

-- Add missing indexes for better performance
CREATE INDEX IF NOT EXISTS idx_quotes_user_id ON quotes(user_id);
CREATE INDEX IF NOT EXISTS idx_quotes_client_id ON quotes(client_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
CREATE INDEX IF NOT EXISTS idx_quotes_date ON quotes(date);
CREATE INDEX IF NOT EXISTS idx_quote_items_quote_id ON quote_items(quote_id);
CREATE INDEX IF NOT EXISTS idx_quote_items_product_id ON quote_items(product_id);

-- Add missing foreign key constraints if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'quote_items_quote_id_fkey'
  ) THEN
    ALTER TABLE quote_items
    ADD CONSTRAINT quote_items_quote_id_fkey
    FOREIGN KEY (quote_id)
    REFERENCES quotes(id)
    ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'quote_items_product_id_fkey'
  ) THEN
    ALTER TABLE quote_items
    ADD CONSTRAINT quote_items_product_id_fkey
    FOREIGN KEY (product_id)
    REFERENCES products(id)
    ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'quotes_user_id_fkey'
  ) THEN
    ALTER TABLE quotes
    ADD CONSTRAINT quotes_user_id_fkey
    FOREIGN KEY (user_id)
    REFERENCES auth.users(id)
    ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'quotes_client_id_fkey'
  ) THEN
    ALTER TABLE quotes
    ADD CONSTRAINT quotes_client_id_fkey
    FOREIGN KEY (client_id)
    REFERENCES clients(id)
    ON DELETE CASCADE;
  END IF;
END $$;

-- Add missing columns if they don't exist
DO $$ 
BEGIN
  -- Add updated_at column to quotes if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'quotes' 
    AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE quotes 
    ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;

  -- Add created_at column to quotes if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'quotes' 
    AND column_name = 'created_at'
  ) THEN
    ALTER TABLE quotes 
    ADD COLUMN created_at timestamptz DEFAULT now();
  END IF;

  -- Add created_at column to quote_items if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'quote_items' 
    AND column_name = 'created_at'
  ) THEN
    ALTER TABLE quote_items 
    ADD COLUMN created_at timestamptz DEFAULT now();
  END IF;

  -- Add updated_at column to quote_items if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'quote_items' 
    AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE quote_items 
    ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Create or replace updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_quotes_updated_at ON quotes;
CREATE TRIGGER update_quotes_updated_at
  BEFORE UPDATE ON quotes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_quote_items_updated_at ON quote_items;
CREATE TRIGGER update_quote_items_updated_at
  BEFORE UPDATE ON quote_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create RLS policies for quotes
CREATE POLICY "Users can manage their own quotes"
ON quotes
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Create RLS policies for quote items
CREATE POLICY "Users can manage their own quote items"
ON quote_items
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM quotes
    WHERE quotes.id = quote_items.quote_id
    AND quotes.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM quotes
    WHERE quotes.id = quote_items.quote_id
    AND quotes.user_id = auth.uid()
  )
);

-- Create function to handle quote number generation
CREATE OR REPLACE FUNCTION generate_quote_number(user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  prefix text;
  next_number integer;
BEGIN
  -- Get the user's quote prefix and next number from company settings
  SELECT 
    COALESCE(quote_prefix, 'DEV-'),
    COALESCE(next_quote_number, 1)
  INTO prefix, next_number
  FROM company_settings
  WHERE company_settings.user_id = $1;

  -- If no settings exist, create default ones
  IF NOT FOUND THEN
    INSERT INTO company_settings (
      user_id, 
      quote_prefix, 
      next_quote_number
    ) 
    VALUES (
      $1, 
      'DEV-', 
      2
    );
    
    prefix := 'DEV-';
    next_number := 1;
  ELSE
    -- Update the next number
    UPDATE company_settings
    SET next_quote_number = next_number + 1
    WHERE company_settings.user_id = $1;
  END IF;

  -- Return the formatted quote number
  RETURN prefix || LPAD(next_number::text, 4, '0');
END;
$$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION generate_quote_number(uuid) TO authenticated;

-- Create function to convert quote to invoice
CREATE OR REPLACE FUNCTION convert_quote_to_invoice(quote_id uuid, user_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_invoice_id uuid;
  quote_record record;
BEGIN
  -- Check if quote exists and belongs to user
  SELECT * INTO quote_record
  FROM quotes
  WHERE id = quote_id AND user_id = user_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Quote not found or access denied';
  END IF;
  
  -- Check if quote is in accepted status
  IF quote_record.status != 'accepted' THEN
    RAISE EXCEPTION 'Only accepted quotes can be converted to invoices';
  END IF;

  -- Start transaction
  BEGIN
    -- Create new invoice
    INSERT INTO invoices (
      user_id,
      client_id,
      invoice_number,
      date,
      due_date,
      status,
      notes,
      terms,
      subtotal,
      tax_amount,
      total,
      template_id,
      footer_text,
      payment_conditions,
      bank_account_details,
      vat_number,
      currency_rate,
      language,
      custom_fields
    )
    SELECT
      user_id,
      client_id,
      (SELECT generate_invoice_number(user_id)),
      CURRENT_DATE,
      CURRENT_DATE + INTERVAL '30 days',
      'draft',
      notes,
      terms,
      subtotal,
      tax_amount,
      total,
      template_id,
      footer_text,
      payment_conditions,
      bank_account_details,
      vat_number,
      currency_rate,
      language,
      custom_fields
    FROM quotes
    WHERE id = quote_id
    RETURNING id INTO new_invoice_id;

    -- Copy quote items to invoice items
    INSERT INTO invoice_items (
      invoice_id,
      description,
      secondary_description,
      quantity,
      unit_price,
      tax_rate,
      product_id,
      total
    )
    SELECT
      new_invoice_id,
      description,
      secondary_description,
      quantity,
      unit_price,
      tax_rate,
      product_id,
      total
    FROM quote_items
    WHERE quote_id = quote_id;

    -- Update quote status to converted
    UPDATE quotes
    SET 
      status = 'converted',
      updated_at = now()
    WHERE id = quote_id;

    RETURN new_invoice_id;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;
END;
$$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION convert_quote_to_invoice(uuid, uuid) TO authenticated;

-- Add comment for documentation
COMMENT ON FUNCTION convert_quote_to_invoice(uuid, uuid) IS 'Converts an accepted quote to a draft invoice';
/*
  # Initial Schema Setup for Invoice Application

  1. Tables
    - products
      - Product catalog with descriptions and prices
    - clients
      - Client information for invoices
    - company_settings
      - Company information including bank details and logo
    - invoices
      - Invoice details with client information
    - invoice_items
      - Individual line items for each invoice

  2. Security
    - RLS enabled on all tables
    - Policies for authenticated users to manage their own data
*/

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text,
  price numeric(12,2) NOT NULL,
  tax_rate numeric(5,2) DEFAULT 7.7 NOT NULL,
  sku text,
  category text,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  email text,
  phone text,
  address text,
  postal_code text,
  city text,
  country text DEFAULT 'Suisse',
  website text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Company settings table
CREATE TABLE IF NOT EXISTS company_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  company_name text NOT NULL,
  company_email text,
  company_phone text,
  company_address text,
  company_postal_code text,
  company_city text,
  company_country text DEFAULT 'Suisse',
  company_website text,
  company_vat_number text,
  company_iban text,
  company_bic text,
  company_bank text,
  company_logo_url text,
  invoice_prefix text DEFAULT 'INV-',
  next_invoice_number integer DEFAULT 1,
  default_payment_terms integer DEFAULT 30,
  default_tax_rate numeric(5,2) DEFAULT 7.7,
  default_currency text DEFAULT 'CHF',
  default_notes text,
  default_terms text DEFAULT 'Paiement dû dans les 30 jours suivant la réception de la facture.',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Invoices table
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE NOT NULL,
  invoice_number text NOT NULL,
  date date NOT NULL,
  due_date date NOT NULL,
  status invoice_status DEFAULT 'draft',
  notes text,
  terms text,
  subtotal numeric(12,2) NOT NULL,
  tax_amount numeric(12,2) NOT NULL,
  total numeric(12,2) NOT NULL,
  payment_reference text,
  template_id uuid REFERENCES invoice_templates(id),
  footer_text text,
  payment_conditions text,
  bank_account_details text,
  vat_number text,
  currency_rate numeric(10,6),
  language text DEFAULT 'fr',
  custom_fields jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Invoice items table
CREATE TABLE IF NOT EXISTS invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES invoices(id) ON DELETE CASCADE NOT NULL,
  description text NOT NULL,
  secondary_description text,
  quantity integer NOT NULL,
  unit_price numeric(12,2) NOT NULL,
  tax_rate numeric(5,2) DEFAULT 7.7 NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  total numeric(12,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can manage their own products"
  ON products
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own clients"
  ON clients
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own company settings"
  ON company_settings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own invoices"
  ON invoices
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own invoice items"
  ON invoice_items
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM invoices
    WHERE invoices.id = invoice_items.invoice_id
    AND invoices.user_id = auth.uid()
  ));
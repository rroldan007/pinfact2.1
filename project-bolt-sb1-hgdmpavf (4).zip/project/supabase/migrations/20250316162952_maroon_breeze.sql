/*
  # Storage Setup for Invoice Application

  1. New Storage Buckets
    - Creates 'company-logos' bucket for storing company logos
    - Creates 'invoice-attachments' bucket for future invoice attachments

  2. Security
    - Sets up RLS policies for authenticated users to manage their files
    - Allows public read access to the files for sharing invoices
*/

-- Enable the storage extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";

-- Create the storage schema if it doesn't already exist
CREATE SCHEMA IF NOT EXISTS "storage";

-- Create the company-logos bucket
INSERT INTO storage.buckets (id, name, public, avif_autodetection)
VALUES ('company-logos', 'company-logos', true, false)
ON CONFLICT (id) DO NOTHING;

-- Create the invoice-attachments bucket
INSERT INTO storage.buckets (id, name, public, avif_autodetection)
VALUES ('invoice-attachments', 'invoice-attachments', true, false)
ON CONFLICT (id) DO NOTHING;

-- Policies for company-logos bucket

-- Allow public to read files from company-logos bucket
CREATE POLICY "Company logos are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'company-logos');

-- Allow authenticated users to upload files to company-logos bucket
CREATE POLICY "Users can upload company logos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to update their own files in company-logos bucket
CREATE POLICY "Users can update their own company logos"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to delete their own files in company-logos bucket
CREATE POLICY "Users can delete their own company logos"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policies for invoice-attachments bucket

-- Allow public to read files from invoice-attachments bucket
CREATE POLICY "Invoice attachments are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'invoice-attachments');

-- Allow authenticated users to upload files to invoice-attachments bucket
CREATE POLICY "Users can upload invoice attachments"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'invoice-attachments' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to update their own files in invoice-attachments bucket
CREATE POLICY "Users can update their own invoice attachments"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'invoice-attachments' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'invoice-attachments' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to delete their own files in invoice-attachments bucket
CREATE POLICY "Users can delete their own invoice attachments"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'invoice-attachments' AND
  (storage.foldername(name))[1] = auth.uid()::text
);
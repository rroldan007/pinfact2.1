/*
  # Fix Quote Loading Issues

  1. Changes
    - Add missing columns to company_settings table
    - Add default values for quote settings
    - Create function to initialize company settings
    - Add trigger for new users

  2. Security
    - Enable RLS on company_settings
    - Add policies for user access
*/

-- Add missing columns to company_settings if they don't exist
DO $$ 
BEGIN
  -- Add quote_prefix if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'company_settings' 
    AND column_name = 'quote_prefix'
  ) THEN
    ALTER TABLE company_settings 
    ADD COLUMN quote_prefix text DEFAULT 'DEV-';
  END IF;

  -- Add next_quote_number if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'company_settings' 
    AND column_name = 'next_quote_number'
  ) THEN
    ALTER TABLE company_settings 
    ADD COLUMN next_quote_number integer DEFAULT 1;
  END IF;
END $$;

-- Create function to initialize company settings
CREATE OR REPLACE FUNCTION initialize_company_settings()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO company_settings (
    user_id,
    company_name,
    default_payment_terms,
    default_tax_rate,
    default_currency,
    quote_prefix,
    next_quote_number,
    invoice_prefix,
    next_invoice_number
  ) VALUES (
    NEW.id,
    'My Company',
    30,
    7.7,
    'CHF',
    'DEV-',
    1,
    'INV-',
    1
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new users if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_trigger 
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION initialize_company_settings();
  END IF;
END $$;

-- Make sure RLS is enabled
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists and create new one
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own company settings" ON company_settings;
  
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'company_settings' 
    AND policyname = 'Users can manage their own company settings'
  ) THEN
    CREATE POLICY "Users can manage their own company settings"
    ON company_settings
    FOR ALL
    TO authenticated
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());
  END IF;
END $$;

-- Create index for better performance if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_company_settings_user_id 
ON company_settings(user_id);
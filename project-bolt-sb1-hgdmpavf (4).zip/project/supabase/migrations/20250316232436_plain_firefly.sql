/*
  # Fix Admin Authentication System

  1. Changes
    - Fix recursive policy issue
    - Add proper admin role checks
    - Improve admin creation function
    - Add admin verification function

  2. Security
    - Proper RLS policies
    - Role-based access control
    - Secure admin management
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Solo administradores pueden ver otros administradores" ON admins;
DROP POLICY IF EXISTS "Los administradores pueden crear otros administradores" ON admins;
DROP POLICY IF EXISTS "Los administradores solo pueden actualizar sus propios registros" ON admins;

-- Recreate admins table with improved structure
CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  permissions jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Create improved policies
CREATE POLICY "Admins can view all admins"
  ON admins
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
      AND (a.role = 'super_admin' OR a.permissions->>'can_manage_admins' = 'true')
    )
  );

CREATE POLICY "Super admins can create admins"
  ON admins
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
      AND a.role = 'super_admin'
    )
  );

CREATE POLICY "Admins can update their own records"
  ON admins
  FOR UPDATE
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
      AND a.role = 'super_admin'
    )
  )
  WITH CHECK (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM admins a
      WHERE a.user_id = auth.uid()
      AND a.role = 'super_admin'
    )
  );

-- Function to check if a user is an admin
CREATE OR REPLACE FUNCTION is_admin(user_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admins 
    WHERE user_id = user_uuid
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check admin role and permissions
CREATE OR REPLACE FUNCTION check_admin_access(user_uuid uuid, required_permission text DEFAULT NULL)
RETURNS boolean AS $$
DECLARE
  admin_record RECORD;
BEGIN
  -- Get admin record
  SELECT role, permissions INTO admin_record
  FROM admins
  WHERE user_id = user_uuid;
  
  -- If no record found, user is not an admin
  IF admin_record IS NULL THEN
    RETURN false;
  END IF;
  
  -- Super admins always have access
  IF admin_record.role = 'super_admin' THEN
    RETURN true;
  END IF;
  
  -- If specific permission is required, check it
  IF required_permission IS NOT NULL THEN
    RETURN (admin_record.permissions->>required_permission)::boolean;
  END IF;
  
  -- Regular admin with no specific permission required
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to add initial admin (improved version)
CREATE OR REPLACE FUNCTION add_initial_admin(
  admin_email text,
  admin_password text
)
RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
  new_admin_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO admin_count FROM admins;
  
  -- Only allow creation if there are no admins
  IF admin_count > 0 THEN
    RAISE EXCEPTION 'Cannot create initial admin: Admins already exist';
  END IF;

  -- Get existing user or create new one
  SELECT id INTO new_user_id
  FROM auth.users
  WHERE email = admin_email;

  IF new_user_id IS NULL THEN
    -- Create new user if doesn't exist
    INSERT INTO auth.users (
      email,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      admin_email,
      jsonb_build_object(
        'is_admin', true,
        'role', 'super_admin'
      ),
      now(),
      now()
    )
    RETURNING id INTO new_user_id;
  END IF;

  -- Create admin record
  INSERT INTO admins (
    user_id,
    role,
    permissions
  )
  VALUES (
    new_user_id,
    'super_admin',
    jsonb_build_object(
      'can_manage_users', true,
      'can_manage_admins', true,
      'can_view_payments', true,
      'can_manage_settings', true
    )
  )
  RETURNING id INTO new_admin_id;

  RETURN new_admin_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
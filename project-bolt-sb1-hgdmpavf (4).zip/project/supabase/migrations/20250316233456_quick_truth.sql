/*
  # Fix Admin Loading and Status Check

  1. Changes
    - Add optimized admin status check function
    - Add proper indexes for faster queries
    - Improve RLS policies

  2. Security
    - Maintain RLS security
    - Keep role-based access control
    - Use security definer for direct access
*/

-- Add index to improve admin lookup performance
CREATE INDEX IF NOT EXISTS idx_admins_user_id ON admins(user_id);

-- Optimized admin status check function
CREATE OR REPLACE FUNCTION public.check_admin_status(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Fast lookup with index
  RETURN EXISTS (
    SELECT 1 
    FROM admins 
    WHERE user_id = $1
    AND (role = 'admin' OR role = 'super_admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;

-- Revoke execute from public
REVOKE EXECUTE ON FUNCTION public.check_admin_status(uuid) FROM public;

-- Optimize admin policies
CREATE OR REPLACE FUNCTION is_admin_user(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins 
    WHERE user_id = checking_user_id
    AND (role = 'admin' OR role = 'super_admin')
  );
END;
$$;

-- Add caching hint
COMMENT ON FUNCTION is_admin_user(uuid) IS 'Check if a user is an admin - result stable within transaction';
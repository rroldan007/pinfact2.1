/*
  # Fix Admin Policies Recursion

  1. Changes
    - Fix infinite recursion in admin policies
    - Simplify policy checks
    - Add proper admin role verification

  2. Security
    - Maintain RLS security
    - Keep role-based access control
    - Fix policy recursion while maintaining security
*/

-- First drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Admins can view all admins" ON admins;
DROP POLICY IF EXISTS "Super admins can create admins" ON admins;
DROP POLICY IF EXISTS "Admins can update their own records" ON admins;

-- Create a function to check admin status without recursion
CREATE OR REPLACE FUNCTION is_admin_user(checking_user_id uuid)
RETURNS boolean AS $$
BEGIN
  -- Direct query without going through RLS
  RETURN EXISTS (
    SELECT 1 
    FROM admins 
    WHERE user_id = checking_user_id
    AND (role = 'admin' OR role = 'super_admin')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to check if user is super admin
CREATE OR REPLACE FUNCTION is_super_admin(checking_user_id uuid)
RETURNS boolean AS $$
BEGIN
  -- Direct query without going through RLS
  RETURN EXISTS (
    SELECT 1 
    FROM admins 
    WHERE user_id = checking_user_id
    AND role = 'super_admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Make sure RLS is enabled
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Create new non-recursive policies
CREATE POLICY "View admins policy"
ON admins
FOR SELECT
USING (
  -- Allow viewing if the user is an admin
  is_admin_user(auth.uid())
);

CREATE POLICY "Insert admins policy"
ON admins
FOR INSERT
WITH CHECK (
  -- Only super admins can create new admins
  is_super_admin(auth.uid())
);

CREATE POLICY "Update admins policy"
ON admins
FOR UPDATE
USING (
  -- Can update if super admin or updating own record
  is_super_admin(auth.uid()) OR
  user_id = auth.uid()
)
WITH CHECK (
  -- Same check for the new values
  is_super_admin(auth.uid()) OR
  user_id = auth.uid()
);

CREATE POLICY "Delete admins policy"
ON admins
FOR DELETE
USING (
  -- Only super admins can delete admin records
  is_super_admin(auth.uid())
);

-- Function to safely check admin permissions
CREATE OR REPLACE FUNCTION check_admin_permission(user_uuid uuid, required_permission text)
RETURNS boolean AS $$
DECLARE
  user_role text;
  user_permissions jsonb;
BEGIN
  -- Direct query without going through RLS
  SELECT role, permissions 
  INTO user_role, user_permissions
  FROM admins
  WHERE user_id = user_uuid;

  -- Super admins always have all permissions
  IF user_role = 'super_admin' THEN
    RETURN true;
  END IF;

  -- Check specific permission for regular admins
  IF user_role = 'admin' AND user_permissions ? required_permission THEN
    RETURN (user_permissions->>required_permission)::boolean;
  END IF;

  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to add initial admin safely
CREATE OR REPLACE FUNCTION add_initial_admin(
  admin_email text,
  admin_password text
)
RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO admin_count FROM admins;
  
  IF admin_count > 0 THEN
    RAISE EXCEPTION 'Cannot create initial admin: Admins already exist';
  END IF;

  -- Create or get user
  SELECT id INTO new_user_id
  FROM auth.users
  WHERE email = admin_email;

  IF new_user_id IS NULL THEN
    -- Create new user
    new_user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      new_user_id,
      admin_email,
      crypt(admin_password, gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{"is_admin": true}',
      now(),
      now()
    );
  END IF;

  -- Create admin record
  INSERT INTO admins (
    user_id,
    role,
    permissions
  )
  VALUES (
    new_user_id,
    'super_admin',
    jsonb_build_object(
      'can_manage_users', true,
      'can_manage_admins', true,
      'can_view_payments', true,
      'can_manage_settings', true
    )
  );

  RETURN new_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
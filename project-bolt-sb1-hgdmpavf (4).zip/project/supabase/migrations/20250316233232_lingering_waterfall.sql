/*
  # Fix Admin Status Check

  1. Changes
    - Add RPC function for checking admin status
    - Optimize admin status check to avoid recursion
    - Add proper error handling

  2. Security
    - Maintain RLS security
    - Keep role-based access control
    - Use security definer for direct access
*/

-- Create RPC function to check admin status
CREATE OR REPLACE FUNCTION public.check_admin_status(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins 
    WHERE user_id = $1
    AND (role = 'admin' OR role = 'super_admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;

-- Revoke execute from public
REVOKE EXECUTE ON FUNCTION public.check_admin_status(uuid) FROM public;
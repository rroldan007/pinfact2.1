/*
  # Fix Admin Access
  
  1. Changes
    - Add missing admin record for r.roldan@live.com
    - Ensure proper permissions
  
  2. Security
    - Maintain RLS policies
    - Set proper admin role
*/

-- First check if the user exists
DO $$ 
DECLARE
  target_user_id uuid;
BEGIN
  -- Get the user ID for r.roldan@live.com
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = 'r.roldan@live.com';

  -- If user exists but doesn't have admin record, create it
  IF target_user_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM admins WHERE user_id = target_user_id
  ) THEN
    INSERT INTO admins (
      user_id,
      role,
      permissions
    )
    VALUES (
      target_user_id,
      'super_admin',
      jsonb_build_object(
        'can_manage_users', true,
        'can_manage_admins', true,
        'can_view_payments', true,
        'can_manage_settings', true
      )
    );
  END IF;
END $$;
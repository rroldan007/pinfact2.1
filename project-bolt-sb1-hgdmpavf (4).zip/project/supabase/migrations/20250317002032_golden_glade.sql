/*
  # Fix Admin Permissions and Setup
  
  1. Changes
    - Drop and recreate admin functions with proper permissions
    - Create initial admin setup function
    - Add proper RLS policies
    - Add performance indexes
  
  2. Security
    - Enable RLS
    - Set up proper function permissions
    - Create secure policies
*/

-- First drop existing policies and functions
DROP POLICY IF EXISTS "View admins policy" ON admins;
DROP POLICY IF EXISTS "Insert admins policy" ON admins;
DROP POLICY IF EXISTS "Update admins policy" ON admins;
DROP POLICY IF EXISTS "Delete admins policy" ON admins;

DROP FUNCTION IF EXISTS public.check_admin_status(uuid);
DROP FUNCTION IF EXISTS public.is_super_admin(uuid);
DROP FUNCTION IF EXISTS public.check_admin_count();

-- Create optimized admin status check function
CREATE OR REPLACE FUNCTION public.check_admin_status(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  -- Direct query without going through RLS
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role IN ('admin', 'super_admin')
  );
END;
$$;

-- Create super admin check function
CREATE OR REPLACE FUNCTION public.is_super_admin(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  -- Direct query without going through RLS
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role = 'super_admin'
  );
END;
$$;

-- Create admin count function
CREATE OR REPLACE FUNCTION public.check_admin_count()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  -- Direct query without going through RLS
  RETURN (
    SELECT COUNT(*)::integer
    FROM admins
  );
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_super_admin(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.check_admin_count() TO authenticated;

-- Add caching hints
COMMENT ON FUNCTION check_admin_status(uuid) IS 'Check if a user is an admin - result stable within transaction';
COMMENT ON FUNCTION is_super_admin(uuid) IS 'Check if a user is a super admin - result stable within transaction';
COMMENT ON FUNCTION check_admin_count() IS 'Get total number of admin users - result stable within transaction';

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_admins_user_id_role ON admins(user_id, role);
CREATE INDEX IF NOT EXISTS idx_admins_role ON admins(role);

-- Make sure RLS is enabled
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Create RLS policies without table aliases
CREATE POLICY "View admins policy"
ON admins
FOR SELECT
TO authenticated
USING (
  check_admin_status(auth.uid())
);

CREATE POLICY "Insert admins policy"
ON admins
FOR INSERT
TO authenticated
WITH CHECK (
  is_super_admin(auth.uid())
);

CREATE POLICY "Update admins policy"
ON admins
FOR UPDATE
TO authenticated
USING (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
)
WITH CHECK (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
);

CREATE POLICY "Delete admins policy"
ON admins
FOR DELETE
TO authenticated
USING (
  is_super_admin(auth.uid())
);

-- Create initial admin setup function
CREATE OR REPLACE FUNCTION setup_initial_admin(
  admin_email text,
  admin_password text
) 
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER 
SET search_path = public
AS $$
DECLARE
  new_user_id uuid;
  admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO admin_count FROM admins;
  
  IF admin_count > 0 THEN
    RAISE EXCEPTION 'Cannot create initial admin: Admins already exist';
  END IF;

  -- Create the user if it doesn't exist
  INSERT INTO auth.users (
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data
  )
  VALUES (
    admin_email,
    crypt(admin_password, gen_salt('bf')),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    '{"is_super_admin": true}'
  )
  RETURNING id INTO new_user_id;

  -- Create admin record
  INSERT INTO admins (
    user_id,
    role,
    permissions
  )
  VALUES (
    new_user_id,
    'super_admin',
    jsonb_build_object(
      'can_manage_users', true,
      'can_manage_admins', true,
      'can_view_payments', true,
      'can_manage_settings', true
    )
  );

  RETURN new_user_id;
END;
$$;
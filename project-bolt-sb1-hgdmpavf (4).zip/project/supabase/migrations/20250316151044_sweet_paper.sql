/*
  # Remove Invoice Templates Schema

  1. Changes
    - Removes the foreign key constraint between invoices and invoice_templates
    - Sets all template_id values to NULL to avoid orphaned references
    - Drops the invoice_templates table completely

  2. Reason
    - Schema restructuring
*/

-- 1. First remove the foreign key constraint so we can modify the referenced table
ALTER TABLE invoices DROP CONSTRAINT IF EXISTS invoices_template_id_fkey;

-- 2. Set all template_id values to NULL to avoid orphaned references
UPDATE invoices SET template_id = NULL WHERE template_id IS NOT NULL;

-- 3. Remove the column from company_settings that references invoice_templates
ALTER TABLE company_settings DROP COLUMN IF EXISTS default_template_id;

-- 4. Finally drop the invoice_templates table
DROP TABLE IF EXISTS invoice_templates;

-- 5. Remove the template_style enum type if it exists
DROP TYPE IF EXISTS template_style;
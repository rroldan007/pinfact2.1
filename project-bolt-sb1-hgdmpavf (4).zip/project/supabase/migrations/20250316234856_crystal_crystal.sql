/*
  # Admin Functions and Policies Migration
  
  1. Changes
    - Drop existing policies first to avoid dependency issues
    - Create admin check functions
    - Create RLS policies
    - Add performance optimizations
  
  2. Security
    - Maintain RLS policies
    - Keep security definer functions
    - Preserve permission checks
*/

-- First drop existing policies to avoid dependency issues
DROP POLICY IF EXISTS "View admins policy" ON admins;
DROP POLICY IF EXISTS "Insert admins policy" ON admins;
DROP POLICY IF EXISTS "Update admins policy" ON admins;
DROP POLICY IF EXISTS "Delete admins policy" ON admins;

-- Drop existing functions to avoid conflicts
DROP FUNCTION IF EXISTS public.check_admin_status(uuid);
DROP FUNCTION IF EXISTS public.is_super_admin(uuid);

-- Create optimized admin status check function
CREATE OR REPLACE FUNCTION public.check_admin_status(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role IN ('admin', 'super_admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.check_admin_status(uuid) TO authenticated;

-- Add caching hint
COMMENT ON FUNCTION check_admin_status(uuid) IS 'Check if a user is an admin - result stable within transaction';

-- Create index for faster lookups if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_admins_user_id_role ON admins(user_id, role);

-- Create super admin check function
CREATE OR REPLACE FUNCTION public.is_super_admin(checking_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admins
    WHERE user_id = checking_user_id
    AND role = 'super_admin'
  );
END;
$$;

-- Create new policies
CREATE POLICY "View admins policy"
ON admins
FOR SELECT
TO public
USING (
  check_admin_status(auth.uid())
);

CREATE POLICY "Insert admins policy"
ON admins
FOR INSERT
TO public
WITH CHECK (
  is_super_admin(auth.uid())
);

CREATE POLICY "Update admins policy"
ON admins
FOR UPDATE
TO public
USING (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
)
WITH CHECK (
  is_super_admin(auth.uid()) OR user_id = auth.uid()
);

CREATE POLICY "Delete admins policy"
ON admins
FOR DELETE
TO public
USING (
  is_super_admin(auth.uid())
);